# 校园闲置物品交易平台 Demo

基于 Vue 3 + Flask + localStorage 的轻量级校园二手物品交易平台演示项目。

## 功能特性

✅ **统一身份认证**：学号注册、校园卡OCR（演示）、人脸验证（演示）  
✅ **智能定价**：基于历史行情与成色的建议售价算法  
✅ **智能推荐**：标签权重 + 价格相近 + 同院系优先 + 协同过滤  
✅ **信用积分**：互评系统、头衔体系（诚信之星、交易达人、宝藏卖家）  
✅ **即时聊天**：WebSocket 实时私信  
✅ **社区互动**：发帖、评论、点赞、通知中心  

## 技术栈

- **前端**：Vue 3 + Vue Router + Vite
- **后端**：Flask + Flask-SocketIO
- **存储**：浏览器 localStorage（无数据库）

## 快速启动

### 后端启动

```bash
cd backend
pip install -r requirements.txt
python app.py
```

后端将运行在 `http://localhost:5000`

### 前端启动

```bash
cd frontend
Set-ExecutionPolicy -ExecutionPolicy Bypass -Scope Process
npm install
npm run dev
```

前端将运行在 `http://localhost:5173`

## 项目结构

```
app1/
├── backend/              # Flask 后端
│   ├── app.py           # 主应用（REST API + WebSocket）
│   └── requirements.txt # Python 依赖
├── frontend/            # Vue 前端
│   ├── src/
│   │   ├── components/  # 组件
│   │   ├── views/       # 页面
│   │   ├── router/      # 路由
│   │   ├── utils/       # 工具函数
│   │   ├── stores/      # localStorage 管理
│   │   ├── App.vue      # 根组件
│   │   └── main.js      # 入口文件
│   ├── index.html
│   ├── package.json
│   └── vite.config.js
└── 需求.md              # 详细需求文档
```

## 演示脚本

1. 注册账号（学号、姓名、院系、密码）
2. 上传校园卡照片，点击"识别（演示）"
3. 拍摄人脸照片完成认证
4. 发布商品，点击"生成建议价"
5. 浏览商品、收藏、查看推荐
6. 发起交易、完成交易、互评
7. 查看信用分与头衔
8. 使用即时聊天功能
9. 社区发帖互动

## 已知限制

- OCR 和人脸识别为演示实现
- WebSocket 消息不持久化（可选前端留痕）
- 数据存储在浏览器，清除缓存会丢失
- 建议先点击"生成样本数据"以获得更好的演示效果

## 开发者

课程 Demo 项目 - 仅用于教学演示

