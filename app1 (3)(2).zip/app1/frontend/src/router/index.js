import { createRouter, createWebHistory } from 'vue-router'
import { getSession, getCurrentUser } from '../utils/storage.js'

const routes = [
  {
    path: '/auth',
    name: 'Auth',
    component: () => import('../views/AuthPage.vue'),
    meta: { requiresGuest: true }
  },
  {
    path: '/profile-setup',
    name: 'ProfileSetup',
    component: () => import('../views/ProfileSetupPage.vue'),
    meta: { requiresAuth: true }
  },
  {
    path: '/',
    redirect: '/market'
  },
  {
    path: '/market',
    name: 'Market',
    component: () => import('../views/MarketPage.vue'),
    meta: { requiresAuth: true }
  },
  {
    path: '/publish',
    name: 'Publish',
    component: () => import('../views/PublishPage.vue'),
    meta: { requiresAuth: true, requiresVerified: true }
  },
  {
    path: '/item/:id',
    name: 'ItemDetail',
    component: () => import('../views/ItemDetailPage.vue'),
    meta: { requiresAuth: true }
  },
  {
    path: '/deal',
    name: 'Deal',
    component: () => import('../views/DealPage.vue'),
    meta: { requiresAuth: true, requiresVerified: true }
  },
  {
    path: '/order/:id',
    name: 'Order',
    component: () => import('../views/OrderPage.vue'),
    meta: { requiresAuth: true, requiresVerified: true }
  },
  {
    path: '/rating/:dealId',
    name: 'Rating',
    component: () => import('../views/RatingPage.vue'),
    meta: { requiresAuth: true }
  },
  {
    path: '/chat/:dealId',
    name: 'Chat',
    component: () => import('../views/ChatPage.vue'),
    meta: { requiresAuth: true }
  },
  {
    path: '/center',
    name: 'Center',
    component: () => import('../views/CenterPage.vue'),
    meta: { requiresAuth: true }
  },
  {
    path: '/community',
    name: 'Community',
    component: () => import('../views/CommunityPage.vue'),
    meta: { requiresAuth: true }
  },
  {
    path: '/me',
    name: 'Me',
    component: () => import('../views/MePage.vue'),
    meta: { requiresAuth: true }
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

// 路由守卫
router.beforeEach((to, from, next) => {
  const session = getSession()
  const currentUser = getCurrentUser()
  
  // 需要登录的页面
  if (to.meta.requiresAuth) {
    if (!session || !currentUser) {
      next('/auth')
      return
    }
    
    // 需要完成人脸验证的页面
    if (to.meta.requiresVerified && !currentUser.faceVerified) {
      alert('请先完成人脸验证和学籍认证！')
      next('/auth')
      return
    }
  }
  
  // 只允许游客访问的页面（如登录页）
  if (to.meta.requiresGuest && session) {
    next('/market')
    return
  }
  
  next()
})

export default router

