﻿/**
 * localStorage 工具函数
 * 所有数据以 CRD_ 前缀存储
 */

// ==================== 通用工具 ====================

/**
 * 获取 localStorage 数据
 */
export function getStorage(key) {
  try {
    const data = localStorage.getItem(key)
    return data ? JSON.parse(data) : null
  } catch (error) {
    console.error(`读取 ${key} 失败:`, error)
    return null
  }
}
export function setStorage(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value))
    return true
  } catch (error) {
    console.error(`存储 ${key} 失败:`, error)
    // 如果是存储空间不足的错误
    if (error.name === 'QuotaExceededError' || error.code === 22) {
      alert('存储空间不足！建议:\n1. 减少上传图片的数量\n2. 使用更小的图片\n3. 清理一些旧数据')
    }
    return false
  }
}

/**
 * 删除 localStorage 数据
 */
export function removeStorage(key) {
  try {
    localStorage.removeItem(key)
    return true
  } catch (error) {
    console.error(`删除 ${key} 失败:`, error)
    return false
  }
}

/**
 * 清空所有 CRD_ 开头的数据
 */
export function clearAllData() {
  const keys = Object.keys(localStorage).filter(key => key.startsWith('CRD_'))
  keys.forEach(key => localStorage.removeItem(key))
  console.log('已清空所有数据')
}

/**
 * 生成唯一 ID
 */
export function generateId() {
  return `${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
}

// ==================== 用户相关 ====================

export function getUsers() {
  return getStorage('CRD_USERS') || []
}

export function setUsers(users) {
  return setStorage('CRD_USERS', users)
}

export function addUser(user) {
  const users = getUsers()
  const newUser = {
    id: generateId(),
    buyerCredit: 100, // 买家信用分
    sellerCredit: 100, // 卖家信用分
    credit: 100, // 兼容旧版本，默认使用卖家信用分
    faceVerified: false,
    createdAt: Date.now(),
    ...user // 放在后面，这样可以覆盖默认值
  }
  users.push(newUser)
  setUsers(users)
  return newUser
}

export function updateUser(userId, updates) {
  const users = getUsers()
  const index = users.findIndex(u => u.id === userId)
  if (index !== -1) {
    users[index] = { ...users[index], ...updates }
    setUsers(users)
    return users[index]
  }
  return null
}

export function getUserById(userId) {
  const users = getUsers()
  return users.find(u => u.id === userId)
}

export function getUserByStudentId(studentId) {
  const users = getUsers()
  return users.find(u => u.studentId === studentId)
}

// ==================== 会话相关 ====================

export function getSession() {
  return getStorage('CRD_SESSION')
}

export function setSession(session) {
  return setStorage('CRD_SESSION', session)
}

export function clearSession() {
  return removeStorage('CRD_SESSION')
}

export function getCurrentUser() {
  const session = getSession()
  if (!session) return null
  return getUserById(session.userId)
}

// ==================== 商品相关 ====================

export function getItems() {
  return getStorage('CRD_ITEMS') || []
}

export function setItems(items) {
  return setStorage('CRD_ITEMS', items)
}

export function addItem(item) {
  const items = getItems()
  const newItem = {
    ...item,
    id: generateId(),
    status: 'ACTIVE', // ACTIVE, SOLD, REMOVED
    createdAt: Date.now()
  }
  items.push(newItem)
  setItems(items)
  return newItem
}

export function updateItem(itemId, updates) {
  const items = getItems()
  const index = items.findIndex(i => i.id === itemId)
  if (index !== -1) {
    items[index] = { ...items[index], ...updates }
    setItems(items)
    return items[index]
  }
  return null
}

export function getItemById(itemId) {
  const items = getItems()
  return items.find(i => i.id === itemId)
}

// ==================== 收藏相关 ====================

export function getFavorites() {
  return getStorage('CRD_FAVS') || []
}

export function setFavorites(favs) {
  return setStorage('CRD_FAVS', favs)
}

export function addFavorite(userId, itemId) {
  const favs = getFavorites()
  if (!favs.find(f => f.userId === userId && f.itemId === itemId)) {
    favs.push({ userId, itemId, createdAt: Date.now() })
    setFavorites(favs)
  }
}

export function removeFavorite(userId, itemId) {
  const favs = getFavorites()
  const filtered = favs.filter(f => !(f.userId === userId && f.itemId === itemId))
  setFavorites(filtered)
}

export function isFavorited(userId, itemId) {
  const favs = getFavorites()
  return favs.some(f => f.userId === userId && f.itemId === itemId)
}

export function getUserFavorites(userId) {
  const favs = getFavorites()
  return favs.filter(f => f.userId === userId)
}

// ==================== 浏览记录 ====================

export function getViews() {
  return getStorage('CRD_VIEWS') || []
}

export function setViews(views) {
  return setStorage('CRD_VIEWS', views)
}

export function addView(userId, itemId) {
  const views = getViews()
  views.push({ userId, itemId, ts: Date.now() })
  setViews(views)
}

export function getUserViews(userId) {
  const views = getViews()
  return views.filter(v => v.userId === userId)
}

// ==================== 交易相关 ====================

export function getDeals() {
  return getStorage('CRD_DEALS') || []
}

export function setDeals(deals) {
  return setStorage('CRD_DEALS', deals)
}

export function addDeal(deal) {
  const deals = getDeals()
  const newDeal = {
    ...deal,
    id: generateId(),
    status: 'INTENT', // INTENT, DONE, CANCELLED
    createdAt: Date.now()
  }
  deals.push(newDeal)
  setDeals(deals)
  return newDeal
}

export function updateDeal(dealId, updates) {
  const deals = getDeals()
  const index = deals.findIndex(d => d.id === dealId)
  if (index !== -1) {
    deals[index] = { ...deals[index], ...updates }
    setDeals(deals)
    return deals[index]
  }
  return null
}

export function getDealById(dealId) {
  const deals = getDeals()
  return deals.find(d => d.id === dealId)
}

// ==================== 评分相关 ====================

export function getRatings() {
  return getStorage('CRD_RATINGS') || []
}

export function setRatings(ratings) {
  return setStorage('CRD_RATINGS', ratings)
}

export function addOrUpdateRating(rating) {
  const ratings = getRatings()
  const index = ratings.findIndex(r => r.dealId === rating.dealId && r.raterId === rating.raterId)
  
  if (index !== -1) {
    // 更新现有评分
    ratings[index] = { ...ratings[index], ...rating, updatedAt: Date.now() }
  } else {
    // 新增评分
    ratings.push({ ...rating, createdAt: Date.now() })
  }
  
  setRatings(ratings)
  return ratings[index] || ratings[ratings.length - 1]
}

export function getRatingsByDeal(dealId) {
  const ratings = getRatings()
  return ratings.filter(r => r.dealId === dealId)
}

// ==================== 信用日志 ====================

export function getCreditLogs() {
  return getStorage('CRD_CREDIT_LOGS') || []
}

export function setCreditLogs(logs) {
  return setStorage('CRD_CREDIT_LOGS', logs)
}

export function addCreditLog(log) {
  const logs = getCreditLogs()
  logs.push({
    ...log,
    id: generateId(),
    createdAt: Date.now()
  })
  setCreditLogs(logs)
}

export function getUserCreditLogs(userId) {
  const logs = getCreditLogs()
  return logs.filter(l => l.userId === userId).sort((a, b) => b.createdAt - a.createdAt)
}

// ==================== 定价日志 ====================

export function getPriceLogs() {
  return getStorage('CRD_PRICE_LOGS') || []
}

export function setPriceLogs(logs) {
  return setStorage('CRD_PRICE_LOGS', logs)
}

export function addPriceLog(log) {
  const logs = getPriceLogs()
  logs.push({
    ...log,
    id: generateId(),
    createdAt: Date.now()
  })
  setPriceLogs(logs)
}

// ==================== 社区相关 ====================

export function getPosts() {
  return getStorage('CRD_POSTS') || []
}

export function setPosts(posts) {
  return setStorage('CRD_POSTS', posts)
}

export function addPost(post) {
  const posts = getPosts()
  const newPost = {
    ...post,
    id: generateId(),
    createdAt: Date.now()
  }
  posts.push(newPost)
  setPosts(posts)
  return newPost
}

export function getComments() {
  return getStorage('CRD_COMMENTS') || []
}

export function setComments(comments) {
  return setStorage('CRD_COMMENTS', comments)
}

export function addComment(comment) {
  const comments = getComments()
  comments.push({
    ...comment,
    id: generateId(),
    createdAt: Date.now()
  })
  setComments(comments)
}

export function getLikes() {
  return getStorage('CRD_LIKES') || []
}

export function setLikes(likes) {
  return setStorage('CRD_LIKES', likes)
}

export function toggleLike(userId, postId) {
  const likes = getLikes()
  const index = likes.findIndex(l => l.userId === userId && l.postId === postId)
  
  if (index !== -1) {
    likes.splice(index, 1)
  } else {
    likes.push({ userId, postId, createdAt: Date.now() })
  }
  
  setLikes(likes)
  return index === -1 // 返回是否点赞
}

// ==================== 通知相关 ====================

export function getNotices() {
  return getStorage('CRD_NOTICES') || []
}

export function setNotices(notices) {
  return setStorage('CRD_NOTICES', notices)
}

export function addNotice(notice) {
  const notices = getNotices()
  notices.unshift({
    ...notice,
    id: generateId(),
    read: false,
    createdAt: Date.now()
  })
  setNotices(notices)
}

export function markNoticeAsRead(noticeId) {
  const notices = getNotices()
  const index = notices.findIndex(n => n.id === noticeId)
  if (index !== -1) {
    notices[index].read = true
    setNotices(notices)
  }
}

export function getUserNotices(userId) {
  const notices = getNotices()
  return notices.filter(n => n.userId === userId).sort((a, b) => b.createdAt - a.createdAt)
}

// ==================== 消息模板 ====================

export function getTemplates() {
  return getStorage('CRD_TEMPLATES') || []
}

export function setTemplates(templates) {
  return setStorage('CRD_TEMPLATES', templates)
}

export function addTemplate(template) {
  const templates = getTemplates()
  templates.push({
    ...template,
    id: generateId(),
    createdAt: Date.now()
  })
  setTemplates(templates)
}

// ==================== 消息留痕（可选）====================

export function getMessages() {
  return getStorage('CRD_MESSAGES') || []
}

export function setMessages(messages) {
  return setStorage('CRD_MESSAGES', messages)
}

export function addMessage(message) {
  const messages = getMessages()
  messages.push({
    ...message,
    id: generateId(),
    timestamp: Date.now()
  })
  setMessages(messages)
}

export function getDealMessages(dealId) {
  const messages = getMessages()
  return messages.filter(m => m.dealId === dealId).sort((a, b) => a.timestamp - b.timestamp)
}

