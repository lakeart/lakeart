/**
 * 智能推荐算法
 */

import { getItems, getUserViews, getUserFavorites, getDeals, getUsers, getUserById } from './storage.js'

/**
 * 计算用户的标签权重（增强版：结合用户兴趣）
 */
export function getUserTagWeights(userId) {
  const views = getUserViews(userId)
  const favs = getUserFavorites(userId)
  const deals = getDeals().filter(d => d.buyerId === userId && d.status === 'DONE')
  const items = getItems()
  const user = getUserById(userId)
  
  const tagCounter = {}
  
  // 用户兴趣标签（基础权重：5倍）
  if (user && user.interests && user.interests.length > 0) {
    user.interests.forEach(interest => {
      tagCounter[interest] = (tagCounter[interest] || 0) + 5
    })
  }
  
  // 收藏权重最高 (3倍)
  favs.forEach(fav => {
    const item = items.find(i => i.id === fav.itemId)
    if (item && item.tags) {
      item.tags.forEach(tag => {
        tagCounter[tag] = (tagCounter[tag] || 0) + 3
      })
    }
  })
  
  // 购买过的权重次之 (2倍)
  deals.forEach(deal => {
    const item = items.find(i => i.id === deal.itemId)
    if (item && item.tags) {
      item.tags.forEach(tag => {
        tagCounter[tag] = (tagCounter[tag] || 0) + 2
      })
    }
  })
  
  // 浏览过的权重最低 (1倍)
  views.forEach(view => {
    const item = items.find(i => i.id === view.itemId)
    if (item && item.tags) {
      item.tags.forEach(tag => {
        tagCounter[tag] = (tagCounter[tag] || 0) + 1
      })
    }
  })
  
  return tagCounter
}

/**
 * 计算用户的价格中位数
 */
export function getUserMedianPrice(userId) {
  const views = getUserViews(userId)
  const favs = getUserFavorites(userId)
  const items = getItems()
  
  const prices = []
  
  // 收集收藏和浏览的商品价格
  ;[...favs, ...views].forEach(record => {
    const item = items.find(i => i.id === record.itemId)
    if (item && item.price) {
      prices.push(item.price)
    }
  })
  
  if (prices.length === 0) return 100 // 默认价格
  
  prices.sort((a, b) => a - b)
  const mid = Math.floor(prices.length / 2)
  return prices.length % 2 === 0 
    ? (prices[mid - 1] + prices[mid]) / 2 
    : prices[mid]
}

/**
 * 找出相似用户
 */
export function getSimilarUsers(userId, limit = 5) {
  const users = getUsers()
  const myFavs = getUserFavorites(userId)
  const myFavItemIds = new Set(myFavs.map(f => f.itemId))
  
  if (myFavItemIds.size === 0) return []
  
  const similarities = []
  
  users.forEach(user => {
    if (user.id === userId) return
    
    const theirFavs = getUserFavorites(user.id)
    const theirFavItemIds = new Set(theirFavs.map(f => f.itemId))
    
    // 计算 Jaccard 相似度
    const intersection = [...myFavItemIds].filter(id => theirFavItemIds.has(id)).length
    const union = new Set([...myFavItemIds, ...theirFavItemIds]).size
    
    if (union > 0 && intersection > 0) {
      similarities.push({
        userId: user.id,
        score: intersection / union
      })
    }
  })
  
  return similarities
    .sort((a, b) => b.score - a.score)
    .slice(0, limit)
}

/**
 * 获取推荐商品（增强版：关联用户兴趣和个人信息）
 */
export function getRecommendedItems(userId, mode = 'mixed') {
  const currentUser = getUserById(userId)
  if (!currentUser) return []
  
  const items = getItems().filter(i => i.status === 'ACTIVE' && i.sellerId !== userId)
  const views = getUserViews(userId)
  const favs = getUserFavorites(userId)
  const viewedItemIds = new Set(views.map(v => v.itemId))
  const favItemIds = new Set(favs.map(f => f.itemId))
  
  // 候选商品（未浏览过的）
  let candidates = items.filter(item => !viewedItemIds.has(item.id))
  
  if (candidates.length === 0) {
    // 如果没有未浏览的，返回最新的商品
    return items
      .sort((a, b) => b.createdAt - a.createdAt)
      .slice(0, 20)
  }
  
  // 基于标签推荐
  if (mode === 'tag' || mode === 'mixed') {
    const tagWeights = getUserTagWeights(userId)
    const medianPrice = getUserMedianPrice(userId)
    
    candidates = candidates.map(item => {
      let score = 0
      
      // 标签权重得分（包含用户兴趣）
      if (item.tags) {
        item.tags.forEach(tag => {
          score += (tagWeights[tag] || 0)
        })
      }
      
      // 用户兴趣标签直接匹配加分
      if (currentUser.interests && currentUser.interests.length > 0) {
        if (currentUser.interests.includes(item.category)) {
          score += 8 // 类别匹配兴趣，高分
        }
        if (item.tags) {
          item.tags.forEach(tag => {
            if (currentUser.interests.includes(tag)) {
              score += 6 // 标签匹配兴趣
            }
          })
        }
      }
      
      // 价格相近得分
      const priceDiff = Math.abs(item.price - medianPrice)
      const priceScore = 1 / (1 + priceDiff / Math.max(50, medianPrice * 0.2))
      score += priceScore * 5 // 价格相近权重
      
      // 同院系加权
      const seller = getUserById(item.sellerId)
      if (seller && seller.department === currentUser.department) {
        score += 2
      }
      
      // 同学院加权（如果有学院信息）
      if (seller && currentUser.college && seller.college === currentUser.college) {
        score += 1.5
      }
      
      // 同专业加权（如果有专业信息）
      if (seller && currentUser.major && seller.major === currentUser.major) {
        score += 1
      }
      
      // 性别相关推荐（某些类别）
      if (currentUser.gender && seller.gender) {
        const genderRelatedCategories = ['服装', '美妆', '运动器材']
        if (genderRelatedCategories.includes(item.category)) {
          if (currentUser.gender === seller.gender) {
            score += 0.5 // 同性别略微加分
          }
        }
      }
      
      return { ...item, score }
    })
  }
  
  // 基于相似用户推荐
  if (mode === 'collaborative' || mode === 'mixed') {
    const similarUsers = getSimilarUsers(userId)
    const collaborativeItemIds = new Set()
    
    similarUsers.forEach(simUser => {
      const theirFavs = getUserFavorites(simUser.userId)
      theirFavs.forEach(fav => {
        if (!viewedItemIds.has(fav.itemId) && !favItemIds.has(fav.itemId)) {
          collaborativeItemIds.add(fav.itemId)
        }
      })
    })
    
    // 给协同过滤的商品加分
    candidates = candidates.map(item => {
      const bonus = collaborativeItemIds.has(item.id) ? 3 : 0
      return {
        ...item,
        score: (item.score || 0) + bonus
      }
    })
  }
  
  // 排序并返回
  return candidates
    .sort((a, b) => (b.score || 0) - (a.score || 0))
    .slice(0, 20)
}

/**
 * 获取同类同价商品（详情页推荐）
 */
export function getSimilarItems(itemId, limit = 8) {
  const targetItem = getItems().find(i => i.id === itemId)
  if (!targetItem) return []
  
  const items = getItems().filter(i => 
    i.id !== itemId && 
    i.status === 'ACTIVE' &&
    i.category === targetItem.category
  )
  
  // 计算价格区间 (±20%)
  const minPrice = targetItem.price * 0.8
  const maxPrice = targetItem.price * 1.2
  
  const filtered = items.filter(i => i.price >= minPrice && i.price <= maxPrice)
  
  // 按价格接近度排序
  return filtered
    .map(item => ({
      ...item,
      priceDiff: Math.abs(item.price - targetItem.price)
    }))
    .sort((a, b) => a.priceDiff - b.priceDiff)
    .slice(0, limit)
}

