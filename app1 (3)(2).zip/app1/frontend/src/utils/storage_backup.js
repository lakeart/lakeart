﻿/**
聽* localStorage 宸ュ叿鍑芥暟
聽* 鎵€鏈夋暟鎹互 CRD_ 鍓嶇紑瀛樺偍
聽*/

// ==================== 閫氱敤宸ュ叿 ====================

/**
聽* 鑾峰彇 localStorage 鏁版嵁
聽*/
export function getStorage(key) {
聽 try {
聽 聽 const data = localStorage.getItem(key)
聽 聽 return data ? JSON.parse(data) : null
聽 } catch (error) {
聽 聽 console.error(`璇诲彇 ${key} 澶辫触:`, error)
聽 聽 return null
聽 }
}

/**
聽* 璁剧疆 localStorage 鏁版嵁
聽*/
export function setStorage(key, value) {
聽 try {
聽 聽 localStorage.setItem(key, JSON.stringify(value))
聽 聽 return true
聽 } catch (error) {
聽 聽 console.error(`瀛樺偍 ${key} 澶辫触:`, error)
聽 聽 return false
聽 }
}

/**
聽* 鍒犻櫎 localStorage 鏁版嵁
聽*/
export function removeStorage(key) {
聽 try {
聽 聽 localStorage.removeItem(key)
聽 聽 return true
聽 } catch (error) {
聽 聽 console.error(`鍒犻櫎 ${key} 澶辫触:`, error)
聽 聽 return false
聽 }
}

/**
聽* 娓呯┖鎵€鏈?CRD_ 寮€澶寸殑鏁版嵁
聽*/
export function clearAllData() {
聽 const keys = Object.keys(localStorage).filter(key => key.startsWith('CRD_'))
聽 keys.forEach(key => localStorage.removeItem(key))
聽 console.log('宸叉竻绌烘墍鏈夋暟鎹?)
}

/**
聽* 鐢熸垚鍞竴 ID
聽*/
export function generateId() {
聽 return `${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
}

// ==================== 鐢ㄦ埛鐩稿叧 ====================

export function getUsers() {
聽 return getStorage('CRD_USERS') || []
}

export function setUsers(users) {
聽 return setStorage('CRD_USERS', users)
}

export function addUser(user) {
聽 const users = getUsers()
聽 const newUser = {
聽 聽 id: generateId(),
聽 聽 buyerCredit: 100, // 涔板淇＄敤鍒?
聽 聽 sellerCredit: 100, // 鍗栧淇＄敤鍒?
聽 聽 credit: 100, // 鍏煎鏃х増鏈紝榛樿浣跨敤鍗栧淇＄敤鍒?
聽 聽 faceVerified: false,
聽 聽 createdAt: Date.now(),
聽 聽 ...user // 鏀惧湪鍚庨潰锛岃繖鏍峰彲浠ヨ鐩栭粯璁ゅ€?
聽 }
聽 users.push(newUser)
聽 setUsers(users)
聽 return newUser
}

export function updateUser(userId, updates) {
聽 const users = getUsers()
聽 const index = users.findIndex(u => u.id === userId)
聽 if (index !== -1) {
聽 聽 users[index] = { ...users[index], ...updates }
聽 聽 setUsers(users)
聽 聽 return users[index]
聽 }
聽 return null
}

export function getUserById(userId) {
聽 const users = getUsers()
聽 return users.find(u => u.id === userId)
}

export function getUserByStudentId(studentId) {
聽 const users = getUsers()
聽 return users.find(u => u.studentId === studentId)
}

// ==================== 浼氳瘽鐩稿叧 ====================

export function getSession() {
聽 return getStorage('CRD_SESSION')
}

export function setSession(session) {
聽 return setStorage('CRD_SESSION', session)
}

export function clearSession() {
聽 return removeStorage('CRD_SESSION')
}

export function getCurrentUser() {
聽 const session = getSession()
聽 if (!session) return null
聽 return getUserById(session.userId)
}

// ==================== 鍟嗗搧鐩稿叧 ====================

export function getItems() {
聽 return getStorage('CRD_ITEMS') || []
}

export function setItems(items) {
聽 return setStorage('CRD_ITEMS', items)
}

export function addItem(item) {
聽 const items = getItems()
聽 const newItem = {
聽 聽 ...item,
聽 聽 id: generateId(),
聽 聽 status: 'ACTIVE', // ACTIVE, SOLD, REMOVED
聽 聽 createdAt: Date.now()
聽 }
聽 items.push(newItem)
聽 setItems(items)
聽 return newItem
}

export function updateItem(itemId, updates) {
聽 const items = getItems()
聽 const index = items.findIndex(i => i.id === itemId)
聽 if (index !== -1) {
聽 聽 items[index] = { ...items[index], ...updates }
聽 聽 setItems(items)
聽 聽 return items[index]
聽 }
聽 return null
}

export function getItemById(itemId) {
聽 const items = getItems()
聽 return items.find(i => i.id === itemId)
}

// ==================== 鏀惰棌鐩稿叧 ====================

export function getFavorites() {
聽 return getStorage('CRD_FAVS') || []
}

export function setFavorites(favs) {
聽 return setStorage('CRD_FAVS', favs)
}

export function addFavorite(userId, itemId) {
聽 const favs = getFavorites()
聽 if (!favs.find(f => f.userId === userId && f.itemId === itemId)) {
聽 聽 favs.push({ userId, itemId, createdAt: Date.now() })
聽 聽 setFavorites(favs)
聽 }
}

export function removeFavorite(userId, itemId) {
聽 const favs = getFavorites()
聽 const filtered = favs.filter(f => !(f.userId === userId && f.itemId === itemId))
聽 setFavorites(filtered)
}

export function isFavorited(userId, itemId) {
聽 const favs = getFavorites()
聽 return favs.some(f => f.userId === userId && f.itemId === itemId)
}

export function getUserFavorites(userId) {
聽 const favs = getFavorites()
聽 return favs.filter(f => f.userId === userId)
}

// ==================== 娴忚璁板綍 ====================

export function getViews() {
聽 return getStorage('CRD_VIEWS') || []
}

export function setViews(views) {
聽 return setStorage('CRD_VIEWS', views)
}

export function addView(userId, itemId) {
聽 const views = getViews()
聽 views.push({ userId, itemId, ts: Date.now() })
聽 setViews(views)
}

export function getUserViews(userId) {
聽 const views = getViews()
聽 return views.filter(v => v.userId === userId)
}

// ==================== 浜ゆ槗鐩稿叧 ====================

export function getDeals() {
聽 return getStorage('CRD_DEALS') || []
}

export function setDeals(deals) {
聽 return setStorage('CRD_DEALS', deals)
}

export function addDeal(deal) {
聽 const deals = getDeals()
聽 const newDeal = {
聽 聽 ...deal,
聽 聽 id: generateId(),
聽 聽 status: 'INTENT', // INTENT, DONE, CANCELLED
聽 聽 createdAt: Date.now()
聽 }
聽 deals.push(newDeal)
聽 setDeals(deals)
聽 return newDeal
}

export function updateDeal(dealId, updates) {
聽 const deals = getDeals()
聽 const index = deals.findIndex(d => d.id === dealId)
聽 if (index !== -1) {
聽 聽 deals[index] = { ...deals[index], ...updates }
聽 聽 setDeals(deals)
聽 聽 return deals[index]
聽 }
聽 return null
}

export function getDealById(dealId) {
聽 const deals = getDeals()
聽 return deals.find(d => d.id === dealId)
}

// ==================== 璇勫垎鐩稿叧 ====================

export function getRatings() {
聽 return getStorage('CRD_RATINGS') || []
}

export function setRatings(ratings) {
聽 return setStorage('CRD_RATINGS', ratings)
}

export function addOrUpdateRating(rating) {
聽 const ratings = getRatings()
聽 const index = ratings.findIndex(r => r.dealId === rating.dealId && r.raterId === rating.raterId)
聽 
聽 if (index !== -1) {
聽 聽 // 鏇存柊鐜版湁璇勫垎
聽 聽 ratings[index] = { ...ratings[index], ...rating, updatedAt: Date.now() }
聽 } else {
聽 聽 // 鏂板璇勫垎
聽 聽 ratings.push({ ...rating, createdAt: Date.now() })
聽 }
聽 
聽 setRatings(ratings)
聽 return ratings[index] || ratings[ratings.length - 1]
}

export function getRatingsByDeal(dealId) {
聽 const ratings = getRatings()
聽 return ratings.filter(r => r.dealId === dealId)
}

// ==================== 淇＄敤鏃ュ織 ====================

export function getCreditLogs() {
聽 return getStorage('CRD_CREDIT_LOGS') || []
}

export function setCreditLogs(logs) {
聽 return setStorage('CRD_CREDIT_LOGS', logs)
}

export function addCreditLog(log) {
聽 const logs = getCreditLogs()
聽 logs.push({
聽 聽 ...log,
聽 聽 id: generateId(),
聽 聽 createdAt: Date.now()
聽 })
聽 setCreditLogs(logs)
}

export function getUserCreditLogs(userId) {
聽 const logs = getCreditLogs()
聽 return logs.filter(l => l.userId === userId).sort((a, b) => b.createdAt - a.createdAt)
}

// ==================== 瀹氫环鏃ュ織 ====================

export function getPriceLogs() {
聽 return getStorage('CRD_PRICE_LOGS') || []
}

export function setPriceLogs(logs) {
聽 return setStorage('CRD_PRICE_LOGS', logs)
}

export function addPriceLog(log) {
聽 const logs = getPriceLogs()
聽 logs.push({
聽 聽 ...log,
聽 聽 id: generateId(),
聽 聽 createdAt: Date.now()
聽 })
聽 setPriceLogs(logs)
}

// ==================== 绀惧尯鐩稿叧 ====================

export function getPosts() {
聽 return getStorage('CRD_POSTS') || []
}

export function setPosts(posts) {
聽 return setStorage('CRD_POSTS', posts)
}

export function addPost(post) {
聽 const posts = getPosts()
聽 const newPost = {
聽 聽 ...post,
聽 聽 id: generateId(),
聽 聽 createdAt: Date.now()
聽 }
聽 posts.push(newPost)
聽 setPosts(posts)
聽 return newPost
}

export function getComments() {
聽 return getStorage('CRD_COMMENTS') || []
}

export function setComments(comments) {
聽 return setStorage('CRD_COMMENTS', comments)
}

export function addComment(comment) {
聽 const comments = getComments()
聽 comments.push({
聽 聽 ...comment,
聽 聽 id: generateId(),
聽 聽 createdAt: Date.now()
聽 })
聽 setComments(comments)
}

export function getLikes() {
聽 return getStorage('CRD_LIKES') || []
}

export function setLikes(likes) {
聽 return setStorage('CRD_LIKES', likes)
}

export function toggleLike(userId, postId) {
聽 const likes = getLikes()
聽 const index = likes.findIndex(l => l.userId === userId && l.postId === postId)
聽 
聽 if (index !== -1) {
聽 聽 likes.splice(index, 1)
聽 } else {
聽 聽 likes.push({ userId, postId, createdAt: Date.now() })
聽 }
聽 
聽 setLikes(likes)
聽 return index === -1 // 杩斿洖鏄惁鐐硅禐
}

// ==================== 閫氱煡鐩稿叧 ====================

export function getNotices() {
聽 return getStorage('CRD_NOTICES') || []
}

export function setNotices(notices) {
聽 return setStorage('CRD_NOTICES', notices)
}

export function addNotice(notice) {
聽 const notices = getNotices()
聽 notices.unshift({
聽 聽 ...notice,
聽 聽 id: generateId(),
聽 聽 read: false,
聽 聽 createdAt: Date.now()
聽 })
聽 setNotices(notices)
}

export function markNoticeAsRead(noticeId) {
聽 const notices = getNotices()
聽 const index = notices.findIndex(n => n.id === noticeId)
聽 if (index !== -1) {
聽 聽 notices[index].read = true
聽 聽 setNotices(notices)
聽 }
}

export function getUserNotices(userId) {
聽 const notices = getNotices()
聽 return notices.filter(n => n.userId === userId).sort((a, b) => b.createdAt - a.createdAt)
}

// ==================== 娑堟伅妯℃澘 ====================

export function getTemplates() {
聽 return getStorage('CRD_TEMPLATES') || []
}

export function setTemplates(templates) {
聽 return setStorage('CRD_TEMPLATES', templates)
}

export function addTemplate(template) {
聽 const templates = getTemplates()
聽 templates.push({
聽 聽 ...template,
聽 聽 id: generateId(),
聽 聽 createdAt: Date.now()
聽 })
聽 setTemplates(templates)
}

// ==================== 娑堟伅鐣欑棔锛堝彲閫夛級====================

export function getMessages() {
聽 return getStorage('CRD_MESSAGES') || []
}

export function setMessages(messages) {
聽 return setStorage('CRD_MESSAGES', messages)
}

export function addMessage(message) {
聽 const messages = getMessages()
聽 messages.push({
聽 聽 ...message,
聽 聽 id: generateId(),
聽 聽 timestamp: Date.now()
聽 })
聽 setMessages(messages)
}

export function getDealMessages(dealId) {
聽 const messages = getMessages()
聽 return messages.filter(m => m.dealId === dealId).sort((a, b) => a.timestamp - b.timestamp)
}


