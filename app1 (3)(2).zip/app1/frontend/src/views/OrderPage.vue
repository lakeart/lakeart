<template>
  <div class="order-page">
    <div class="page-header">
      <button class="btn-back" @click="goBack">
        <span>←</span>
      </button>
      <h1>确认订单</h1>
      <div></div>
    </div>

    <div v-if="item" class="order-container">
      <!-- 商品信息 -->
      <div class="order-item">
        <img :src="item.images?.[0] || 'https://via.placeholder.com/100'" :alt="item.title">
        <div class="item-info">
          <div class="item-title">{{ item.title }}</div>
          <div class="item-seller">{{ getSellerName(item.sellerId) }}</div>
        </div>
        <div class="item-price">
          ¥{{ item.price }}
          <span class="quantity">x1</span>
        </div>
      </div>

      <!-- 收货地址 -->
      <div class="address-section">
        <div class="section-header">
          <h3>收货地址</h3>
          <button class="btn-edit" @click="editAddress">修改</button>
        </div>
        <div class="address-content" v-if="!isEditingAddress">
          <div class="address-name">{{ currentUser.name }} {{ hiddenPhone }}</div>
          <div class="address-detail">{{ deliveryAddress }}</div>
        </div>
        <div class="address-form" v-else>
          <textarea 
            v-model="tempAddress" 
            placeholder="请输入收货地址（如：XX大学XX校区XX栋XX楼XX室）"
            rows="3"
          ></textarea>
          <div class="form-actions">
            <button class="btn-cancel" @click="cancelEdit">取消</button>
            <button class="btn-save" @click="saveAddress">保存</button>
          </div>
        </div>
      </div>

      <!-- 费用明细 -->
      <div class="fee-section">
        <h3>费用明细</h3>
        <div class="fee-item">
          <span>商品金额</span>
          <span>¥{{ item.price }}</span>
        </div>
        <!-- <div class="fee-item">
          <span>配送费</span>
          <span>¥0.00</span>
        </div> -->
      </div>

      <!-- 底部合计 -->
      <div class="order-footer">
        <div class="total-section">
          <span class="total-label">合计：</span>
          <span class="total-price">¥{{ item.price }}</span>
        </div>
        <button class="btn-pay" @click="confirmOrder">
          确认支付
        </button>
      </div>
    </div>

    <div v-else class="empty-state">
      <p>商品不存在</p>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { 
  getItemById, getCurrentUser, getUserById, 
  addDeal, addNotice, updateUser, updateItem 
} from '../utils/storage.js'

const router = useRouter()
const route = useRoute()

const currentUser = ref(null)
const item = ref(null)
const isEditingAddress = ref(false)
const tempAddress = ref('')

// 收货地址（从用户信息中获取，如果没有则使用默认值）
const deliveryAddress = computed(() => {
  if (currentUser.value?.deliveryAddress) {
    return currentUser.value.deliveryAddress
  }
  return `XX大学${currentUser.value?.department}XX宿舍楼XX室`
})

// 隐藏的手机号
const hiddenPhone = computed(() => {
  if (currentUser.value?.studentId) {
    const id = currentUser.value.studentId
    return `138****${id.slice(-4)}`
  }
  return '138****5678'
})

onMounted(() => {
  currentUser.value = getCurrentUser()
  const itemId = route.params.id
  
  if (!currentUser.value) {
    alert('请先登录')
    router.push('/auth')
    return
  }
  
  if (itemId) {
    item.value = getItemById(itemId)
    
    if (!item.value) {
      alert('商品不存在')
      router.push('/market')
      return
    }
    
    // 检查是否是自己的商品
    if (item.value.sellerId === currentUser.value.id) {
      alert('不能购买自己的商品')
      router.push('/market')
      return
    }
    
    // 检查商品状态
    if (item.value.status === 'SOLD') {
      alert('该商品已售出')
      router.push('/market')
      return
    }
  }
})

function getSellerName(sellerId) {
  const seller = getUserById(sellerId)
  return seller?.name || '未知卖家'
}

function goBack() {
  router.back()
}

function editAddress() {
  tempAddress.value = deliveryAddress.value
  isEditingAddress.value = true
}

function cancelEdit() {
  isEditingAddress.value = false
  tempAddress.value = ''
}

function saveAddress() {
  if (!tempAddress.value.trim()) {
    alert('请输入收货地址')
    return
  }
  
  // 更新用户的收货地址
  updateUser(currentUser.value.id, {
    deliveryAddress: tempAddress.value.trim()
  })
  
  // 重新获取当前用户信息
  currentUser.value = getCurrentUser()
  isEditingAddress.value = false
  tempAddress.value = ''
  
  alert('地址保存成功')
}

async function confirmOrder() {
  if (!item.value) return
  
  const paying = ref(false)
  
  try {
    paying.value = true
    
    // 调用支付接口（演示版）
    const response = await fetch('http://localhost:5000/api/payment/create', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        orderId: `ORD_${Date.now()}`,
        amount: item.value.price,
        itemTitle: item.value.title
      })
    })
    
    const result = await response.json()
    
    if (!result.ok) {
      throw new Error(result.message || '支付失败')
    }
    
    // 支付成功，创建交易
    const deal = addDeal({
      itemId: item.value.id,
      sellerId: item.value.sellerId,
      buyerId: currentUser.value.id,
      status: 'DONE', // 支付成功后直接标记为已完成
      deliveryAddress: deliveryAddress.value,
      transactionId: result.data.transactionId
    })
    
    // 更新商品状态为已售出
    updateItem(item.value.id, { status: 'SOLD' })
    
    // 通知卖家
    addNotice({
      userId: item.value.sellerId,
      type: 'deal',
      title: '交易完成',
      content: `${currentUser.value.name} 已购买您的 ${item.value.title}，请记得确认收货并评价！`
    })
    
    // 通知买家
    addNotice({
      userId: currentUser.value.id,
      type: 'deal',
      title: '支付成功',
      content: `您已成功购买 ${item.value.title}，请记得评价卖家！`
    })
    
    alert('支付成功！\n这是演示版，无需实际支付。')
    
    // 跳转到评价页面
    router.push(`/rating/${deal.id}`)
  } catch (error) {
    console.error('支付失败:', error)
    alert(`支付失败：${error.message}\n请检查后端服务是否启动`)
  } finally {
    paying.value = false
  }
}
</script>

<style scoped>
.order-page {
  min-height: 100vh;
  background: #f5f5f5;
  padding-bottom: 80px;
}

.page-header {
  background: white;
  padding: 16px 20px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
  position: sticky;
  top: 60px;
  z-index: 100;
}

.btn-back {
  background: none;
  border: none;
  font-size: 24px;
  cursor: pointer;
  color: #333;
  padding: 0;
  width: 40px;
  height: 40px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 50%;
  transition: all 0.3s;
}

.btn-back:hover {
  background: #f5f5f5;
}

.page-header h1 {
  margin: 0;
  font-size: 18px;
  color: #333;
}

.order-container {
  max-width: 600px;
  margin: 20px auto;
  padding: 0 20px;
}

/* 商品信息 */
.order-item {
  background: white;
  border-radius: 12px;
  padding: 16px;
  display: flex;
  gap: 12px;
  margin-bottom: 12px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.08);
}

.order-item img {
  width: 80px;
  height: 80px;
  border-radius: 8px;
  object-fit: cover;
}

.item-info {
  flex: 1;
  display: flex;
  flex-direction: column;
  justify-content: center;
  min-width: 0;
}

.item-title {
  font-size: 16px;
  font-weight: 500;
  color: #333;
  margin-bottom: 8px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.item-seller {
  font-size: 14px;
  color: #999;
}

.item-price {
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  justify-content: center;
  font-size: 18px;
  font-weight: bold;
  color: #ff4757;
}

.quantity {
  font-size: 14px;
  color: #999;
  font-weight: normal;
  margin-top: 4px;
}

/* 收货地址 */
.address-section {
  background: white;
  border-radius: 12px;
  padding: 16px;
  margin-bottom: 12px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.08);
}

.section-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12px;
}

.section-header h3 {
  margin: 0;
  font-size: 16px;
  color: #333;
}

.btn-edit {
  background: none;
  border: none;
  color: #667eea;
  font-size: 14px;
  cursor: pointer;
  padding: 4px 12px;
  border-radius: 4px;
  transition: all 0.3s;
}

.btn-edit:hover {
  background: rgba(102, 126, 234, 0.1);
}

.address-content {
  padding: 12px;
  background: #f9f9f9;
  border-radius: 8px;
}

.address-name {
  font-size: 15px;
  color: #333;
  font-weight: 500;
  margin-bottom: 8px;
}

.address-detail {
  font-size: 14px;
  color: #666;
  line-height: 1.6;
}

.address-form textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ddd;
  border-radius: 8px;
  font-size: 14px;
  font-family: inherit;
  resize: vertical;
  margin-bottom: 12px;
}

.form-actions {
  display: flex;
  gap: 12px;
}

.btn-cancel,
.btn-save {
  flex: 1;
  padding: 10px;
  border: none;
  border-radius: 8px;
  font-size: 14px;
  cursor: pointer;
  transition: all 0.3s;
}

.btn-cancel {
  background: #f5f5f5;
  color: #666;
}

.btn-save {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
}

/* 费用明细 */
.fee-section {
  background: white;
  border-radius: 12px;
  padding: 16px;
  margin-bottom: 80px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.08);
}

.fee-section h3 {
  margin: 0 0 12px 0;
  font-size: 16px;
  color: #333;
}

.fee-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 8px 0;
  font-size: 14px;
  color: #666;
}

/* 底部合计 */
.order-footer {
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  background: white;
  padding: 16px 20px;
  box-shadow: 0 -2px 8px rgba(0,0,0,0.1);
  display: flex;
  justify-content: space-between;
  align-items: center;
  z-index: 100;
}

.total-section {
  display: flex;
  align-items: baseline;
  gap: 8px;
}

.total-label {
  font-size: 14px;
  color: #666;
}

.total-price {
  font-size: 24px;
  font-weight: bold;
  color: #ff4757;
}

.btn-pay {
  padding: 12px 32px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  border: none;
  border-radius: 20px;
  font-size: 16px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s;
  box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
}

.btn-pay:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 16px rgba(102, 126, 234, 0.5);
}

.empty-state {
  text-align: center;
  padding: 60px 20px;
  color: #999;
}
</style>

