<template>
  <div class="rating-page">
    <div class="page-header">
      <button class="btn-back" @click="goBack">
        <span>←</span>
      </button>
      <h1>评价对方</h1>
      <div></div>
    </div>

    <div v-if="deal && item" class="rating-container">
      <!-- 交易信息 -->
      <div class="deal-summary">
        <img :src="item.images?.[0] || 'https://via.placeholder.com/80'" :alt="item.title">
        <div class="deal-info">
          <div class="item-title">{{ item.title }}</div>
          <div class="item-price">¥{{ item.price }}</div>
        </div>
      </div>

      <!-- 评价对象 -->
      <div class="rating-target">
        <div class="target-avatar">{{ targetUser?.name?.[0] || '?' }}</div>
        <div class="target-info">
          <div class="target-name">{{ targetUser?.name || '未知用户' }}</div>
          <div class="target-role">{{ isRatingSeller ? '卖家' : '买家' }}</div>
          <div class="target-department">{{ targetUser?.department }}</div>
        </div>
      </div>

      <!-- 评分表单 -->
      <div class="rating-form">
        <div class="form-section">
          <h3>请对本次交易评分</h3>
          <p class="section-hint">请对本次交易的{{isRatingSeller ? '卖家' : '买家'}}进行公正的评价</p>
          
          <div class="form-group">
            <label>评分 *</label>
            <div class="star-rating">
              <span 
                v-for="n in 5" 
                :key="n"
                class="star"
                :class="{ active: ratingForm.stars >= n, hover: hoverStars >= n }"
                @click="ratingForm.stars = n"
                @mouseenter="hoverStars = n"
                @mouseleave="hoverStars = 0"
              >
                ⭐
              </span>
            </div>
            <div class="rating-text">
              {{ getRatingText(ratingForm.stars) }}
            </div>
          </div>
          
          <div class="form-group">
            <label>评价内容（不少于5个字）</label>
            <textarea 
              v-model="ratingForm.text" 
              placeholder="说说你的交易体验..."
              rows="5"
              maxlength="200"
            ></textarea>
            <div class="char-count">{{ ratingForm.text.length }}/200</div>
          </div>
          
          <div class="form-group">
            <label class="checkbox-label">
              <input type="checkbox" v-model="ratingForm.hasDispute">
              <span>标记为有纠纷（会影响对方信用分）</span>
            </label>
          </div>
        </div>

        <!-- 温馨提示 -->
        <div class="tips-section">
          <div class="tips-title">📋 温馨提示</div>
          <ul class="tips-list">
            <li>评价一旦提交将无法修改，请认真填写</li>
            <li>公正的评价有助于维护良好的交易环境</li>
            <li>恶意差评将被系统识别并处理</li>
          </ul>
        </div>

        <!-- 提交按钮 -->
        <div class="form-actions">
          <button class="btn-cancel" @click="goBack">取消</button>
          <button class="btn-submit" @click="submitRating" :disabled="submitting">
            {{ submitting ? '提交中...' : '发布评价' }}
          </button>
        </div>
      </div>
    </div>

    <div v-else class="empty-state">
      <p>交易信息不存在</p>
      <button class="btn-primary" @click="goBack">返回</button>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { 
  getDealById, getCurrentUser, getItemById, getUserById,
  addOrUpdateRating, addNotice
} from '../utils/storage.js'
import { updateCreditScore } from '../utils/credit.js'

const router = useRouter()
const route = useRoute()

const currentUser = ref(null)
const deal = ref(null)
const item = ref(null)
const targetUser = ref(null)
const submitting = ref(false)
const hoverStars = ref(0)

const ratingForm = ref({
  stars: 5,
  text: '',
  hasDispute: false
})

// 是否正在评价卖家
const isRatingSeller = computed(() => {
  if (!deal.value || !currentUser.value) return true
  return deal.value.buyerId === currentUser.value.id
})

onMounted(() => {
  currentUser.value = getCurrentUser()
  const dealId = route.params.dealId
  
  if (!currentUser.value) {
    alert('请先登录')
    router.push('/auth')
    return
  }
  
  if (dealId) {
    deal.value = getDealById(dealId)
    
    if (!deal.value) {
      alert('交易不存在')
      router.push('/deal')
      return
    }
    
    // 获取商品信息
    item.value = getItemById(deal.value.itemId)
    
    // 确定被评价对象
    const targetUserId = isRatingSeller.value 
      ? deal.value.sellerId 
      : deal.value.buyerId
    targetUser.value = getUserById(targetUserId)
  }
})

function getRatingText(stars) {
  const texts = {
    1: '😞 非常不满意',
    2: '😕 不太满意',
    3: '😐 一般般',
    4: '😊 比较满意',
    5: '😄 非常满意'
  }
  return texts[stars] || ''
}

function goBack() {
  router.back()
}

async function submitRating() {
  if (!deal.value || !currentUser.value) return
  
  // 验证评价内容
  if (!ratingForm.value.text.trim()) {
    alert('请填写评价内容')
    return
  }
  
  if (ratingForm.value.text.trim().length < 5) {
    alert('评价内容不能少于5个字')
    return
  }
  
  if (confirm('确定要提交评价吗？评价提交后将无法修改。')) {
    submitting.value = true
    
    try {
      // 确定被评价者
      const rateeId = isRatingSeller.value 
        ? deal.value.sellerId 
        : deal.value.buyerId
      
      // 保存评分
      addOrUpdateRating({
        dealId: deal.value.id,
        raterId: currentUser.value.id,
        rateeId: rateeId,
        stars: ratingForm.value.stars,
        text: ratingForm.value.text.trim(),
        hasDispute: ratingForm.value.hasDispute,
        raterRole: isRatingSeller.value ? 'buyer' : 'seller'  // 评价者角色
      })
      
      // 更新信用分（区分买家/卖家积分）
      const creditResult = updateCreditScore(
        rateeId,
        ratingForm.value.stars,
        deal.value.id,
        true,
        ratingForm.value.hasDispute,
        isRatingSeller.value ? 'seller' : 'buyer'  // 被评价者角色
      )
      
      // 通知对方
      addNotice({
        userId: rateeId,
        type: 'rating',
        title: '收到新评价',
        content: `您收到了 ${ratingForm.value.stars} 星评价，${isRatingSeller.value ? '卖家' : '买家'}信用分${creditResult.delta > 0 ? '+' : ''}${creditResult.delta.toFixed(1)}`
      })
      
      alert('评价成功！感谢您的反馈。')
      router.push('/deal')
    } catch (error) {
      console.error('评价失败:', error)
      alert('评价失败，请重试')
    } finally {
      submitting.value = false
    }
  }
}
</script>

<style scoped>
.rating-page {
  min-height: 100vh;
  background: #f5f5f5;
  padding-bottom: 20px;
}

.page-header {
  background: white;
  padding: 16px 20px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
  position: sticky;
  top: 60px;
  z-index: 100;
}

.btn-back {
  background: none;
  border: none;
  font-size: 24px;
  cursor: pointer;
  color: #333;
  padding: 0;
  width: 40px;
  height: 40px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 50%;
  transition: all 0.3s;
}

.btn-back:hover {
  background: #f5f5f5;
}

.page-header h1 {
  margin: 0;
  font-size: 18px;
  color: #333;
}

.rating-container {
  max-width: 600px;
  margin: 20px auto;
  padding: 0 20px;
}

/* 交易信息 */
.deal-summary {
  background: white;
  border-radius: 12px;
  padding: 16px;
  display: flex;
  gap: 12px;
  margin-bottom: 12px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.08);
}

.deal-summary img {
  width: 80px;
  height: 80px;
  border-radius: 8px;
  object-fit: cover;
}

.deal-info {
  flex: 1;
  display: flex;
  flex-direction: column;
  justify-content: center;
}

.item-title {
  font-size: 16px;
  font-weight: 500;
  color: #333;
  margin-bottom: 8px;
}

.item-price {
  font-size: 20px;
  font-weight: bold;
  color: #ff4757;
}

/* 评价对象 */
.rating-target {
  background: white;
  border-radius: 12px;
  padding: 20px;
  display: flex;
  align-items: center;
  gap: 16px;
  margin-bottom: 12px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.08);
}

.target-avatar {
  width: 60px;
  height: 60px;
  border-radius: 50%;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  font-size: 24px;
  font-weight: bold;
}

.target-info {
  flex: 1;
}

.target-name {
  font-size: 18px;
  font-weight: 600;
  color: #333;
  margin-bottom: 4px;
}

.target-role {
  display: inline-block;
  padding: 2px 10px;
  background: #e6f7ff;
  color: #1890ff;
  border-radius: 4px;
  font-size: 12px;
  margin-bottom: 6px;
}

.target-department {
  font-size: 14px;
  color: #999;
}

/* 评分表单 */
.rating-form {
  background: white;
  border-radius: 12px;
  padding: 24px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.08);
}

.form-section h3 {
  margin: 0 0 8px 0;
  font-size: 18px;
  color: #333;
}

.section-hint {
  color: #999;
  font-size: 14px;
  margin-bottom: 24px;
}

.form-group {
  margin-bottom: 24px;
}

.form-group label {
  display: block;
  margin-bottom: 12px;
  color: #333;
  font-weight: 500;
  font-size: 15px;
}

.star-rating {
  display: flex;
  gap: 12px;
  font-size: 40px;
  margin-bottom: 12px;
}

.star {
  cursor: pointer;
  opacity: 0.3;
  transition: all 0.3s;
  user-select: none;
}

.star.active,
.star.hover {
  opacity: 1;
  transform: scale(1.1);
}

.star:hover {
  transform: scale(1.2);
}

.rating-text {
  font-size: 16px;
  color: #667eea;
  font-weight: 500;
  height: 24px;
}

.form-group textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ddd;
  border-radius: 8px;
  font-size: 14px;
  font-family: inherit;
  resize: vertical;
  line-height: 1.6;
}

.char-count {
  text-align: right;
  font-size: 12px;
  color: #999;
  margin-top: 4px;
}

.checkbox-label {
  display: flex;
  align-items: center;
  gap: 8px;
  cursor: pointer;
  padding: 12px;
  background: #fff7e6;
  border-radius: 8px;
  border: 1px solid #faad14;
}

.checkbox-label input {
  width: 18px;
  height: 18px;
  cursor: pointer;
}

.checkbox-label span {
  color: #d46b08;
  font-size: 14px;
}

/* 温馨提示 */
.tips-section {
  background: #f9f9f9;
  border-radius: 8px;
  padding: 16px;
  margin: 24px 0;
}

.tips-title {
  font-size: 15px;
  font-weight: 600;
  color: #333;
  margin-bottom: 12px;
}

.tips-list {
  margin: 0;
  padding-left: 20px;
  color: #666;
  font-size: 14px;
  line-height: 1.8;
}

.tips-list li {
  margin-bottom: 4px;
}

/* 按钮 */
.form-actions {
  display: flex;
  gap: 12px;
}

.btn-cancel,
.btn-submit {
  flex: 1;
  padding: 14px;
  border: none;
  border-radius: 8px;
  font-size: 16px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s;
}

.btn-cancel {
  background: #f5f5f5;
  color: #666;
}

.btn-cancel:hover {
  background: #e8e8e8;
}

.btn-submit {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
}

.btn-submit:hover:not(:disabled) {
  transform: translateY(-2px);
  box-shadow: 0 6px 16px rgba(102, 126, 234, 0.5);
}

.btn-submit:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}

.empty-state {
  text-align: center;
  padding: 60px 20px;
  color: #999;
}

.btn-primary {
  padding: 12px 32px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  border: none;
  border-radius: 8px;
  font-size: 16px;
  cursor: pointer;
  margin-top: 20px;
}
</style>

