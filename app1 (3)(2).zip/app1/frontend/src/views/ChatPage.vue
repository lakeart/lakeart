<template>
  <div class="chat-page">
    <div class="chat-container">
      <div class="chat-header">
        <button class="btn-back" @click="$router.back()">← 返回</button>
        <div class="chat-title">
          <h3>{{ chatTitle }}</h3>
          <span class="status" :class="{ connected: isConnected }">
            {{ isConnected ? '● 已连接' : '○ 未连接' }}
          </span>
        </div>
      </div>
      
      <div class="messages-container" ref="messagesContainer">
        <div 
          v-for="(msg, index) in messages" 
          :key="index"
          :class="['message-item', msg.fromUserId === currentUser.id ? 'mine' : 'other']"
        >
          <div class="message-avatar">
            {{ getUserName(msg.fromUserId)[0] }}
          </div>
          <div class="message-content">
            <div class="message-meta">
              <span class="sender">{{ getUserName(msg.fromUserId) }}</span>
              <span class="time">{{ formatTime(msg.timestamp) }}</span>
            </div>
            <div class="message-text">{{ msg.text }}</div>
          </div>
        </div>
        
        <div v-if="messages.length === 0" class="empty-state">
          <p>💬 还没有消息</p>
          <p class="hint">开始聊天吧！</p>
        </div>
      </div>
      
      <div class="input-container">
        <textarea 
          v-model="inputText"
          placeholder="输入消息..."
          rows="3"
          @keydown.enter.exact.prevent="sendMessage"
          @keydown.enter.shift.exact="inputText += '\n'"
        ></textarea>
        <button class="btn-send" @click="sendMessage" :disabled="!inputText.trim() || !isConnected">
          发送
        </button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted, nextTick, computed } from 'vue'
import { useRoute } from 'vue-router'
import { io } from 'socket.io-client'
import { 
  getCurrentUser, getDealById, getItemById, getUserById,
  getDealMessages, addMessage
} from '../utils/storage.js'

const route = useRoute()
const currentUser = ref(null)
const deal = ref(null)
const item = ref(null)

const socket = ref(null)
const isConnected = ref(false)
const messages = ref([])
const inputText = ref('')
const messagesContainer = ref(null)

const chatTitle = computed(() => {
  if (!deal.value || !item.value) return '聊天'
  return `关于：${item.value.title}`
})

onMounted(() => {
  currentUser.value = getCurrentUser()
  loadDeal()
  loadMessages()
  connectSocket()
})

onUnmounted(() => {
  disconnectSocket()
})

function loadDeal() {
  const dealId = route.params.dealId
  deal.value = getDealById(dealId)
  
  if (deal.value) {
    item.value = getItemById(deal.value.itemId)
  }
}

function loadMessages() {
  // 加载历史消息（如果有存储）
  const dealId = route.params.dealId
  const historyMessages = getDealMessages(dealId)
  messages.value = historyMessages
  
  nextTick(() => {
    scrollToBottom()
  })
}

function connectSocket() {
  try {
    socket.value = io('http://localhost:5000')
    
    socket.value.on('connect', () => {
      console.log('Socket connected')
      isConnected.value = true
      
      // 加入房间
      const dealId = route.params.dealId
      socket.value.emit('join', {
        dealId,
        userId: currentUser.value.id
      })
    })
    
    socket.value.on('disconnect', () => {
      console.log('Socket disconnected')
      isConnected.value = false
    })
    
    socket.value.on('connected', (data) => {
      console.log('Server message:', data)
    })
    
    socket.value.on('user_joined', (data) => {
      console.log('User joined:', data)
    })
    
    socket.value.on('user_left', (data) => {
      console.log('User left:', data)
    })
    
    socket.value.on('new_message', (data) => {
      console.log('New message:', data)
      messages.value.push(data)
      
      // 可选：持久化消息
      addMessage(data)
      
      nextTick(() => {
        scrollToBottom()
      })
    })
  } catch (error) {
    console.error('Socket connection error:', error)
    alert('无法连接到聊天服务器，请确保后端服务已启动')
  }
}

function disconnectSocket() {
  if (socket.value) {
    const dealId = route.params.dealId
    socket.value.emit('leave', {
      dealId,
      userId: currentUser.value.id
    })
    
    socket.value.disconnect()
  }
}

function sendMessage() {
  if (!inputText.value.trim() || !isConnected.value) return
  
  const dealId = route.params.dealId
  const message = {
    dealId,
    fromUserId: currentUser.value.id,
    text: inputText.value.trim(),
    timestamp: Date.now()
  }
  
  socket.value.emit('msg', message)
  
  inputText.value = ''
}

function getUserName(userId) {
  const user = getUserById(userId)
  return user?.name || '未知用户'
}

function formatTime(timestamp) {
  const date = new Date(timestamp)
  const now = new Date()
  
  if (date.toDateString() === now.toDateString()) {
    // 今天：只显示时间
    return date.toLocaleTimeString('zh-CN', { 
      hour: '2-digit', 
      minute: '2-digit' 
    })
  } else {
    // 其他：显示日期+时间
    return date.toLocaleString('zh-CN', {
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit'
    })
  }
}

function scrollToBottom() {
  if (messagesContainer.value) {
    messagesContainer.value.scrollTop = messagesContainer.value.scrollHeight
  }
}
</script>

<style scoped>
.chat-page {
  padding: 20px 0;
  height: calc(100vh - 104px);
}

.chat-container {
  background: white;
  border-radius: 12px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
  height: 100%;
  display: flex;
  flex-direction: column;
}

.chat-header {
  padding: 20px 24px;
  border-bottom: 1px solid #f0f0f0;
  display: flex;
  align-items: center;
  gap: 16px;
}

.btn-back {
  padding: 8px 16px;
  background: #f5f5f5;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  font-size: 14px;
  transition: all 0.3s;
}

.btn-back:hover {
  background: #e0e0e0;
}

.chat-title {
  flex: 1;
}

.chat-title h3 {
  margin: 0 0 4px 0;
  font-size: 18px;
  color: #333;
}

.status {
  font-size: 12px;
  color: #999;
}

.status.connected {
  color: #52c41a;
}

.messages-container {
  flex: 1;
  padding: 24px;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.message-item {
  display: flex;
  gap: 12px;
  max-width: 70%;
}

.message-item.mine {
  align-self: flex-end;
  flex-direction: row-reverse;
}

.message-avatar {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  font-weight: bold;
  flex-shrink: 0;
}

.message-item.mine .message-avatar {
  background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
}

.message-content {
  flex: 1;
}

.message-meta {
  display: flex;
  gap: 8px;
  margin-bottom: 4px;
  font-size: 12px;
  color: #999;
}

.message-item.mine .message-meta {
  flex-direction: row-reverse;
}

.sender {
  font-weight: 500;
}

.message-text {
  padding: 12px 16px;
  background: #f5f5f5;
  border-radius: 12px;
  font-size: 14px;
  line-height: 1.6;
  word-wrap: break-word;
  white-space: pre-wrap;
}

.message-item.mine .message-text {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
}

.empty-state {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  color: #999;
}

.hint {
  font-size: 14px;
  color: #bbb;
  margin-top: 8px;
}

.input-container {
  padding: 20px 24px;
  border-top: 1px solid #f0f0f0;
  display: flex;
  gap: 12px;
}

.input-container textarea {
  flex: 1;
  padding: 12px;
  border: 1px solid #ddd;
  border-radius: 8px;
  font-size: 14px;
  font-family: inherit;
  resize: none;
}

.input-container textarea:focus {
  outline: none;
  border-color: #667eea;
}

.btn-send {
  padding: 12px 32px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  font-size: 16px;
  font-weight: 500;
  transition: all 0.3s;
  align-self: flex-end;
}

.btn-send:hover:not(:disabled) {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
}

.btn-send:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
</style>

