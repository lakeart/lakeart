from flask import Flask, request, jsonify
from flask_cors import CORS
from flask_socketio import SocketIO, emit, join_room, leave_room
import re

app = Flask(__name__)
app.config['SECRET_KEY'] = 'campus-resale-demo-secret'
CORS(app, resources={r"/*": {"origins": "*"}})
socketio = SocketIO(app, cors_allowed_origins="*", async_mode='eventlet')

# ==================== REST API ====================

@app.route('/api/ping', methods=['GET'])
def ping():
    """健康检查"""
    return jsonify({'ok': True, 'message': 'Server is running'})

@app.route('/api/face/verify', methods=['POST'])
def face_verify():
    """
    人脸验证（演示版）
    只要收到 data:image/ 开头的 base64 就判定通过
    """
    data = request.get_json()
    selfie_base64 = data.get('selfieBase64', '')
    
    # 演示逻辑：检查是否为有效的 base64 图片
    if selfie_base64 and selfie_base64.startswith('data:image/'):
        return jsonify({'ok': True, 'message': '人脸验证通过（演示）'})
    else:
        return jsonify({'ok': False, 'message': '请上传有效的照片'}), 400

@app.route('/api/payment/create', methods=['POST'])
def create_payment():
    """
    创建支付订单（演示版）
    实际应该对接支付宝/微信支付等
    """
    data = request.get_json()
    order_id = data.get('orderId')
    amount = data.get('amount')
    item_title = data.get('itemTitle', '')
    
    if not order_id or not amount:
        return jsonify({'ok': False, 'message': '订单信息不完整'}), 400
    
    # 演示逻辑：直接返回成功
    # 实际应该：
    # 1. 创建支付订单
    # 2. 返回支付链接或二维码
    # 3. 等待支付回调
    
    import time
    time.sleep(1)  # 模拟网络延迟
    
    return jsonify({
        'ok': True,
        'message': '支付成功（演示版，无需实际支付）',
        'data': {
            'orderId': order_id,
            'transactionId': f'TXN_{int(time.time() * 1000)}',
            'amount': amount,
            'status': 'SUCCESS'
        }
    })

# ==================== WebSocket ====================

@socketio.on('connect')
def handle_connect():
    """客户端连接"""
    print(f'Client connected: {request.sid}')
    emit('connected', {'message': '已连接到服务器'})

@socketio.on('disconnect')
def handle_disconnect():
    """客户端断开"""
    print(f'Client disconnected: {request.sid}')

@socketio.on('join')
def handle_join(data):
    """加入交易聊天室"""
    deal_id = data.get('dealId')
    user_id = data.get('userId')
    room = f'deal:{deal_id}'
    
    join_room(room)
    print(f'User {user_id} joined room {room}')
    
    # 通知房间内其他人
    emit('user_joined', {
        'userId': user_id,
        'message': f'用户 {user_id} 加入了聊天'
    }, room=room, skip_sid=request.sid)

@socketio.on('leave')
def handle_leave(data):
    """离开聊天室"""
    deal_id = data.get('dealId')
    user_id = data.get('userId')
    room = f'deal:{deal_id}'
    
    leave_room(room)
    print(f'User {user_id} left room {room}')
    
    emit('user_left', {
        'userId': user_id,
        'message': f'用户 {user_id} 离开了聊天'
    }, room=room)

@socketio.on('msg')
def handle_message(data):
    """发送聊天消息"""
    deal_id = data.get('dealId')
    from_user_id = data.get('fromUserId')
    text = data.get('text')
    timestamp = data.get('timestamp')
    
    room = f'deal:{deal_id}'
    
    # 广播消息到房间
    emit('new_message', {
        'dealId': deal_id,
        'fromUserId': from_user_id,
        'text': text,
        'timestamp': timestamp
    }, room=room)
    
    print(f'Message in {room} from {from_user_id}: {text}')

if __name__ == '__main__':
    print('🚀 Flask server starting on http://localhost:5000')
    socketio.run(app, host='0.0.0.0', port=5000, debug=True)

