from flask import Flask, request, jsonify
from flask_cors import CORS
from flask_socketio import SocketIO, emit, join_room, leave_room
from paddleocr import PaddleOCR
from PIL import Image
import io
import re

# 1. 初始化 Flask
app = Flask(__name__)
app.config['SECRET_KEY'] = 'campus-resale-demo-secret'
CORS(app, resources={r"/*": {"origins": "*"}})
socketio = SocketIO(app, cors_allowed_origins="*", async_mode='eventlet')

# 2. 初始化 PaddleOCR（OCR 识别）
ocr = PaddleOCR(use_angle_cls=True, lang="ch")

# ==================== REST API ====================
@app.route('/api/ping', methods=['GET'])
def ping():
    """健康检查"""
    return jsonify({'ok': True, 'message': 'Server is running'})

@app.route('/api/recognize', methods=['POST'])  # 修改：GET → POST
def recognize_image():
    # 1. 获取上传的图片
    if 'image' not in request.files:
        return jsonify({'ok': False, 'message': '请上传图片'}), 400
    
    file = request.files['image']
    image_data = file.read()
    image = Image.open(io.BytesIO(image_data))

    # 2. 用 PaddleOCR 识别文字
    result = ocr.ocr(image, cls=True)

    texts = []
    for line in result[0]:
        text = line[1][0]
        confidence = line[1][1]
        texts.append({"text": text, "confidence": float(confidence)})

    return jsonify({"texts": texts})  # 修改：return 缩进问题

@app.route('/api/face/verify', methods=['POST'])
def face_verify():
    data = request.get_json()
    selfie_base64 = data.get('selfieBase64', '')
    if selfie_base64 and selfie_base64.startswith('data:image/'):
        return jsonify({'ok': True, 'message': '人脸验证通过（演示）'})
    else:
        return jsonify({'ok': False, 'message': '请上传有效的照片'}), 400

@app.route('/api/payment/create', methods=['POST'])
def create_payment():
    data = request.get_json()
    order_id = data.get('orderId')
    amount = data.get('amount')
    item_title = data.get('itemTitle', '')
    if not order_id or not amount:
        return jsonify({'ok': False, 'message': '订单信息不完整'}), 400
    import time
    time.sleep(1)
    return jsonify({
        'ok': True,
        'message': '支付成功（演示版，无需实际支付）',
        'data': {
            'orderId': order_id,
            'transactionId': f'TXN_{int(time.time() * 1000)}',
            'amount': amount,
            'status': 'SUCCESS'
        }
    })

# ==================== WebSocket ====================
@socketio.on('connect')
def handle_connect():
    print(f'Client connected: {request.sid}')
    emit('connected', {'message': '已连接到服务器'})

@socketio.on('disconnect')
def handle_disconnect():
    print(f'Client disconnected: {request.sid}')

@socketio.on('join')
def handle_join(data):
    deal_id = data.get('dealId')
    user_id = data.get('userId')
    room = f'deal:{deal_id}'
    join_room(room)
    print(f'User {user_id} joined room {room}')
    emit('user_joined', {
        'userId': user_id,
        'message': f'用户 {user_id} 加入了聊天'
    }, room=room, skip_sid=request.sid)

@socketio.on('leave')
def handle_leave(data):
    deal_id = data.get('dealId')
    user_id = data.get('userId')
    room = f'deal:{deal_id}'
    leave_room(room)
    print(f'User {user_id} left room {room}')
    emit('user_left', {
        'userId': user_id,
        'message': f'用户 {user_id} 离开了聊天'
    }, room=room)

@socketio.on('msg')
def handle_message(data):
    deal_id = data.get('dealId')
    from_user_id = data.get('fromUserId')
    text = data.get('text')
    timestamp = data.get('timestamp')
    room = f'deal:{deal_id}'
    emit('new_message', {
        'dealId': deal_id,
        'fromUserId': from_user_id,
        'text': text,
        'timestamp': timestamp
    }, room=room)
    print(f'Message in {room} from {from_user_id}: {text}')

# 4. 启动 Flask + SocketIO
if __name__ == '__main__':
    print('🚀 Flask server starting on http://localhost:5000')
    socketio.run(app, host='0.0.0.0', port=5000, debug=True)