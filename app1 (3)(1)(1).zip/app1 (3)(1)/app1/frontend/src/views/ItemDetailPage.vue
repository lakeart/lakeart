<template>
  <div class="item-detail-page" v-if="item">
    <div class="detail-container">
      <!-- 商品信息 -->
      <div class="item-section">
        <div class="image-gallery">
          <div class="main-image">
            <img :src="currentImage" :alt="item.title">
          </div>
          <div class="thumbnail-list" v-if="item.images && item.images.length > 1">
            <img 
              v-for="(img, index) in item.images" 
              :key="index"
              :src="img" 
              :class="{ active: currentImageIndex === index }"
              @click="currentImageIndex = index"
            >
          </div>
        </div>
        
        <div class="item-info">
          <h1 class="item-title">{{ item.title }}</h1>
          
          <div class="item-tags">
            <span class="tag" v-for="tag in item.tags" :key="tag">{{ tag }}</span>
          </div>
          
          <div class="item-meta">
            <span class="meta-item">
              <span class="label">分类：</span>
              <span class="value">{{ item.category }}</span>
            </span>
            <span class="meta-item">
              <span class="label">品牌：</span>
              <span class="value">{{ item.brand }}</span>
            </span>
            <span class="meta-item" v-if="item.model">
              <span class="label">型号：</span>
              <span class="value">{{ item.model }}</span>
            </span>
            <span class="meta-item" v-if="item.originalPrice">
              <span class="label">原价：</span>
              <span class="value">¥{{ item.originalPrice }}</span>
            </span>
          </div>
          
          <div class="price-section">
            <div class="price">¥{{ item.price }}</div>
            <div class="price-hint">议价请私信卖家</div>
          </div>
          
          <div class="description">
            <h3>商品描述</h3>
            <p>{{ item.description || '暂无详细描述' }}</p>
          </div>
          
          <div class="actions">
            <button 
              class="btn-favorite" 
              :class="{ favorited: isFavorited }"
              @click="toggleFavorite"
            >
              {{ isFavorited ? '❤️ 已收藏' : '🤍 收藏' }}
            </button>
            <button 
              class="btn-deal" 
              @click="handleCreateDeal"
              :disabled="item.status === 'SOLD'"
            >
              {{ item.status === 'SOLD' ? '已售出' : '💬 发起交易' }}
            </button>
          </div>
        </div>
      </div>
      
      <!-- 卖家信息 -->
      <div class="seller-section" v-if="seller">
        <h3>卖家信息</h3>
        <div class="seller-card" @click="goToUserProfile">
          <div class="seller-avatar">{{ seller.name[0] }}</div>
          <div class="seller-info">
            <div class="seller-name">
              {{ seller.name }}
              <div class="badges">
                <span 
                  v-for="badge in sellerBadges" 
                  :key="badge.name"
                  class="badge-icon"
                  :title="badge.description"
                  :style="{ color: badge.color }"
                >
                  {{ badge.icon }}
                </span>
              </div>
            </div>
            <div class="seller-dept">{{ seller.department }}</div>
            <div class="seller-credit">
              信用分：<span :class="getCreditClass(seller.credit)">{{ seller.credit }}</span>
            </div>
          </div>
        </div>
      </div>
      
      <!-- 同类同价推荐 -->
      <div class="similar-section" v-if="similarItems.length > 0">
        <h3>🔍 同类同价推荐</h3>
        <div class="similar-items">
          <ItemCard 
            v-for="simItem in similarItems" 
            :key="simItem.id" 
            :item="simItem"
          />
        </div>
      </div>
    </div>
  </div>
  
  <div v-else class="empty-state">
    <p>😕 商品不存在</p>
    <button class="btn-back" @click="$router.back()">返回</button>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import ItemCard from '../components/ItemCard.vue'
import { 
  getItemById, getUserById, getCurrentUser, 
  addView, isFavorited as checkFavorite, 
  addFavorite, removeFavorite, addDeal, addNotice 
} from '../utils/storage.js'
import { getSimilarItems } from '../utils/recommend.js'
import { getUserBadges } from '../utils/credit.js'

const route = useRoute()
const router = useRouter()

const item = ref(null)
const seller = ref(null)
const currentUser = ref(null)
const currentImageIndex = ref(0)
const isFavorited = ref(false)
const similarItems = ref([])
const sellerBadges = ref([])

const currentImage = computed(() => {
  if (!item.value || !item.value.images || item.value.images.length === 0) {
    return 'https://via.placeholder.com/600x400/CCCCCC/FFFFFF?text=No+Image'
  }
  return item.value.images[currentImageIndex.value]
})

onMounted(() => {
  currentUser.value = getCurrentUser()
  loadItem()
})

function loadItem() {
  const itemId = route.params.id
  item.value = getItemById(itemId)
  
  if (!item.value) return
  
  // 记录浏览
  if (currentUser.value) {
    addView(currentUser.value.id, itemId)
  }
  
  // 加载卖家信息
  seller.value = getUserById(item.value.sellerId)
  
  // 加载卖家徽章
  if (seller.value) {
    sellerBadges.value = getUserBadges(seller.value.id)
  }
  
  // 检查收藏状态
  if (currentUser.value) {
    isFavorited.value = checkFavorite(currentUser.value.id, itemId)
  }
  
  // 加载同类推荐
  similarItems.value = getSimilarItems(itemId)
}

function toggleFavorite() {
  if (!currentUser.value) {
    alert('请先登录')
    return
  }
  
  if (isFavorited.value) {
    removeFavorite(currentUser.value.id, item.value.id)
    isFavorited.value = false
  } else {
    addFavorite(currentUser.value.id, item.value.id)
    isFavorited.value = true
  }
}

function handleCreateDeal() {
  if (!currentUser.value) {
    alert('请先登录')
    return
  }
  
  if (item.value.sellerId === currentUser.value.id) {
    alert('不能购买自己的商品')
    return
  }
  
  if (item.value.status === 'SOLD') {
    alert('该商品已售出')
    return
  }
  
  // 跳转到订单确认页面
  router.push(`/order/${item.value.id}`)
}

function getCreditClass(credit) {
  if (credit >= 75) return 'excellent'
  if (credit >= 60) return 'good'
  return 'normal'
}

function goToUserProfile() {
  // 这里可以跳转到用户主页，暂时跳转到"我的"页面
  router.push('/me')
}
</script>

<style scoped>
.item-detail-page {
  padding: 20px 0;
}

.detail-container {
  max-width: 1000px;
  margin: 0 auto;
}

.item-section {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 32px;
  background: white;
  border-radius: 12px;
  padding: 32px;
  margin-bottom: 24px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}

.image-gallery {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.main-image {
  width: 100%;
  aspect-ratio: 4/3;
  border-radius: 8px;
  overflow: hidden;
  background: #f5f5f5;
}

.main-image img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.thumbnail-list {
  display: flex;
  gap: 8px;
}

.thumbnail-list img {
  width: 80px;
  height: 80px;
  border-radius: 6px;
  object-fit: cover;
  cursor: pointer;
  border: 2px solid transparent;
  transition: all 0.3s;
}

.thumbnail-list img:hover {
  border-color: #667eea;
}

.thumbnail-list img.active {
  border-color: #667eea;
}

.item-info {
  display: flex;
  flex-direction: column;
}

.item-title {
  margin: 0 0 16px 0;
  font-size: 24px;
  color: #333;
}

.item-tags {
  display: flex;
  gap: 8px;
  margin-bottom: 16px;
  flex-wrap: wrap;
}

.tag {
  background: #f0f0f0;
  padding: 4px 12px;
  border-radius: 4px;
  font-size: 14px;
  color: #666;
}

.item-meta {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin-bottom: 20px;
  padding: 16px;
  background: #f9f9f9;
  border-radius: 8px;
}

.meta-item {
  font-size: 14px;
}

.meta-item .label {
  color: #999;
}

.meta-item .value {
  color: #333;
  font-weight: 500;
}

.meta-item .condition {
  display: inline-block;
  background: #e6f7ff;
  color: #1890ff;
  padding: 2px 8px;
  border-radius: 4px;
}

.price-section {
  margin-bottom: 20px;
  padding: 20px;
  background: linear-gradient(135deg, #ffeaa7 0%, #fdcb6e 100%);
  border-radius: 8px;
}

.price {
  font-size: 36px;
  font-weight: bold;
  color: #ff4757;
  margin-bottom: 4px;
}

.price-hint {
  font-size: 12px;
  color: #666;
}

.description {
  margin-bottom: 24px;
  flex: 1;
}

.description h3 {
  margin: 0 0 12px 0;
  font-size: 16px;
  color: #333;
}

.description p {
  margin: 0;
  color: #666;
  line-height: 1.6;
}

.actions {
  display: flex;
  gap: 12px;
}

.btn-favorite,
.btn-deal {
  flex: 1;
  padding: 14px;
  border: none;
  border-radius: 8px;
  font-size: 16px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s;
}

.btn-favorite {
  background: #f5f5f5;
  color: #333;
}

.btn-favorite:hover {
  background: #e0e0e0;
}

.btn-favorite.favorited {
  background: #ffe6e6;
  color: #ff4757;
}

.btn-deal {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
}

.btn-deal:hover:not(:disabled) {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
}

.btn-deal:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.seller-section {
  background: white;
  border-radius: 12px;
  padding: 24px;
  margin-bottom: 24px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}

.seller-section h3 {
  margin: 0 0 16px 0;
  font-size: 18px;
  color: #333;
}

.seller-card {
  display: flex;
  gap: 16px;
  padding: 16px;
  background: #f9f9f9;
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.3s;
}

.seller-card:hover {
  background: #f0f0f0;
}

.seller-avatar {
  width: 64px;
  height: 64px;
  border-radius: 50%;
  background: linear-gradient(135deg, #ffd89b 0%, #19547b 100%);
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  font-size: 24px;
  font-weight: bold;
  flex-shrink: 0;
}

.seller-info {
  flex: 1;
}

.seller-name {
  font-size: 18px;
  font-weight: 600;
  color: #333;
  margin-bottom: 8px;
  display: flex;
  align-items: center;
  gap: 8px;
}

.badges {
  display: flex;
  gap: 4px;
}

.badge-icon {
  font-size: 18px;
}

.seller-dept {
  font-size: 14px;
  color: #666;
  margin-bottom: 8px;
}

.seller-credit {
  font-size: 14px;
  color: #666;
}

.seller-credit span {
  font-weight: bold;
  padding: 2px 8px;
  border-radius: 4px;
}

.seller-credit .excellent {
  background: #52c41a;
  color: white;
}

.seller-credit .good {
  background: #1890ff;
  color: white;
}

.seller-credit .normal {
  background: #faad14;
  color: white;
}

.similar-section {
  background: white;
  border-radius: 12px;
  padding: 24px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}

.similar-section h3 {
  margin: 0 0 20px 0;
  font-size: 18px;
  color: #333;
}

.similar-items {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
  gap: 16px;
}

.empty-state {
  text-align: center;
  padding: 100px 20px;
  color: #999;
}

.btn-back {
  margin-top: 20px;
  padding: 10px 24px;
  background: #667eea;
  color: white;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  font-size: 14px;
}

@media (max-width: 768px) {
  .item-section {
    grid-template-columns: 1fr;
  }
}
</style>

