<template>
  <div class="me-page" v-if="currentUser">
    <div class="profile-section">
      <div class="profile-header">
        <div class="avatar-large">{{ currentUser.name[0] }}</div>
        <div class="profile-info">
          <h1>{{ currentUser.name }}</h1>
          <div class="user-meta">
            <span class="meta-item">学号：{{ currentUser.studentId }}</span>
            <span class="meta-item">院系：{{ currentUser.department }}</span>
          </div>
          <div class="badges-display">
            <span 
              v-for="badge in userBadges" 
              :key="badge.name"
              class="badge-large"
              :style="{ background: badge.color }"
              :title="badge.description"
            >
              {{ badge.icon }} {{ badge.name }}
            </span>
            <span v-if="userBadges.length === 0" class="no-badge">
              暂无头衔，继续努力吧！
            </span>
          </div>
        </div>
      </div>
      
      <div class="credit-section">
        <!-- 买家信用分 -->
        <div class="credit-card">
          <div class="credit-label">🛒 买家信用分</div>
          <div class="credit-value" :class="buyerCreditLevel.color">
            {{ currentUser.buyerCredit || 60 }}
          </div>
          <div class="credit-level">{{ buyerCreditLevel.level }}</div>
          
          <div class="credit-progress">
            <div 
              class="progress-bar buyer" 
              :style="{ width: (currentUser.buyerCredit || 60) + '%' }"
            ></div>
          </div>
        </div>
        
        <!-- 卖家信用分 -->
        <div class="credit-card">
          <div class="credit-label">🏪 卖家信用分</div>
          <div class="credit-value" :class="sellerCreditLevel.color">
            {{ currentUser.sellerCredit || 60 }}
          </div>
          <div class="credit-level">{{ sellerCreditLevel.level }}</div>
          
          <div class="credit-progress">
            <div 
              class="progress-bar seller" 
              :style="{ width: (currentUser.sellerCredit || 60) + '%' }"
            ></div>
          </div>
        </div>
        
        <div class="stats-grid">
          <div class="stat-card">
            <div class="stat-value">{{ ratingStats.totalCount }}</div>
            <div class="stat-label">总评价数</div>
          </div>
          <div class="stat-card">
            <div class="stat-value good">{{ ratingStats.goodCount }}</div>
            <div class="stat-label">好评数</div>
          </div>
          <div class="stat-card">
            <div class="stat-value bad">{{ ratingStats.badCount }}</div>
            <div class="stat-label">差评数</div>
          </div>
          <div class="stat-card">
            <div class="stat-value">{{ recentDealsCount }}</div>
            <div class="stat-label">近30天成交</div>
          </div>
        </div>
      </div>
    </div>
    
    <div class="content-tabs">
      <button 
        v-for="tab in tabs" 
        :key="tab.value"
        :class="['tab', { active: activeTab === tab.value }]"
        @click="activeTab = tab.value"
      >
        {{ tab.label }}
      </button>
    </div>
    
    <!-- 信用日志 -->
    <div v-if="activeTab === 'credit'" class="tab-content">
      <h3>信用变动记录</h3>
      <div class="credit-logs">
        <div v-for="log in creditLogs" :key="log.id" class="log-item">
          <div class="log-header">
            <span class="log-time">{{ formatTime(log.createdAt) }}</span>
            <span class="log-delta" :class="log.delta >= 0 ? 'positive' : 'negative'">
              {{ log.delta >= 0 ? '+' : '' }}{{ log.delta.toFixed(1) }}
            </span>
          </div>
          <div class="log-reason">{{ log.reason }}</div>
          <div class="log-credit">
            {{ log.oldCredit.toFixed(1) }} → {{ log.newCredit.toFixed(1) }}
          </div>
        </div>
        
        <div v-if="creditLogs.length === 0" class="empty-state">
          暂无信用记录
        </div>
      </div>
    </div>
    
    <!-- 我的商品 -->
    <div v-if="activeTab === 'items'" class="tab-content">
      <h3>我发布的商品</h3>
      <div class="items-grid">
        <ItemCard 
          v-for="item in myItems" 
          :key="item.id" 
          :item="item"
        />
      </div>
      
      <div v-if="myItems.length === 0" class="empty-state">
        还没有发布商品
      </div>
    </div>
    
    <!-- 我的收藏 -->
    <div v-if="activeTab === 'favorites'" class="tab-content">
      <h3>我的收藏</h3>
      <div class="items-grid">
        <ItemCard 
          v-for="item in favoriteItems" 
          :key="item.id" 
          :item="item"
        />
      </div>
      
      <div v-if="favoriteItems.length === 0" class="empty-state">
        还没有收藏商品
      </div>
    </div>
    
    <!-- 设置 -->
    <div v-if="activeTab === 'settings'" class="tab-content">
      <h3>设置</h3>
      <div class="settings-section">
        <button class="btn-danger" @click="clearAllData">
          🗑️ 清空所有数据（慎用）
        </button>
        <button class="btn-secondary" @click="generateSampleData">
          🎲 生成样本数据
        </button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import ItemCard from '../components/ItemCard.vue'
import { 
  getCurrentUser, getUserCreditLogs, getItems, getUserFavorites,
  getItemById, clearAllData as clearStorage
} from '../utils/storage.js'
import { 
  getUserBadges, getUserRatingStats, getRecentDealsCount,
  getCreditLevel
} from '../utils/credit.js'
import { generateSampleData as generateData } from '../utils/init.js'

const router = useRouter()
const currentUser = ref(null)
const activeTab = ref('credit')

const tabs = [
  { value: 'credit', label: '信用记录' },
  { value: 'items', label: '我的商品' },
  { value: 'favorites', label: '我的收藏' },
  { value: 'settings', label: '设置' }
]

const userBadges = ref([])
const ratingStats = ref({ goodCount: 0, badCount: 0, totalCount: 0, badRate: 0 })
const recentDealsCount = ref(0)
const creditLogs = ref([])
const myItems = ref([])
const favoriteItems = ref([])

const buyerCreditLevel = computed(() => {
  if (!currentUser.value) return { level: '良好', color: 'good' }
  return getCreditLevel(currentUser.value.buyerCredit || 60)
})

const sellerCreditLevel = computed(() => {
  if (!currentUser.value) return { level: '良好', color: 'good' }
  return getCreditLevel(currentUser.value.sellerCredit || 60)
})

// 兼容旧版本
const creditLevel = computed(() => sellerCreditLevel.value)

onMounted(() => {
  currentUser.value = getCurrentUser()
  if (currentUser.value) {
    loadData()
  }
})

function loadData() {
  // 加载徽章
  userBadges.value = getUserBadges(currentUser.value.id)
  
  // 加载评分统计
  ratingStats.value = getUserRatingStats(currentUser.value.id)
  
  // 加载近期成交
  recentDealsCount.value = getRecentDealsCount(currentUser.value.id)
  
  // 加载信用日志
  creditLogs.value = getUserCreditLogs(currentUser.value.id)
  
  // 加载我的商品
  const allItems = getItems()
  myItems.value = allItems.filter(item => item.sellerId === currentUser.value.id)
  
  // 加载收藏
  const favs = getUserFavorites(currentUser.value.id)
  favoriteItems.value = favs
    .map(fav => getItemById(fav.itemId))
    .filter(item => item && item.status === 'ACTIVE')
}

function formatTime(timestamp) {
  const date = new Date(timestamp)
  return date.toLocaleString('zh-CN')
}

function clearAllData() {
  if (confirm('确定要清空所有数据吗？此操作不可恢复！')) {
    if (confirm('再次确认：真的要清空所有数据吗？')) {
      clearStorage()
      alert('数据已清空，即将返回登录页')
      router.push('/auth')
    }
  }
}

function generateSampleData() {
  if (confirm('确定要生成样本数据吗？')) {
    const success = generateData()
    if (success) {
      alert('样本数据生成成功！')
      loadData()
    } else {
      alert('已存在数据，无需重复生成')
    }
  }
}
</script>

<style scoped>
.me-page {
  padding: 20px 0;
}

.profile-section {
  background: linear-gradient(135deg, #ffffff 0%, #f8f9ff 100%);
  border-radius: 16px;
  padding: 32px;
  margin-bottom: 24px;
  box-shadow: 0 4px 16px rgba(102, 126, 234, 0.15);
  border: 2px solid rgba(102, 126, 234, 0.1);
  position: relative;
  overflow: hidden;
  animation: fadeIn 0.6s ease;
}

.profile-section::before {
  content: '';
  position: absolute;
  top: -50%;
  right: -50%;
  width: 100%;
  height: 100%;
  background: radial-gradient(circle, rgba(102, 126, 234, 0.1) 0%, transparent 70%);
  animation: float 6s ease-in-out infinite;
}

.profile-header {
  display: flex;
  gap: 24px;
  margin-bottom: 32px;
  padding-bottom: 32px;
  border-bottom: 1px solid #f0f0f0;
}

.avatar-large {
  width: 120px;
  height: 120px;
  border-radius: 50%;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  font-size: 48px;
  font-weight: bold;
  flex-shrink: 0;
}

.profile-info {
  flex: 1;
}

.profile-info h1 {
  margin: 0 0 12px 0;
  font-size: 32px;
  color: #333;
}

.user-meta {
  display: flex;
  gap: 16px;
  margin-bottom: 16px;
  font-size: 14px;
  color: #666;
}

.badges-display {
  display: flex;
  gap: 12px;
  flex-wrap: wrap;
}

.badge-large {
  padding: 8px 16px;
  border-radius: 20px;
  color: white;
  font-size: 16px;
  font-weight: bold;
  display: flex;
  align-items: center;
  gap: 6px;
}

.no-badge {
  color: #999;
  font-size: 14px;
  font-style: italic;
}

.credit-section {
  display: grid;
  grid-template-columns: 1fr 1fr 2fr;
  gap: 16px;
}

.credit-card {
  padding: 24px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border-radius: 16px;
  color: white;
  text-align: center;
  position: relative;
  overflow: hidden;
  box-shadow: 0 8px 24px rgba(102, 126, 234, 0.4);
}

.credit-card::before {
  content: '';
  position: absolute;
  top: -50%;
  left: -50%;
  width: 200%;
  height: 200%;
  background: radial-gradient(circle, rgba(255, 255, 255, 0.1) 0%, transparent 70%);
  animation: rotate 15s linear infinite;
}

.credit-card > * {
  position: relative;
  z-index: 1;
}

.credit-label {
  font-size: 14px;
  opacity: 0.9;
  margin-bottom: 8px;
}

.credit-value {
  font-size: 64px;
  font-weight: bold;
  margin-bottom: 8px;
}

.credit-level {
  font-size: 18px;
  font-weight: 500;
  margin-bottom: 16px;
}

.credit-progress {
  width: 100%;
  height: 8px;
  background: rgba(255,255,255,0.3);
  border-radius: 4px;
  overflow: hidden;
}

.progress-bar {
  height: 100%;
  background: white;
  border-radius: 4px;
  transition: width 0.3s;
}

.progress-bar.buyer {
  background: linear-gradient(90deg, #ffd89b 0%, #19547b 100%);
}

.progress-bar.seller {
  background: linear-gradient(90deg, #4facfe 0%, #00f2fe 100%);
}

.stats-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 16px;
}

.stat-card {
  padding: 20px;
  background: #f9f9f9;
  border-radius: 8px;
  text-align: center;
}

.stat-value {
  font-size: 32px;
  font-weight: bold;
  color: #333;
  margin-bottom: 8px;
}

.stat-value.good {
  color: #52c41a;
}

.stat-value.bad {
  color: #ff4757;
}

.stat-label {
  font-size: 14px;
  color: #999;
}

.content-tabs {
  display: flex;
  gap: 12px;
  margin-bottom: 24px;
  flex-wrap: wrap;
}

.tab {
  padding: 10px 20px;
  border: 1px solid #ddd;
  background: white;
  border-radius: 20px;
  cursor: pointer;
  transition: all 0.3s;
  font-size: 14px;
}

.tab:hover {
  border-color: #667eea;
  color: #667eea;
}

.tab.active {
  background: #667eea;
  color: white;
  border-color: #667eea;
}

.tab-content {
  background: white;
  border-radius: 12px;
  padding: 24px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}

.tab-content h3 {
  margin: 0 0 20px 0;
  font-size: 18px;
  color: #333;
}

.credit-logs {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.log-item {
  padding: 16px;
  background: #f9f9f9;
  border-radius: 8px;
  border-left: 4px solid #ddd;
}

.log-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 8px;
}

.log-time {
  font-size: 12px;
  color: #999;
}

.log-delta {
  font-size: 18px;
  font-weight: bold;
}

.log-delta.positive {
  color: #52c41a;
}

.log-delta.negative {
  color: #ff4757;
}

.log-reason {
  font-size: 14px;
  color: #333;
  margin-bottom: 4px;
}

.log-credit {
  font-size: 12px;
  color: #999;
}

.items-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
  gap: 16px;
}

.empty-state {
  text-align: center;
  padding: 40px;
  color: #999;
}

.settings-section {
  display: flex;
  flex-direction: column;
  gap: 12px;
  max-width: 400px;
}

.btn-danger,
.btn-secondary {
  padding: 14px;
  border: none;
  border-radius: 8px;
  font-size: 16px;
  cursor: pointer;
  transition: all 0.3s;
}

.btn-danger {
  background: #ff4757;
  color: white;
}

.btn-danger:hover {
  background: #ff6b81;
}

.btn-secondary {
  background: #1890ff;
  color: white;
}

.btn-secondary:hover {
  background: #40a9ff;
}

@media (max-width: 968px) {
  .profile-header {
    flex-direction: column;
    text-align: center;
  }
  
  .avatar-large {
    margin: 0 auto;
  }
  
  .credit-section {
    grid-template-columns: 1fr;
    gap: 16px;
  }
  
  .stats-grid {
    grid-template-columns: repeat(2, 1fr);
  }
  
  .user-meta {
    justify-content: center;
  }
  
  .badges-display {
    justify-content: center;
  }
}
</style>

