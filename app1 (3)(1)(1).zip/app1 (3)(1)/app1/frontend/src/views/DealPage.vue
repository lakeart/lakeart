<template>
  <div class="deal-page">
    <h1>💼 我的交易</h1>
    
    <div class="tabs">
      <button 
        v-for="tab in tabs" 
        :key="tab.value"
        :class="['tab', { active: activeTab === tab.value }]"
        @click="activeTab = tab.value"
      >
        {{ tab.label }}
        <span class="count" v-if="getCountByTab(tab.value) > 0">
          {{ getCountByTab(tab.value) }}
        </span>
      </button>
    </div>
    
    <!-- 我发布的商品列表 -->
    <div v-if="activeTab === 'myitems'" class="items-grid">
      <div 
        v-for="item in filteredItems" 
        :key="item.id"
        class="item-card"
      >
        <div class="item-image" @click="goToItem(item.id)">
          <img :src="item.images?.[0] || 'https://via.placeholder.com/300x200'" :alt="item.title">
          <div class="item-status" :class="item.status.toLowerCase()">
            {{ item.status === 'ACTIVE' ? '销售中' : item.status === 'SOLD' ? '已售出' : '已下架' }}
          </div>
        </div>
        <div class="item-info">
          <div class="item-main" @click="goToItem(item.id)">
            <div class="item-title">{{ item.title }}</div>
            <div class="item-meta">
              <span class="item-category">{{ item.category }}</span>
              <span class="item-brand">{{ item.brand }}</span>
            </div>
            <div class="item-price">¥{{ item.price }}</div>
            <div class="item-time">发布于 {{ formatTime(item.createdAt) }}</div>
          </div>
          <div class="item-actions">
            <button 
              v-if="item.status === 'ACTIVE'" 
              class="btn-action btn-remove" 
              @click.stop="removeItem(item)"
              title="下架商品"
            >
              📦 下架
            </button>
            <button 
              v-if="item.status === 'REMOVED'" 
              class="btn-action btn-relist" 
              @click.stop="relistItem(item)"
              title="重新上架"
            >
              ♻️ 上架
            </button>
            <button 
              v-if="item.status === 'ACTIVE' || item.status === 'REMOVED'" 
              class="btn-action btn-delete" 
              @click.stop="deleteItem(item)"
              title="删除商品"
            >
              🗑️ 删除
            </button>
          </div>
        </div>
      </div>
      
      <div v-if="filteredItems.length === 0" class="empty-state">
        <p>😕 还没有发布商品</p>
        <p class="hint">去发布你的第一个商品吧！</p>
      </div>
    </div>
    
    <!-- 交易列表 -->
    <div v-else class="deal-list">
      <div 
        v-for="deal in filteredDeals" 
        :key="deal.id"
        class="deal-card"
      >
        <div class="deal-header">
          <div class="deal-id">交易编号：{{ deal.id.slice(-8) }}</div>
          <div class="deal-status" :class="deal.status.toLowerCase()">
            {{ statusText[deal.status] }}
          </div>
        </div>
        
        <div class="deal-content">
          <div class="item-info" @click="goToItem(deal.itemId)">
            <img :src="getItemImage(deal.itemId)" :alt="getItemTitle(deal.itemId)">
            <div class="item-detail">
              <div class="item-title">{{ getItemTitle(deal.itemId) }}</div>
              <div class="item-price">¥{{ getItemPrice(deal.itemId) }}</div>
            </div>
          </div>
          
          <div class="deal-info">
            <div class="info-item">
              <span class="label">卖家：</span>
              <span class="value">{{ getUserName(deal.sellerId) }}</span>
            </div>
            <div class="info-item">
              <span class="label">买家：</span>
              <span class="value">{{ getUserName(deal.buyerId) }}</span>
            </div>
            <div class="info-item">
              <span class="label">创建时间：</span>
              <span class="value">{{ formatTime(deal.createdAt) }}</span>
            </div>
          </div>
        </div>
        
        <div class="deal-actions">
          <!-- 卖家操作 -->
          <template v-if="deal.sellerId === currentUser.id">
            <button 
              v-if="deal.status === 'INTENT'" 
              class="btn-action primary"
              @click="completeDeal(deal)"
            >
              ✅ 确认完成交易
            </button>
            <button 
              v-if="deal.status === 'INTENT'" 
              class="btn-action danger"
              @click="cancelDeal(deal)"
            >
              ❌ 取消交易
            </button>
          </template>
          
          <!-- 买家操作 -->
          <template v-if="deal.buyerId === currentUser.id">
            <button 
              v-if="deal.status === 'INTENT'" 
              class="btn-action"
              @click="cancelDeal(deal)"
            >
              取消交易
            </button>
          </template>
          
          <!-- 已完成交易 - 双方都可以评价 -->
          <button 
            v-if="deal.status === 'DONE'"
            class="btn-action primary"
            @click="openRateModal(deal)"
          >
            {{ hasRated(deal.id) ? '✏️ 修改评价' : '⭐ 评价对方' }}
          </button>
          
          <!-- 聊天功能 -->
          <button 
            class="btn-action secondary"
            @click="goToChat(deal.id)"
          >
            💬 聊天
          </button>
        </div>
        
        <!-- 显示评价 -->
        <div v-if="deal.status === 'DONE'" class="ratings-section">
          <div 
            v-for="rating in getDealRatings(deal.id)" 
            :key="rating.raterId"
            class="rating-item"
          >
            <div class="rating-header">
              <span class="rater">{{ getUserName(rating.raterId) }}</span>
              <span class="stars">{{ '⭐'.repeat(rating.stars) }}</span>
            </div>
            <div class="rating-text" v-if="rating.text">{{ rating.text }}</div>
          </div>
        </div>
      </div>
      
      <div v-if="filteredDeals.length === 0" class="empty-state">
        <p>😕 暂无交易记录</p>
        <p class="hint">去逛逛市场，发现心仪的商品吧！</p>
      </div>
    </div>
    
    <!-- 评价弹窗 -->
    <div v-if="showRateModal" class="modal-overlay" @click="closeRateModal">
      <div class="modal-content" @click.stop>
        <h3>评价交易</h3>
        
        <div class="rate-form">
          <div class="form-group">
            <label>评分 *</label>
            <div class="star-rating">
              <span 
                v-for="n in 5" 
                :key="n"
                class="star"
                :class="{ active: ratingForm.stars >= n }"
                @click="ratingForm.stars = n"
              >
                ⭐
              </span>
            </div>
          </div>
          
          <div class="form-group">
            <label>评价内容（选填）</label>
            <textarea 
              v-model="ratingForm.text" 
              placeholder="说说你的交易体验..."
              rows="4"
            ></textarea>
          </div>
          
          <div class="form-group">
            <label class="checkbox-label">
              <input type="checkbox" v-model="ratingForm.hasDispute">
              标记为有纠纷（会扣除信用分）
            </label>
          </div>
          
          <div class="modal-actions">
            <button class="btn-cancel" @click="closeRateModal">取消</button>
            <button class="btn-submit" @click="submitRating">提交评价</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { 
  getDeals, getCurrentUser, getItemById, getUserById,
  updateDeal, updateItem, addOrUpdateRating, getRatingsByDeal,
  addNotice, getRatings, getItems
} from '../utils/storage.js'
import { updateCreditScore } from '../utils/credit.js'

const router = useRouter()
const currentUser = ref(null)

const tabs = [
  { value: 'all', label: '全部交易' },
  { value: 'buying', label: '我买的' },
  { value: 'selling', label: '我卖的' },
  { value: 'myitems', label: '我发布的商品' },
  { value: 'done', label: '已完成' }
]

const activeTab = ref('all')
const showRateModal = ref(false)
const currentDeal = ref(null)
const ratingForm = ref({
  stars: 5,
  text: '',
  hasDispute: false
})

const statusText = {
  'INTENT': '待完成',
  'DONE': '已完成',
  'CANCELLED': '已取消'
}

const allDeals = ref([])
const myItems = ref([])

const filteredDeals = computed(() => {
  // 如果是"我发布的商品"标签，返回空数组（不显示交易）
  if (activeTab.value === 'myitems') {
    return []
  }
  
  let deals = allDeals.value
  
  if (activeTab.value === 'buying') {
    deals = deals.filter(d => d.buyerId === currentUser.value.id)
  } else if (activeTab.value === 'selling') {
    deals = deals.filter(d => d.sellerId === currentUser.value.id)
  } else if (activeTab.value === 'done') {
    deals = deals.filter(d => d.status === 'DONE')
  } else {
    // all：只显示与当前用户相关的
    deals = deals.filter(d => 
      d.buyerId === currentUser.value.id || 
      d.sellerId === currentUser.value.id
    )
  }
  
  return deals.sort((a, b) => b.createdAt - a.createdAt)
})

const filteredItems = computed(() => {
  if (activeTab.value === 'myitems' && currentUser.value) {
    // 过滤掉已删除的商品，显示其他所有状态
    return myItems.value.filter(item => 
      item.sellerId === currentUser.value.id && 
      item.status !== 'DELETED'
    ).sort((a, b) => b.createdAt - a.createdAt)
  }
  return []
})

onMounted(() => {
  currentUser.value = getCurrentUser()
  loadDeals()
  loadMyItems()
})

function loadDeals() {
  allDeals.value = getDeals()
}

function loadMyItems() {
  myItems.value = getItems()
}

function getCountByTab(tab) {
  if (tab === 'all') {
    return allDeals.value.filter(d => 
      d.buyerId === currentUser.value.id || 
      d.sellerId === currentUser.value.id
    ).length
  } else if (tab === 'buying') {
    return allDeals.value.filter(d => d.buyerId === currentUser.value.id).length
  } else if (tab === 'selling') {
    return allDeals.value.filter(d => d.sellerId === currentUser.value.id).length
  } else if (tab === 'done') {
    return allDeals.value.filter(d => 
      d.status === 'DONE' && 
      (d.buyerId === currentUser.value.id || d.sellerId === currentUser.value.id)
    ).length
  }
  return 0
}

function getItemImage(itemId) {
  const item = getItemById(itemId)
  return item?.images?.[0] || 'https://via.placeholder.com/100'
}

function getItemTitle(itemId) {
  const item = getItemById(itemId)
  return item?.title || '商品已删除'
}

function getItemPrice(itemId) {
  const item = getItemById(itemId)
  return item?.price || 0
}

function getUserName(userId) {
  const user = getUserById(userId)
  return user?.name || '未知用户'
}

function formatTime(timestamp) {
  const date = new Date(timestamp)
  return date.toLocaleString('zh-CN')
}

function completeDeal(deal) {
  if (confirm('确认交易已完成？商品将标记为已售出。')) {
    // 更新交易状态
    updateDeal(deal.id, { 
      status: 'DONE',
      updatedAt: Date.now()
    })
    
    // 更新商品状态
    updateItem(deal.itemId, { status: 'SOLD' })
    
    // 通知买家
    addNotice({
      userId: deal.buyerId,
      type: 'deal',
      title: '交易完成',
      content: `您购买的 ${getItemTitle(deal.itemId)} 已完成交易`
    })
    
    alert('交易已完成！别忘了互相评价哦~')
    loadDeals()
  }
}

function cancelDeal(deal) {
  if (confirm('确定要取消这笔交易吗？')) {
    updateDeal(deal.id, { 
      status: 'CANCELLED',
      updatedAt: Date.now()
    })
    
    // 通知对方
    const notifyUserId = deal.sellerId === currentUser.value.id 
      ? deal.buyerId 
      : deal.sellerId
    
    addNotice({
      userId: notifyUserId,
      type: 'deal',
      title: '交易已取消',
      content: `${getItemTitle(deal.itemId)} 的交易已被取消`
    })
    
    alert('交易已取消')
    loadDeals()
  }
}

function goToItem(itemId) {
  router.push(`/item/${itemId}`)
}

// 下架商品
function removeItem(item) {
  if (confirm(`确定要下架商品"${item.title}"吗？下架后可以重新上架。`)) {
    updateItem(item.id, { status: 'REMOVED' })
    loadMyItems()
    alert('商品已下架')
  }
}

// 重新上架
function relistItem(item) {
  if (confirm(`确定要重新上架商品"${item.title}"吗？`)) {
    updateItem(item.id, { status: 'ACTIVE' })
    loadMyItems()
    alert('商品已重新上架')
  }
}

// 删除商品
function deleteItem(item) {
  if (confirm(`确定要删除商品"${item.title}"吗？删除后无法恢复！`)) {
    // 这里实际上是永久删除，但为了保持数据完整性，我们将状态设为DELETED
    // 或者可以直接从数组中移除，但这会影响历史数据
    updateItem(item.id, { status: 'DELETED' })
    loadMyItems()
    alert('商品已删除')
  }
}

function goToItemDetail(itemId) {
  router.push(`/item/${itemId}`)
}

function goToChat(dealId) {
  router.push(`/chat/${dealId}`)
}

function openRateModal(deal) {
  currentDeal.value = deal
  
  // 检查是否已评价过
  const existingRating = getRatingsByDeal(deal.id).find(r => r.raterId === currentUser.value.id)
  
  if (existingRating) {
    ratingForm.value = {
      stars: existingRating.stars,
      text: existingRating.text || '',
      hasDispute: existingRating.hasDispute || false
    }
  } else {
    ratingForm.value = {
      stars: 5,
      text: '',
      hasDispute: false
    }
  }
  
  showRateModal.value = true
}

function closeRateModal() {
  showRateModal.value = false
  currentDeal.value = null
}

function hasRated(dealId) {
  const ratings = getRatingsByDeal(dealId)
  return ratings.some(r => r.raterId === currentUser.value.id)
}

function getDealRatings(dealId) {
  return getRatingsByDeal(dealId)
}

function submitRating() {
  if (!currentDeal.value) return
  
  const deal = currentDeal.value
  
  // 确定被评价者
  const rateeId = deal.sellerId === currentUser.value.id 
    ? deal.buyerId 
    : deal.sellerId
  
  // 保存评分
  addOrUpdateRating({
    dealId: deal.id,
    raterId: currentUser.value.id,
    rateeId: rateeId,
    stars: ratingForm.value.stars,
    text: ratingForm.value.text,
    hasDispute: ratingForm.value.hasDispute
  })
  
  // 更新信用分
  const creditResult = updateCreditScore(
    rateeId,
    ratingForm.value.stars,
    deal.id,
    true,
    ratingForm.value.hasDispute
  )
  
  // 通知对方
  addNotice({
    userId: rateeId,
    type: 'rating',
    title: '收到新评价',
    content: `您收到了 ${ratingForm.value.stars} 星评价，信用分${creditResult.delta > 0 ? '+' : ''}${creditResult.delta.toFixed(1)}`
  })
  
  alert('评价成功！')
  closeRateModal()
  loadDeals()
}
</script>

<style scoped>
.deal-page {
  padding: 20px 0;
}

.deal-page h1 {
  margin: 0 0 24px 0;
  font-size: 28px;
  color: #333;
}

.tabs {
  display: flex;
  gap: 12px;
  margin-bottom: 24px;
  flex-wrap: wrap;
}

.tab {
  padding: 10px 20px;
  border: 1px solid #ddd;
  background: white;
  border-radius: 20px;
  cursor: pointer;
  transition: all 0.3s;
  font-size: 14px;
  display: flex;
  align-items: center;
  gap: 6px;
}

.tab:hover {
  border-color: #667eea;
  color: #667eea;
}

.tab.active {
  background: #667eea;
  color: white;
  border-color: #667eea;
}

.count {
  background: rgba(0,0,0,0.1);
  padding: 2px 8px;
  border-radius: 10px;
  font-size: 12px;
}

.tab.active .count {
  background: rgba(255,255,255,0.3);
}

.deal-list {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.deal-card {
  background: white;
  border-radius: 12px;
  padding: 24px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}

.deal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
  padding-bottom: 16px;
  border-bottom: 1px solid #f0f0f0;
}

.deal-id {
  font-size: 14px;
  color: #999;
}

.deal-status {
  padding: 4px 12px;
  border-radius: 12px;
  font-size: 12px;
  font-weight: bold;
}

.deal-status.intent {
  background: #fff7e6;
  color: #faad14;
}

.deal-status.done {
  background: #f6ffed;
  color: #52c41a;
}

.deal-status.cancelled {
  background: #f5f5f5;
  color: #999;
}

.deal-content {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 24px;
  margin-bottom: 16px;
}

.item-info {
  display: flex;
  gap: 12px;
  cursor: pointer;
  transition: all 0.3s;
  padding: 12px;
  border-radius: 8px;
}

.item-info:hover {
  background: #f9f9f9;
}

.item-info img {
  width: 80px;
  height: 80px;
  border-radius: 8px;
  object-fit: cover;
}

.item-detail {
  flex: 1;
  display: flex;
  flex-direction: column;
  justify-content: center;
}

.item-title {
  font-size: 16px;
  font-weight: 500;
  color: #333;
  margin-bottom: 8px;
}

.item-price {
  font-size: 20px;
  font-weight: bold;
  color: #ff4757;
}

.deal-info {
  display: flex;
  flex-direction: column;
  gap: 8px;
  justify-content: center;
}

.info-item {
  font-size: 14px;
}

.info-item .label {
  color: #999;
}

.info-item .value {
  color: #333;
  font-weight: 500;
}

.deal-actions {
  display: flex;
  gap: 12px;
  flex-wrap: wrap;
}

.btn-action {
  padding: 10px 20px;
  border: 1px solid #ddd;
  background: white;
  border-radius: 8px;
  cursor: pointer;
  font-size: 14px;
  transition: all 0.3s;
}

.btn-action:hover {
  background: #f5f5f5;
}

.btn-action.primary {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  border: none;
}

.btn-action.primary:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
}

.btn-action.secondary {
  background: #1890ff;
  color: white;
  border: none;
}

.btn-action.secondary:hover {
  background: #40a9ff;
}

.btn-action.danger {
  background: #ff4757;
  color: white;
  border: none;
}

.btn-action.danger:hover {
  background: #ff6b81;
}

.ratings-section {
  margin-top: 16px;
  padding-top: 16px;
  border-top: 1px solid #f0f0f0;
}

.rating-item {
  padding: 12px;
  background: #f9f9f9;
  border-radius: 8px;
  margin-bottom: 8px;
}

.rating-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 8px;
}

.rater {
  font-weight: 500;
  color: #333;
}

.stars {
  font-size: 14px;
}

.rating-text {
  font-size: 14px;
  color: #666;
  line-height: 1.6;
}

.empty-state {
  text-align: center;
  padding: 60px 20px;
  color: #999;
}

.hint {
  font-size: 14px;
  color: #bbb;
  margin-top: 8px;
}

/* 弹窗样式 */
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0,0,0,0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
}

.modal-content {
  background: white;
  border-radius: 12px;
  padding: 32px;
  max-width: 500px;
  width: 90%;
  max-height: 90vh;
  overflow-y: auto;
}

.modal-content h3 {
  margin: 0 0 24px 0;
  font-size: 20px;
  color: #333;
}

.rate-form .form-group {
  margin-bottom: 20px;
}

.rate-form label {
  display: block;
  margin-bottom: 8px;
  color: #333;
  font-weight: 500;
}

.star-rating {
  display: flex;
  gap: 8px;
  font-size: 32px;
}

.star {
  cursor: pointer;
  opacity: 0.3;
  transition: all 0.3s;
}

.star.active {
  opacity: 1;
  transform: scale(1.1);
}

.rate-form textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ddd;
  border-radius: 8px;
  font-size: 14px;
  font-family: inherit;
  resize: vertical;
}

.checkbox-label {
  display: flex;
  align-items: center;
  gap: 8px;
  cursor: pointer;
}

.checkbox-label input {
  width: 18px;
  height: 18px;
  cursor: pointer;
}

.modal-actions {
  display: flex;
  gap: 12px;
  margin-top: 24px;
}

.btn-cancel,
.btn-submit {
  flex: 1;
  padding: 12px;
  border: none;
  border-radius: 8px;
  font-size: 16px;
  cursor: pointer;
  transition: all 0.3s;
}

.btn-cancel {
  background: #f5f5f5;
  color: #666;
}

.btn-submit {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
}

@media (max-width: 768px) {
  .deal-content {
    grid-template-columns: 1fr;
  }
}

/* 我发布的商品列表样式 */
.items-grid {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.items-grid .item-card {
  background: white;
  border-radius: 12px;
  overflow: hidden;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
  cursor: pointer;
  transition: all 0.3s;
  display: flex;
  flex-direction: row;
  height: 140px;
}

.items-grid .item-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 16px rgba(0,0,0,0.15);
}

.items-grid .item-image {
  position: relative;
  width: 180px;
  min-width: 180px;
  height: 140px;
  overflow: hidden;
  background: #f5f5f5;
}

.items-grid .item-image img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  transition: transform 0.3s;
}

.items-grid .item-card:hover .item-image img {
  transform: scale(1.05);
}

.items-grid .item-status {
  position: absolute;
  top: 10px;
  right: 10px;
  padding: 4px 12px;
  border-radius: 12px;
  font-size: 12px;
  font-weight: bold;
  color: white;
  backdrop-filter: blur(4px);
}

.items-grid .item-status.active {
  background: rgba(82, 196, 26, 0.9);
}

.items-grid .item-status.sold {
  background: rgba(153, 153, 153, 0.9);
}

.items-grid .item-status.removed {
  background: rgba(255, 71, 87, 0.9);
}

.items-grid .item-info {
  padding: 16px 20px;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  flex: 1;
  min-width: 0;
  gap: 16px;
}

.items-grid .item-main {
  flex: 1;
  min-width: 0;
  cursor: pointer;
}

.items-grid .item-actions {
  display: flex;
  flex-direction: column;
  gap: 8px;
  flex-shrink: 0;
}

.btn-action {
  padding: 6px 16px;
  border: none;
  border-radius: 6px;
  font-size: 13px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s;
  white-space: nowrap;
  min-width: 80px;
}

.btn-remove {
  background: linear-gradient(135deg, #ffa502 0%, #ff6348 100%);
  color: white;
}

.btn-remove:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(255, 165, 2, 0.4);
}

.btn-relist {
  background: linear-gradient(135deg, #52c41a 0%, #73d13d 100%);
  color: white;
}

.btn-relist:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(82, 196, 26, 0.4);
}

.btn-delete {
  background: linear-gradient(135deg, #ff4757 0%, #ff6b81 100%);
  color: white;
}

.btn-delete:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(255, 71, 87, 0.4);
}

.items-grid .item-title {
  font-size: 18px;
  font-weight: 600;
  color: #333;
  margin-bottom: 8px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.items-grid .item-meta {
  display: flex;
  gap: 8px;
  margin-bottom: 8px;
}

.items-grid .item-brand {
  background: #e6f7ff;
  color: #1890ff;
  padding: 2px 8px;
  border-radius: 4px;
  font-size: 12px;
}

.items-grid .item-category,
.items-grid .item-condition {
  font-size: 12px;
  padding: 4px 10px;
  border-radius: 6px;
  font-weight: 500;
}

.items-grid .item-category {
  background: #e6f7ff;
  color: #1890ff;
}

.items-grid .item-condition {
  background: #f6ffed;
  color: #52c41a;
}

.items-grid .item-price {
  font-size: 28px;
  font-weight: bold;
  background: linear-gradient(135deg, #ff4757 0%, #ff6b81 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  margin-bottom: 4px;
}

.items-grid .item-time {
  font-size: 13px;
  color: #999;
}

@media (max-width: 768px) {
  .items-grid .item-card {
    height: 120px;
  }
  
  .items-grid .item-image {
    width: 140px;
    min-width: 140px;
    height: 120px;
  }
  
  .items-grid .item-info {
    padding: 12px 16px;
  }
  
  .items-grid .item-title {
    font-size: 16px;
  }
  
  .items-grid .item-price {
    font-size: 24px;
  }
}
</style>

