<template>
  <div class="market-page">
    <div class="page-header">
      <h1>📦 商品市场</h1>
    </div>
    
    <div class="market-content">
      <!-- 左侧：推荐区 -->
      <aside class="sidebar">
        <div class="recommend-section">
          <h2>💡 为你推荐</h2>
          
          <div class="recommend-mode">
            <button 
              v-for="m in modes" 
              :key="m.value"
              :class="['mode-btn', { active: mode === m.value }]"
              @click="switchMode(m.value)"
            >
              {{ m.label }}
            </button>
          </div>
          
          <div class="recommend-list">
            <div 
              v-for="item in recommendedItems" 
              :key="item.id"
              class="recommend-item"
              @click="goToDetail(item.id)"
            >
              <img :src="item.images?.[0] || 'https://via.placeholder.com/80'" :alt="item.title">
              <div class="item-info">
                <div class="item-title">{{ item.title }}</div>
                <div class="item-price">¥{{ item.price }}</div>
              </div>
            </div>
            
            <div v-if="recommendedItems.length === 0" class="empty-state">
              <p>暂无推荐</p>
              <p class="hint">多浏览、收藏商品后会有更精准的推荐哦~</p>
            </div>
          </div>
        </div>
      </aside>
      
      <!-- 右侧：商品列表 -->
      <main class="main-content">
        <div class="filter-bar">
          <select v-model="filterCategory" @change="applyFilter">
            <option value="">全部分类</option>
            <option value="电子产品">电子产品</option>
            <option value="教材">教材</option>
            <option value="生活用品">生活用品</option>
            <option value="服装">服装</option>
            <option value="运动器材">运动器材</option>
            <option value="自行车">自行车</option>
            <option value="其他">其他</option>
          </select>
          
          <select v-model="sortBy" @change="applySort">
            <option value="latest">最新发布</option>
            <option value="price-asc">价格从低到高</option>
            <option value="price-desc">价格从高到低</option>
          </select>
          
          <div class="search-box">
            <input 
              v-model="searchKeyword" 
              type="text" 
              placeholder="搜索商品..." 
              @input="applyFilter"
            />
          </div>
        </div>
        
        <div class="items-grid">
          <ItemCard 
            v-for="item in displayedItems" 
            :key="item.id" 
            :item="item"
          />
        </div>
        
        <div v-if="displayedItems.length === 0" class="empty-state">
          <p>😕 暂无商品</p>
          <p class="hint">试试调整筛选条件，或者发布第一个商品吧！</p>
        </div>
      </main>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import ItemCard from '../components/ItemCard.vue'
import { getItems, getCurrentUser } from '../utils/storage.js'
import { getRecommendedItems } from '../utils/recommend.js'

const router = useRouter()
const currentUser = ref(null)

// 推荐模式
const mode = ref('mixed')
const modes = [
  { value: 'mixed', label: '混合推荐' },
  { value: 'tag', label: '基于标签' },
  { value: 'collaborative', label: '协同过滤' }
]

// 筛选和排序
const filterCategory = ref('')
const sortBy = ref('latest')
const searchKeyword = ref('')

// 所有商品
const allItems = ref([])

// 推荐商品
const recommendedItems = ref([])

// 显示的商品（经过筛选和排序）
const displayedItems = computed(() => {
  let items = allItems.value.filter(item => item.status === 'ACTIVE')
  
  // 筛选分类
  if (filterCategory.value) {
    items = items.filter(item => item.category === filterCategory.value)
  }
  
  // 搜索关键词
  if (searchKeyword.value.trim()) {
    const keyword = searchKeyword.value.toLowerCase()
    items = items.filter(item => 
      item.title.toLowerCase().includes(keyword) ||
      item.description?.toLowerCase().includes(keyword) ||
      item.tags?.some(tag => tag.toLowerCase().includes(keyword))
    )
  }
  
  // 排序
  if (sortBy.value === 'latest') {
    items.sort((a, b) => b.createdAt - a.createdAt)
  } else if (sortBy.value === 'price-asc') {
    items.sort((a, b) => a.price - b.price)
  } else if (sortBy.value === 'price-desc') {
    items.sort((a, b) => b.price - a.price)
  }
  
  return items
})

onMounted(() => {
  currentUser.value = getCurrentUser()
  loadItems()
  loadRecommendations()
})

function loadItems() {
  allItems.value = getItems()
}

function loadRecommendations() {
  if (currentUser.value) {
    try {
      recommendedItems.value = getRecommendedItems(currentUser.value.id, mode.value)
    } catch (error) {
      console.error('推荐加载失败:', error)
      recommendedItems.value = []
    }
  }
}

function switchMode(newMode) {
  mode.value = newMode
  loadRecommendations()
}

function applyFilter() {
  // 触发计算属性重新计算
}

function applySort() {
  // 触发计算属性重新计算
}

function goToDetail(itemId) {
  router.push(`/item/${itemId}`)
}
</script>

<style scoped>
.market-page {
  padding: 20px 0;
}

.page-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 24px;
}

.page-header h1 {
  margin: 0;
  font-size: 28px;
  color: #333;
}

.market-content {
  display: grid;
  grid-template-columns: 240px 1fr;
  gap: 24px;
}

.sidebar {
  background: linear-gradient(135deg, #ffffff 0%, #f8f9ff 100%);
  border-radius: 16px;
  padding: 24px;
  height: fit-content;
  position: sticky;
  top: 84px;
  box-shadow: 0 4px 16px rgba(102, 126, 234, 0.15);
  border: 2px solid rgba(102, 126, 234, 0.1);
  animation: fadeIn 0.6s ease;
}

.recommend-section h2 {
  margin: 0 0 16px 0;
  font-size: 18px;
  color: #333;
}

.recommend-mode {
  display: flex;
  gap: 8px;
  margin-bottom: 16px;
  flex-wrap: wrap;
}

.mode-btn {
  padding: 6px 12px;
  border: 1px solid #ddd;
  background: white;
  border-radius: 16px;
  font-size: 12px;
  cursor: pointer;
  transition: all 0.3s;
}

.mode-btn:hover {
  border-color: #667eea;
  color: #667eea;
}

.mode-btn.active {
  background: #667eea;
  color: white;
  border-color: #667eea;
}

.recommend-list {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.recommend-item {
  display: flex;
  gap: 12px;
  padding: 12px;
  border-radius: 10px;
  background: white;
  cursor: pointer;
  transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
  border: 2px solid transparent;
  position: relative;
  overflow: hidden;
}

.recommend-item::before {
  content: '';
  position: absolute;
  top: 0;
  left: -100%;
  width: 100%;
  height: 100%;
  background: linear-gradient(90deg, transparent, rgba(102, 126, 234, 0.1), transparent);
  transition: left 0.5s;
}

.recommend-item:hover::before {
  left: 100%;
}

.recommend-item:hover {
  background: linear-gradient(135deg, #f8f9ff 0%, #ffffff 100%);
  transform: translateX(8px) scale(1.02);
  border-color: rgba(102, 126, 234, 0.3);
  box-shadow: 0 4px 12px rgba(102, 126, 234, 0.2);
}

.recommend-item img {
  width: 60px;
  height: 60px;
  border-radius: 6px;
  object-fit: cover;
}

.item-info {
  flex: 1;
  display: flex;
  flex-direction: column;
  justify-content: center;
}

.item-title {
  font-size: 14px;
  font-weight: 500;
  color: #333;
  margin-bottom: 4px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.item-price {
  font-size: 16px;
  font-weight: bold;
  color: #ff4757;
}

.main-content {
  min-height: 400px;
}

.filter-bar {
  display: flex;
  gap: 12px;
  margin-bottom: 20px;
  flex-wrap: wrap;
}

.filter-bar select {
  padding: 10px 16px;
  border: 1px solid #ddd;
  border-radius: 8px;
  background: white;
  font-size: 14px;
  cursor: pointer;
}

.search-box {
  flex: 1;
  min-width: 200px;
}

.search-box input {
  width: 100%;
  padding: 10px 16px;
  border: 1px solid #ddd;
  border-radius: 8px;
  font-size: 14px;
}

.search-box input:focus {
  outline: none;
  border-color: #667eea;
}

.items-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 20px;
}

@media (max-width: 1200px) {
  .items-grid {
    grid-template-columns: repeat(2, 1fr);
  }
}

@media (max-width: 768px) {
  .items-grid {
    grid-template-columns: 1fr;
  }
}

.empty-state {
  text-align: center;
  padding: 60px 20px;
  color: #999;
}

.empty-state p {
  margin: 8px 0;
}

.hint {
  font-size: 14px;
  color: #bbb;
}

@media (max-width: 968px) {
  .market-content {
    grid-template-columns: 1fr;
  }
  
  .sidebar {
    position: static;
  }
}
</style>

