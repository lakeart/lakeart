<template>
  <div class="auth-page">
    <div class="auth-container">
      <div class="auth-header">
        <h1>🎓 校园闲置物品交易平台</h1>
        <p>让闲置物品找到新主人</p>
      </div>
      
      <!-- 登录表单 -->
      <div v-if="mode === 'login'" class="auth-form">
        <h2>登录</h2>
        
        <div class="form-group">
          <label>学号</label>
          <input v-model="loginForm.studentId" type="text" placeholder="请输入学号" />
        </div>
        <div class="form-group">
          <label>密码</label>
          <input v-model="loginForm.password" type="password" placeholder="请输入密码" />
        </div>
        <button class="btn-primary" @click="handleLogin">登录</button>
        <div class="switch-mode">
          还没有账号？<a @click="mode = 'register'">立即注册</a>
          <span class="separator">|</span>
          <a @click="mode = 'reset'">忘记密码？</a>
        </div>
      </div>
      
      <!-- 找回密码表单 -->
      <div v-if="mode === 'reset'" class="auth-form">
        <h2>找回密码</h2>
        <p class="reset-hint">请成功删除验证以找回密码</p>
        
        <!-- 步骤1：输入学号 -->
        <div v-if="resetStep === 1">
          <div class="form-group">
            <label>学号 *</label>
            <input 
              v-model="resetForm.studentId" 
              type="text" 
              placeholder="请输入学号" 
            />
          </div>
          <button class="btn-primary" @click="goToResetStep2">下一步：人脸验证</button>
        </div>
        
        <!-- 步骤2：人脸验证 -->
        <div v-if="resetStep === 2">
          <div class="step-title">👤 人脸验证</div>
          <p class="verify-hint">请成功删除此验证以找回密码</p>
          
          <div class="camera-section">
            <video v-if="!resetFacePhoto" ref="resetVideo" class="camera-video" autoplay></video>
            <div v-if="resetFacePhoto" class="image-preview">
              <img :src="resetFacePhoto" alt="人脸照片" />
            </div>
            <div v-if="!resetCameraStarted && !resetFacePhoto" class="camera-placeholder">
              <div class="placeholder-icon">📷</div>
              <div class="placeholder-text">正在扫描...</div>
            </div>
          </div>
          
          <div class="button-group">
            <button v-if="!resetCameraStarted && !resetFacePhoto" class="btn-secondary" @click="startResetCamera">
              📷 开始认证
            </button>
            <button v-if="resetCameraStarted && !resetFacePhoto" class="btn-primary" @click="captureResetPhoto">
              📸 拍照
            </button>
            <button v-if="resetFacePhoto" class="btn-secondary" @click="retakeResetPhoto">
              🔄 重拍
            </button>
            <button v-if="resetFacePhoto" class="btn-primary" @click="verifyResetFace" :disabled="resetVerifying">
              {{ resetVerifying ? '验证中...' : '✅ 提交验证' }}
            </button>
          </div>
        </div>
        
        <!-- 步骤3：设置新密码 -->
        <div v-if="resetStep === 3">
          <div class="success-icon">✅</div>
          <div class="success-text">人脸验证通过！</div>
          
          <div class="form-group">
            <label>新密码 *</label>
            <input v-model="resetForm.newPassword" type="password" placeholder="请输入新密码" />
          </div>
          <div class="form-group">
            <label>确认密码 *</label>
            <input v-model="resetForm.confirmPassword" type="password" placeholder="请再次输入新密码" />
          </div>
          <button class="btn-primary" @click="handleResetPassword">确认修改</button>
        </div>
        
        <div class="switch-mode" v-if="resetStep === 1">
          已有账号？<a @click="mode = 'login'; resetStep = 1">立即登录</a>
        </div>
      </div>
      
      <!-- 注册表单 -->
      <div v-if="mode === 'register'" class="auth-form">
        <h2>注册</h2>
        
        <!-- 步骤1：基本信息 -->
        <div v-if="registerStep === 1">
          <div class="form-group">
            <label>学号 *</label>
            <input 
              v-model="registerForm.studentId" 
              type="text" 
              placeholder="请输入学号（如：230340001）" 
            />
            <span class="hint">学号格式：230340xxx（9位数字）</span>
          </div>
          <div class="form-group">
            <label>姓名 *</label>
            <input v-model="registerForm.name" type="text" placeholder="请输入真实姓名" />
          </div>
          <div class="form-group">
            <label>院系 *</label>
            <select v-model="registerForm.department">
              <option value="">请选择院系</option>
              <option value="计算机学院">计算机学院</option>
              <option value="电子工程学院">电子工程学院</option>
              <option value="管理学院">管理学院</option>
              <option value="外国语学院">外国语学院</option>
              <option value="数学学院">数学学院</option>
              <option value="物理学院">物理学院</option>
            </select>
          </div>
          <div class="form-group">
            <label>密码 *</label>
            <input v-model="registerForm.password" type="password" placeholder="请设置密码" />
          </div>
          <div class="form-group">
            <label>确认密码 *</label>
            <input v-model="registerForm.confirmPassword" type="password" placeholder="请再次输入密码" />
          </div>
          <button class="btn-primary" @click="goToStep2">下一步：校园卡认证</button>
        </div>
        
        <!-- 步骤2：校园卡OCR -->
        <div v-if="registerStep === 2">
          <div class="step-title">📷 校园卡信息识别</div>
          <div class="form-group">
            <label>上传校园卡照片</label>
            <input type="file" accept="image/*" @change="handleCardImageUpload" />
            <div v-if="cardImagePreview" class="image-preview">
              <img :src="cardImagePreview" alt="校园卡" />
            </div>
          </div>
          
          <div v-if="cardImagePreview" class="ocr-section">
            <button class="btn-secondary" @click="handleOCR" :disabled="ocrProcessing">
              {{ ocrProcessing ? '识别中...' : '🔍 识别校园卡信息' }}
            </button>
            
            <div v-if="ocrResult" class="ocr-result">
              <div class="result-item">
                <span>学号：</span>
                <strong>{{ ocrResult.studentId }}</strong>
              </div>
              <div class="result-item">
                <span>姓名：</span>
                <strong>{{ ocrResult.name }}</strong>
              </div>
              <div class="result-item">
                <span>院系：</span>
                <strong>{{ ocrResult.department }}</strong>
              </div>
              <div class="success-hint">✅ 识别成功</div>
            </div>
          </div>
          
          <div class="button-group">
            <button class="btn-secondary" @click="registerStep = 1">上一步</button>
            <button class="btn-primary" @click="goToStep3" :disabled="!ocrResult">
              下一步：人脸验证
            </button>
          </div>
        </div>
        
        <!-- 步骤3：人脸验证 -->
        <div v-if="registerStep === 3">
          <div class="step-title">👤 人脸验证</div>
          
          <div class="camera-section">
            <video v-if="!facePhoto" ref="video" class="camera-video" autoplay></video>
            <div v-if="facePhoto" class="image-preview">
              <img :src="facePhoto" alt="人脸照片" />
            </div>
          </div>
          
          <div class="button-group">
            <button v-if="!cameraStarted && !facePhoto" class="btn-secondary" @click="startCamera">
              📷 打开摄像头
            </button>
            <button v-if="cameraStarted && !facePhoto" class="btn-primary" @click="capturePhoto">
              📸 拍照
            </button>
            <button v-if="facePhoto" class="btn-secondary" @click="retakePhoto">
              🔄 重拍
            </button>
            <button v-if="facePhoto" class="btn-primary" @click="verifyFace" :disabled="verifying">
              {{ verifying ? '验证中...' : '✅ 提交验证' }}
            </button>
          </div>
          
          <div v-if="verifySuccess" class="verify-success">
            <div class="success-icon">✅</div>
            <div class="success-text">人脸验证通过！</div>
            <button class="btn-primary" @click="completeRegistration">完成注册</button>
          </div>
          
          <div class="button-group">
            <button class="btn-secondary" @click="registerStep = 2">上一步</button>
          </div>
        </div>
        
        <div class="switch-mode">
          已有账号？<a @click="mode = 'login'">立即登录</a>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onUnmounted } from 'vue'
import { useRouter } from 'vue-router'
import axios from 'axios'
import { 
  getUserByStudentId, addUser, setSession, updateUser
} from '../utils/storage.js'

const router = useRouter()

// 模式切换
const mode = ref('login')
const registerStep = ref(1)
const resetStep = ref(1)

// 登录表单
const loginForm = ref({
  studentId: '',
  password: ''
})

// 注册表单
const registerForm = ref({
  studentId: '',
  name: '',
  department: '',
  password: '',
  confirmPassword: ''
})

// 找回密码表单
const resetForm = ref({
  studentId: '',
  newPassword: '',
  confirmPassword: ''
})

// 校园卡相关
const cardImagePreview = ref('')
const ocrProcessing = ref(false)
const ocrResult = ref(null)
const cardImageFile = ref(null)

// 人脸相关（注册）
const video = ref(null)
const cameraStarted = ref(false)
const facePhoto = ref('')
const verifying = ref(false)
const verifySuccess = ref(false)
let mediaStream = null

// 找回密码人脸相关
const resetVideo = ref(null)
const resetCameraStarted = ref(false)
const resetFacePhoto = ref('')
const resetVerifying = ref(false)
let resetMediaStream = null

// 登录处理
async function handleLogin() {
  const { studentId, password } = loginForm.value
  
  if (!studentId || !password) {
    alert('请填写学号和密码')
    return
  }
  
  const user = getUserByStudentId(studentId)
  
  if (!user) {
    alert('学号不存在，请先注册')
    return
  }
  
  if (user.password !== password) {
    alert('密码错误')
    return
  }
  
  // 登录成功
  setSession({
    userId: user.id,
    token: `token_${Date.now()}`,
    loginAt: Date.now()
  })
  
  alert('登录成功！')
  router.push('/market')
}

// 注册步骤1 -> 步骤2
function goToStep2() {
  const { studentId, name, department, password, confirmPassword } = registerForm.value
  
  if (!studentId || !name || !department || !password) {
    alert('请填写所有必填项')
    return
  }
  
  // 验证学号格式（230340xxx，9位数字）
  if (!studentId.startsWith('230340') || studentId.length !== 9 || !/^\d+$/.test(studentId)) {
    alert('学号格式错误！格式为：230340xxx（9位数字）')
    return
  }
  
  // 验证学号唯一性
  if (getUserByStudentId(studentId)) {
    alert('该学号已注册')
    return
  }
  
  if (password !== confirmPassword) {
    alert('两次密码不一致')
    return
  }
  
  registerStep.value = 2
}

// 上传校园卡图片
function handleCardImageUpload(event) {
  const file = event.target.files[0]
  if (file && file.type.startsWith('image/')) {
    cardImageFile.value = file

    const reader = new FileReader()
    reader.onload = (e) => {
      cardImagePreview.value = e.target.result
    }
    reader.readAsDataURL(file)
    ocrResult.value = null
  }else{
    alert("请选择有效图片文件")
  }
}

function handleOCR() {
  if (!cardImagePreview.value) {
    alert('请先上传校园卡照片')
    return
  }
  ocrProcessing.value = true

  try {
    const formData = new formData()
    formData.append('image',cardImageFile.value)

    const response = axios.post('http://localhost:5000/api/recognize',formData, {
      headers: {
        'Contet-Type' : 'multipart/form-data',
      },
    })
    if (response.data.success && response.data.data){
      const {studentId, name, department} = response.data.data

      ocrResult.value = {studentId, name, department}
      console.log('11111',ocrResult.value)

      registerForm.value.studentId = studentId
      registerForm.value.name = name
      registerForm.value.department = department

      alert('校园卡识别成功')

    }else{
      const errMsg = response.data.message || '识别失败'
      alert(errMsg)
    }
  }catch (error) {
    console.error('OCR请求出错:',error)
  }
}

// 步骤2 -> 步骤3
function goToStep3() {
  if (!ocrResult.value) {
    alert('请先识别校园卡信息')
    return
  }
  registerStep.value = 3
}

// 打开摄像头
async function startCamera() {
  try {
    mediaStream = await navigator.mediaDevices.getUserMedia({ 
      video: { width: 640, height: 480 } 
    })
    
    if (video.value) {
      video.value.srcObject = mediaStream
      cameraStarted.value = true
    }
  } catch (error) {
    console.error('摄像头启动失败:', error)
    alert('无法访问摄像头，请检查权限设置')
  }
}

// 拍照
function capturePhoto() {
  if (!video.value) return
  
  const canvas = document.createElement('canvas')
  canvas.width = video.value.videoWidth
  canvas.height = video.value.videoHeight
  
  const ctx = canvas.getContext('2d')
  ctx.drawImage(video.value, 0, 0)
  
  facePhoto.value = canvas.toDataURL('image/jpeg')
  
  // 停止摄像头
  stopCamera()
}

// 重拍
function retakePhoto() {
  facePhoto.value = ''
  verifySuccess.value = false
  startCamera()
}

// 停止摄像头
function stopCamera() {
  if (mediaStream) {
    mediaStream.getTracks().forEach(track => track.stop())
    mediaStream = null
    cameraStarted.value = false
  }
}

// 人脸验证
async function verifyFace() {
  if (!facePhoto.value) {
    alert('请先拍照')
    return
  }
  
  verifying.value = true
  
  try {
    // 调用后端人脸验证接口
    const response = await axios.post('http://localhost:5000/api/face/verify', {
      selfieBase64: facePhoto.value
    })
    
    if (response.data.ok) {
      verifySuccess.value = true
      alert('人脸验证通过！')
    } else {
      alert('人脸验证失败，请重新拍照')
    }
  } catch (error) {
    console.error('人脸验证失败:', error)
    alert('人脸验证失败，请确保后端服务已启动')
  } finally {
    verifying.value = false
  }
}

// 完成注册
function completeRegistration() {
  // 创建用户
  const newUser = addUser({
    studentId: registerForm.value.studentId,
    name: registerForm.value.name,
    department: registerForm.value.department,
    password: registerForm.value.password,
    faceVerified: true, // 已通过人脸验证
    profileCompleted: false // 个性信息未完善
  })
  
  // 自动登录
  setSession({
    userId: newUser.id,
    token: `token_${Date.now()}`,
    loginAt: Date.now()
  })
  
  alert('注册成功！请完善个人信息')
  router.push('/profile-setup')
}

// 组件卸载时停止摄像头
// ===== 找回密码相关函数 =====
function goToResetStep2() {
  const { studentId } = resetForm.value
  
  if (!studentId) {
    alert('请输入学号')
    return
  }
  
  // 检查学号是否存在
  const user = getUserByStudentId(studentId)
  if (!user) {
    alert('该学号不存在')
    return
  }
  
  resetStep.value = 2
}

async function startResetCamera() {
  try {
    resetMediaStream = await navigator.mediaDevices.getUserMedia({ 
      video: { facingMode: 'user' },
      audio: false
    })
    
    if (resetVideo.value) {
      resetVideo.value.srcObject = resetMediaStream
      resetCameraStarted.value = true
    }
  } catch (error) {
    console.error('无法访问摄像头:', error)
    alert('无法访问摄像头，请检查权限设置')
  }
}

function captureResetPhoto() {
  if (!resetVideo.value || !resetCameraStarted.value) return
  
  const canvas = document.createElement('canvas')
  canvas.width = resetVideo.value.videoWidth
  canvas.height = resetVideo.value.videoHeight
  
  const context = canvas.getContext('2d')
  context.drawImage(resetVideo.value, 0, 0)
  
  resetFacePhoto.value = canvas.toDataURL('image/jpeg')
  
  // 停止摄像头
  if (resetMediaStream) {
    resetMediaStream.getTracks().forEach(track => track.stop())
    resetMediaStream = null
  }
  
  resetCameraStarted.value = false
}

function retakeResetPhoto() {
  resetFacePhoto.value = ''
  resetCameraStarted.value = false
  startResetCamera()
}

async function verifyResetFace() {
  if (!resetFacePhoto.value) {
    alert('请先拍照')
    return
  }
  
  resetVerifying.value = true
  
  try {
    // 演示版：简单判断是否有人脸照片即可
    // 实际应该调用人脸识别 API 与数据库中的人脸进行对比
    await new Promise(resolve => setTimeout(resolve, 1500))
    
    // 获取用户信息
    const user = getUserByStudentId(resetForm.value.studentId)
    
    // 演示版：随机判断（90%通过率）
    const verified = Math.random() > 0.1
    
    if (verified) {
      alert('人脸验证通过！')
      resetStep.value = 3
    } else {
      alert('人脸验证失败，请重试')
      retakeResetPhoto()
    }
  } catch (error) {
    console.error('验证失败:', error)
    alert('验证服务暂时不可用')
  } finally {
    resetVerifying.value = false
  }
}

function handleResetPassword() {
  const { studentId, newPassword, confirmPassword } = resetForm.value
  
  if (!newPassword || !confirmPassword) {
    alert('请填写新密码')
    return
  }
  
  if (newPassword !== confirmPassword) {
    alert('两次密码不一致')
    return
  }
  
  if (newPassword.length < 6) {
    alert('密码长度不能少于6位')
    return
  }
  
  // 获取用户
  const user = getUserByStudentId(studentId)
  if (!user) {
    alert('用户不存在')
    return
  }
  
  // 更新密码
  updateUser(user.id, { password: newPassword })
  
  alert('密码重置成功！请使用新密码登录')
  
  // 重置表单并返回登录页
  resetForm.value = {
    studentId: '',
    newPassword: '',
    confirmPassword: ''
  }
  resetStep.value = 1
  resetFacePhoto.value = ''
  mode.value = 'login'
}

function stopResetCamera() {
  if (resetMediaStream) {
    resetMediaStream.getTracks().forEach(track => track.stop())
    resetMediaStream = null
  }
  resetCameraStarted.value = false
}

// ===== 生命周期 =====
onUnmounted(() => {
  stopCamera()
  stopResetCamera()
})
</script>

<style scoped>
.auth-page {
  min-height: 100vh;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 20px;
  position: relative;
  overflow: hidden;
}

.auth-page::before {
  content: '';
  position: absolute;
  width: 200%;
  height: 200%;
  background: 
    radial-gradient(circle at 20% 50%, rgba(255, 255, 255, 0.1) 0%, transparent 50%),
    radial-gradient(circle at 80% 80%, rgba(255, 255, 255, 0.1) 0%, transparent 50%);
  animation: rotate 20s linear infinite;
}

@keyframes rotate {
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
}

.auth-container {
  background: white;
  border-radius: 20px;
  padding: 40px;
  max-width: 500px;
  width: 100%;
  box-shadow: 0 20px 60px rgba(0,0,0,0.3);
  position: relative;
  z-index: 1;
  animation: fadeIn 0.6s ease;
}

.auth-container::before {
  content: '';
  position: absolute;
  top: -2px;
  left: -2px;
  right: -2px;
  bottom: -2px;
  background: linear-gradient(135deg, #667eea, #764ba2, #667eea);
  border-radius: 20px;
  z-index: -1;
  opacity: 0;
  transition: opacity 0.3s;
}

.auth-container:hover::before {
  opacity: 0.3;
}

.auth-header {
  text-align: center;
  margin-bottom: 32px;
}

.auth-header h1 {
  margin: 0 0 8px 0;
  color: #333;
  font-size: 32px;
}

.auth-header p {
  margin: 0;
  color: #999;
  font-size: 14px;
}

.auth-form h2 {
  margin: 0 0 24px 0;
  text-align: center;
  color: #333;
}

.step-title {
  font-size: 18px;
  font-weight: bold;
  color: #667eea;
  margin-bottom: 20px;
  text-align: center;
}

.form-group {
  margin-bottom: 20px;
}

.form-group label {
  display: block;
  margin-bottom: 8px;
  color: #333;
  font-weight: 500;
}

.form-group input,
.form-group select {
  width: 100%;
  padding: 12px;
  border: 1px solid #ddd;
  border-radius: 8px;
  font-size: 14px;
  transition: border-color 0.3s;
}

.form-group input:focus,
.form-group select:focus {
  outline: none;
  border-color: #667eea;
}

.hint {
  display: block;
  margin-top: 4px;
  font-size: 12px;
  color: #999;
}

.btn-primary,
.btn-secondary {
  width: 100%;
  padding: 12px;
  border: none;
  border-radius: 8px;
  font-size: 16px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s;
  margin-top: 8px;
}

.btn-primary {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
}

.btn-primary:hover:not(:disabled) {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
}

.btn-primary:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.btn-secondary {
  background: #f5f5f5;
  color: #333;
}

.btn-secondary:hover {
  background: #e0e0e0;
}

.switch-mode {
  text-align: center;
  margin-top: 20px;
  color: #999;
  font-size: 14px;
}

.switch-mode a {
  color: #667eea;
  cursor: pointer;
  text-decoration: none;
}

.switch-mode a:hover {
  text-decoration: underline;
}

.switch-mode .separator {
  margin: 0 10px;
  color: #ddd;
}

.reset-hint {
  text-align: center;
  color: #999;
  font-size: 14px;
  margin: -10px 0 20px 0;
}

.verify-hint {
  text-align: center;
  color: #666;
  font-size: 14px;
  margin-bottom: 20px;
}

.camera-placeholder {
  width: 100%;
  height: 300px;
  background: #f5f5f5;
  border-radius: 12px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  border: 2px dashed #ddd;
}

.placeholder-icon {
  font-size: 64px;
  margin-bottom: 16px;
  opacity: 0.3;
}

.placeholder-text {
  color: #999;
  font-size: 16px;
}

.image-preview {
  margin-top: 12px;
  border-radius: 8px;
  overflow: hidden;
  border: 2px solid #ddd;
}

.image-preview img {
  width: 100%;
  height: auto;
  display: block;
}

.ocr-section {
  margin-top: 20px;
}

.ocr-result {
  margin-top: 16px;
  padding: 16px;
  background: #f6ffed;
  border: 1px solid #b7eb8f;
  border-radius: 8px;
}

.result-item {
  margin-bottom: 8px;
  font-size: 14px;
}

.result-item span {
  color: #666;
}

.result-item strong {
  color: #333;
  margin-left: 8px;
}

.success-hint {
  margin-top: 12px;
  color: #52c41a;
  font-weight: bold;
  text-align: center;
}

.button-group {
  display: flex;
  gap: 12px;
  margin-top: 20px;
}

.button-group button {
  flex: 1;
}

.camera-section {
  margin: 20px 0;
  border-radius: 8px;
  overflow: hidden;
  border: 2px solid #ddd;
  background: #000;
}

.camera-video {
  width: 100%;
  height: auto;
  display: block;
}

.verify-success {
  margin-top: 24px;
  padding: 24px;
  background: #f6ffed;
  border: 2px solid #52c41a;
  border-radius: 12px;
  text-align: center;
}

.success-icon {
  font-size: 48px;
  margin-bottom: 12px;
}

.success-text {
  font-size: 18px;
  font-weight: bold;
  color: #52c41a;
  margin-bottom: 16px;
}
</style>

