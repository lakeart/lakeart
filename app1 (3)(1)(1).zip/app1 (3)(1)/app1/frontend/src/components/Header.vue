<template>
  <header class="header">
    <div class="header-content">
      <div class="logo" @click="$router.push('/market')">
        🎓 校园闲置
      </div>
      
      <nav class="nav">
        <router-link to="/market" class="nav-link">商品市场</router-link>
        <router-link to="/publish" class="nav-link">发布商品</router-link>
        <router-link to="/community" class="nav-link">社区广场</router-link>
        <router-link to="/deal" class="nav-link">我的交易</router-link>
        <router-link to="/center" class="nav-link">
          通知中心
          <span v-if="unreadCount > 0" class="badge">{{ unreadCount }}</span>
        </router-link>
      </nav>
      
      <div class="user-section" v-if="currentUser">
        <div class="user-info" @click="$router.push('/me')">
          <div class="avatar">{{ currentUser.name[0] }}</div>
          <span class="username">{{ currentUser.name }}</span>
          <span class="credit" :class="getCreditClass(currentUser.credit)">
            {{ currentUser.credit }}分
          </span>
        </div>
        <button class="btn-logout" @click="handleLogout">退出</button>
      </div>
    </div>
  </header>
</template>

<script setup>
import { ref, computed, onMounted, watch } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { getCurrentUser, clearSession, getUserNotices } from '../utils/storage.js'

const router = useRouter()
const route = useRoute()
const currentUser = ref(null)
const unreadCount = ref(0)

function updateUnreadCount() {
  if (currentUser.value) {
    const notices = getUserNotices(currentUser.value.id)
    unreadCount.value = notices.filter(n => !n.read).length
  }
}

onMounted(() => {
  currentUser.value = getCurrentUser()
  updateUnreadCount()
  
  // 监听 storage 事件，当其他页面更新 localStorage 时刷新
  window.addEventListener('storage', updateUnreadCount)
})

// 监听路由变化，更新未读数量
watch(() => route.path, () => {
  updateUnreadCount()
})

function getCreditClass(credit) {
  if (credit >= 75) return 'credit-excellent'
  if (credit >= 60) return 'credit-good'
  return 'credit-normal'
}

function handleLogout() {
  if (confirm('确定要退出登录吗？')) {
    clearSession()
    router.push('/auth')
  }
}
</script>

<style scoped>
.header {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
  position: sticky;
  top: 0;
  z-index: 100;
}

.header-content {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 20px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 64px;
}

.logo {
  font-size: 24px;
  font-weight: bold;
  color: white;
  cursor: pointer;
  user-select: none;
}

.nav {
  display: flex;
  gap: 24px;
  flex: 1;
  justify-content: center;
}

.nav-link {
  color: rgba(255,255,255,0.9);
  text-decoration: none;
  padding: 8px 16px;
  border-radius: 4px;
  transition: all 0.3s;
  position: relative;
  font-weight: 500;
}

.nav-link:hover {
  background: rgba(255,255,255,0.1);
  color: white;
}

.nav-link.router-link-active {
  background: rgba(255,255,255,0.2);
  color: white;
}

.badge {
  position: absolute;
  top: 0;
  right: 0;
  background: #ff4757;
  color: white;
  font-size: 12px;
  padding: 2px 6px;
  border-radius: 10px;
  min-width: 18px;
  text-align: center;
}

.user-section {
  display: flex;
  align-items: center;
  gap: 12px;
}

.user-info {
  display: flex;
  align-items: center;
  gap: 8px;
  cursor: pointer;
  padding: 6px 12px;
  border-radius: 20px;
  transition: background 0.3s;
}

.user-info:hover {
  background: rgba(255,255,255,0.1);
}

.avatar {
  width: 36px;
  height: 36px;
  border-radius: 50%;
  background: linear-gradient(135deg, #ffd89b 0%, #19547b 100%);
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  font-weight: bold;
  font-size: 16px;
}

.username {
  color: white;
  font-weight: 500;
}

.credit {
  padding: 4px 8px;
  border-radius: 12px;
  font-size: 12px;
  font-weight: bold;
}

.credit-excellent {
  background: #52c41a;
  color: white;
}

.credit-good {
  background: #1890ff;
  color: white;
}

.credit-normal {
  background: #faad14;
  color: white;
}

.btn-logout {
  background: rgba(255,255,255,0.2);
  color: white;
  border: none;
  padding: 8px 16px;
  border-radius: 4px;
  cursor: pointer;
  font-size: 14px;
  transition: all 0.3s;
}

.btn-logout:hover {
  background: rgba(255,255,255,0.3);
}
</style>

