/**
 * 智能定价算法 - 基于原始价格
 * 根据用户输入的原始价格计算建议售价
 */

import { getItems } from './storage.js'

// 品类折旧系数（基于原始价格的百分比）
const CATEGORY_DEPRECIATION = {
  '电子产品': 0.65,   // 保留原价的65%
  '教材': 0.35,       // 保留原价的35%
  '服装': 0.45,       // 保留原价的45%
  '生活用品': 0.55,   // 保留原价的55%
  '运动器材': 0.60,   // 保留原价的60%
  '自行车': 0.70,     // 保留原价的70%
  '其他': 0.50        // 保留原价的50%
}

// 品牌溢价系数（在品类折旧基础上调整）
const BRAND_PREMIUMS = {
  '苹果': 1.15,
  '华为': 1.08,
  '戴尔': 1.05,
  '联想': 1.0,
  '小米': 0.95,
  '耐克': 1.1,
  '阿迪达斯': 1.05,
  '捷安特': 1.1,
  '美利达': 1.05,
  '高等教育出版社': 1.0,
  '清华大学出版社': 1.05,
  '机械工业出版社': 1.0,
  '宜家': 1.0,
  '无印良品': 1.08,
  '优衣库': 1.0,
  'ZARA': 1.05,
  '其他': 1.0
}

/**
 * 获取历史样本
 * 获取相同类别和品牌的历史成交数据
 */
function getHistorySamples(category, brand, limit = 50) {
  const items = getItems().filter(i => 
    i.originalPrice && 
    i.price && 
    i.price > 0 && 
    i.status === 'SOLD'
  )
  
  if (items.length === 0) return []

  // 按时间排序，新的在前
  const sortedItems = [...items].sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0))
  
  // 层级匹配策略
  const matchLevels = [
    // 层级1：同类别+同品牌
    sortedItems.filter(i => 
      i.category === category && 
      i.brand === brand
    ),
    // 层级2：同类别
    sortedItems.filter(i => 
      i.category === category
    )
  ]

  for (const samples of matchLevels) {
    if (samples.length >= 2) {
      // 返回折旧率数据
      return samples.slice(0, limit).map(s => ({
        originalPrice: s.originalPrice,
        soldPrice: s.price,
        depreciationRate: s.price / s.originalPrice
      }))
    }
  }

  return []
}

/**
 * 计算平均折旧率
 */
function calculateAverageDepreciation(samples) {
  if (samples.length === 0) return null
  
  const rates = samples.map(s => s.depreciationRate)
  const avgRate = rates.reduce((sum, rate) => sum + rate, 0) / rates.length
  
  return avgRate
}

/**
 * 生成建议售价 - 基于原始价格
 * @param {string} category - 商品类别
 * @param {string} brand - 品牌
 * @param {number} originalPrice - 原始价格（新品价格）
 */
export function generateSuggestedPrice(category, brand, originalPrice) {
  if (!originalPrice || originalPrice <= 0) {
    return {
      suggestedPrice: 0,
      minPrice: 0,
      maxPrice: 0,
      source: 'invalid',
      sampleCount: 0,
      confidence: 'low'
    }
  }
  
  // 1. 获取历史样本
  const historySamples = getHistorySamples(category, brand)
  
  let depreciationRate
  let source
  let sampleCount = 0
  
  // 决策逻辑：优先使用历史数据，否则使用默认折旧率
  if (historySamples.length >= 2) {
    // 有足够历史数据，使用平均折旧率
    depreciationRate = calculateAverageDepreciation(historySamples)
    source = 'history'
    sampleCount = historySamples.length
  } else {
    // 使用默认品类折旧率
    depreciationRate = CATEGORY_DEPRECIATION[category] || 0.50
    source = 'default'
    sampleCount = 0
  }
  
  // 应用品牌溢价系数
  const brandPremium = BRAND_PREMIUMS[brand] || 1.0
  depreciationRate *= brandPremium
  
  // 确保折旧率在合理范围内 (20%-90%)
  depreciationRate = Math.max(0.2, Math.min(0.9, depreciationRate))
  
  // 计算建议价格
  let suggestedPrice = Math.round(originalPrice * depreciationRate)
  
  // 价格合理性检查
  if (suggestedPrice < 1) suggestedPrice = 1
  if (suggestedPrice >= originalPrice) suggestedPrice = Math.round(originalPrice * 0.85)
  
  // 生成建议价格区间（±15%）
  const minPrice = Math.max(1, Math.round(suggestedPrice * 0.85))
  const maxPrice = Math.min(originalPrice, Math.round(suggestedPrice * 1.15))
  
  return {
    suggestedPrice,
    minPrice,
    maxPrice,
    source,
    sampleCount,
    depreciationRate: Math.round(depreciationRate * 100),
    confidence: calculateConfidenceLevel(source, sampleCount)
  }
}

/**
 * 计算价格置信度
 */
function calculateConfidenceLevel(source, sampleCount) {
  if (source === 'history' && sampleCount >= 5) return 'high'
  if (source === 'history' && sampleCount >= 2) return 'medium'
  if (source === 'seed' && sampleCount >= 3) return 'medium'
  return 'low'
}

/**
 * 获取所有可用的分类、品牌等选项
 */
export function getCategories() {
  return ['电子产品', '教材', '生活用品', '服装', '运动器材', '自行车', '其他']
}

export function getBrandsByCategory(category) {
  const brandMap = {
    '电子产品': ['苹果', '华为', '小米', '联想', '戴尔', '惠普', '其他'],
    '教材': ['高等教育出版社', '清华大学出版社', '机械工业出版社', '人民邮电出版社', '其他'],
    '生活用品': ['宜家', '无印良品', '网易严选', '其他'],
    '服装': ['优衣库', 'ZARA', 'H&M', '其他'],
    '运动器材': ['耐克', '阿迪达斯', '李宁', '安踏', '其他'],
    '自行车': ['捷安特', '美利达', '永久', '凤凰', '其他'],
    '其他': ['其他']
  }
  return brandMap[category] || ['其他']
}

/**
 * 价格合理性验证
 */
export function validatePrice(price, category, condition) {
  const minReasonable = getMinReasonablePrice(category)
  const maxReasonable = getMaxReasonablePrice(category)
  
  if (price < minReasonable) {
    return { valid: false, reason: `价格过低，该类商品通常不低于${minReasonable}元` }
  }
  
  if (price > maxReasonable) {
    return { valid: false, reason: `价格过高，该类商品通常不高于${maxReasonable}元` }
  }
  
  return { valid: true }
}

function getMinReasonablePrice(category) {
  const mins = {
    '电子产品': 50,
    '教材': 1,
    '生活用品': 1,
    '服装': 5,
    '运动器材': 10,
    '自行车': 30,
    '其他': 1
  }
  return mins[category] || 1
}

function getMaxReasonablePrice(category) {
  const maxs = {
    '电子产品': 20000,
    '教材': 100,
    '生活用品': 500,
    '服装': 500,
    '运动器材': 1000,
    '自行车': 2000,
    '其他': 1000
  }
  return maxs[category] || 1000
}