# Details

Date : 2025-11-17 09:48:41

Directory e:\\app1 (3)(1)

Total : 38 files,  11138 codes, 313 comments, 1741 blanks, all 13192 lines

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [app1/.augment/rules/r1.md](/app1/.augment/rules/r1.md) | Markdown | 24 | 0 | 21 | 45 |
| [app1/QUICKSTART.md](/app1/QUICKSTART.md) | Markdown | 189 | 0 | 60 | 249 |
| [app1/README.md](/app1/README.md) | Markdown | 66 | 0 | 22 | 88 |
| [app1/backend/app.py](/app1/backend/app.py) | Python | 103 | 8 | 16 | 127 |
| [app1/backend/requirements.txt](/app1/backend/requirements.txt) | pip requirements | 6 | 0 | 2 | 8 |
| [app1/frontend/index.html](/app1/frontend/index.html) | HTML | 12 | 0 | 2 | 14 |
| [app1/frontend/package-lock.json](/app1/frontend/package-lock.json) | JSON | 1,585 | 0 | 1 | 1,586 |
| [app1/frontend/package.json](/app1/frontend/package.json) | JSON | 21 | 0 | 1 | 22 |
| [app1/frontend/src/App.vue](/app1/frontend/src/App.vue) | Vue | 86 | 0 | 17 | 103 |
| [app1/frontend/src/components/EmptyState.vue](/app1/frontend/src/components/EmptyState.vue) | Vue | 54 | 0 | 8 | 62 |
| [app1/frontend/src/components/Header.vue](/app1/frontend/src/components/Header.vue) | Vue | 189 | 0 | 31 | 220 |
| [app1/frontend/src/components/ItemCard.vue](/app1/frontend/src/components/ItemCard.vue) | Vue | 193 | 0 | 33 | 226 |
| [app1/frontend/src/components/LoadingSpinner.vue](/app1/frontend/src/components/LoadingSpinner.vue) | Vue | 41 | 0 | 7 | 48 |
| [app1/frontend/src/main.js](/app1/frontend/src/main.js) | JavaScript | 16 | 1 | 4 | 21 |
| [app1/frontend/src/router/index.js](/app1/frontend/src/router/index.js) | JavaScript | 105 | 4 | 10 | 119 |
| [app1/frontend/src/styles/main.css](/app1/frontend/src/styles/main.css) | PostCSS | 154 | 7 | 30 | 191 |
| [app1/frontend/src/utils/api.js](/app1/frontend/src/utils/api.js) | JavaScript | 22 | 9 | 6 | 37 |
| [app1/frontend/src/utils/credit.js](/app1/frontend/src/utils/credit.js) | JavaScript | 123 | 35 | 26 | 184 |
| [app1/frontend/src/utils/init.js](/app1/frontend/src/utils/init.js) | JavaScript | 273 | 16 | 17 | 306 |
| [app1/frontend/src/utils/pricing.js](/app1/frontend/src/utils/pricing.js) | JavaScript | 162 | 42 | 31 | 235 |
| [app1/frontend/src/utils/recommend.js](/app1/frontend/src/utils/recommend.js) | JavaScript | 182 | 39 | 46 | 267 |
| [app1/frontend/src/utils/storage.js](/app1/frontend/src/utils/storage.js) | JavaScript | 482 | 66 | 94 | 642 |
| [app1/frontend/src/utils/storage\_backup.js](/app1/frontend/src/utils/storage_backup.js) | JavaScript | 365 | 33 | 84 | 482 |
| [app1/frontend/src/views/AuthPage.vue](/app1/frontend/src/views/AuthPage.vue) | Vue | 825 | 9 | 147 | 981 |
| [app1/frontend/src/views/CenterPage.vue](/app1/frontend/src/views/CenterPage.vue) | Vue | 454 | 2 | 80 | 536 |
| [app1/frontend/src/views/ChatPage.vue](/app1/frontend/src/views/ChatPage.vue) | Vue | 347 | 0 | 63 | 410 |
| [app1/frontend/src/views/CommunityPage.vue](/app1/frontend/src/views/CommunityPage.vue) | Vue | 429 | 2 | 77 | 508 |
| [app1/frontend/src/views/DealPage.vue](/app1/frontend/src/views/DealPage.vue) | Vue | 964 | 8 | 160 | 1,132 |
| [app1/frontend/src/views/ItemDetailPage.vue](/app1/frontend/src/views/ItemDetailPage.vue) | Vue | 489 | 3 | 85 | 577 |
| [app1/frontend/src/views/MarketPage.vue](/app1/frontend/src/views/MarketPage.vue) | Vue | 351 | 2 | 62 | 415 |
| [app1/frontend/src/views/MePage.vue](/app1/frontend/src/views/MePage.vue) | Vue | 537 | 6 | 89 | 632 |
| [app1/frontend/src/views/OrderPage.vue](/app1/frontend/src/views/OrderPage.vue) | Vue | 455 | 8 | 74 | 537 |
| [app1/frontend/src/views/ProfileSetupPage.vue](/app1/frontend/src/views/ProfileSetupPage.vue) | Vue | 455 | 4 | 64 | 523 |
| [app1/frontend/src/views/PublishPage.vue](/app1/frontend/src/views/PublishPage.vue) | Vue | 500 | 4 | 83 | 587 |
| [app1/frontend/src/views/RatingPage.vue](/app1/frontend/src/views/RatingPage.vue) | Vue | 491 | 5 | 78 | 574 |
| [app1/frontend/vite.config.js](/app1/frontend/vite.config.js) | JavaScript | 14 | 0 | 3 | 17 |
| [app1/如何添加真实商品图片.md](/app1/%E5%A6%82%E4%BD%95%E6%B7%BB%E5%8A%A0%E7%9C%9F%E5%AE%9E%E5%95%86%E5%93%81%E5%9B%BE%E7%89%87.md) | Markdown | 142 | 0 | 43 | 185 |
| [app1/改进说明.md](/app1/%E6%94%B9%E8%BF%9B%E8%AF%B4%E6%98%8E.md) | Markdown | 232 | 0 | 64 | 296 |

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)