# Summary

Date : 2025-11-17 09:48:41

Directory e:\\app1 (3)(1)

Total : 38 files,  11138 codes, 313 comments, 1741 blanks, all 13192 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| Vue | 17 | 6,860 | 53 | 1,158 | 8,071 |
| JavaScript | 10 | 1,744 | 245 | 321 | 2,310 |
| JSON | 2 | 1,606 | 0 | 2 | 1,608 |
| Markdown | 5 | 653 | 0 | 210 | 863 |
| PostCSS | 1 | 154 | 7 | 30 | 191 |
| Python | 1 | 103 | 8 | 16 | 127 |
| HTML | 1 | 12 | 0 | 2 | 14 |
| pip requirements | 1 | 6 | 0 | 2 | 8 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 38 | 11,138 | 313 | 1,741 | 13,192 |
| app1 | 38 | 11,138 | 313 | 1,741 | 13,192 |
| app1 (Files) | 4 | 629 | 0 | 189 | 818 |
| app1\\.augment | 1 | 24 | 0 | 21 | 45 |
| app1\\.augment\\rules | 1 | 24 | 0 | 21 | 45 |
| app1\\backend | 2 | 109 | 8 | 18 | 135 |
| app1\\frontend | 31 | 10,376 | 305 | 1,513 | 12,194 |
| app1\\frontend (Files) | 4 | 1,632 | 0 | 7 | 1,639 |
| app1\\frontend\\src | 27 | 8,744 | 305 | 1,506 | 10,555 |
| app1\\frontend\\src (Files) | 2 | 102 | 1 | 21 | 124 |
| app1\\frontend\\src\\components | 4 | 477 | 0 | 79 | 556 |
| app1\\frontend\\src\\router | 1 | 105 | 4 | 10 | 119 |
| app1\\frontend\\src\\styles | 1 | 154 | 7 | 30 | 191 |
| app1\\frontend\\src\\utils | 7 | 1,609 | 240 | 304 | 2,153 |
| app1\\frontend\\src\\views | 12 | 6,297 | 53 | 1,062 | 7,412 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)