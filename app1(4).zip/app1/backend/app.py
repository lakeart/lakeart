from flask import Flask, request, jsonify
from flask_cors import CORS
from flask_socketio import SocketIO, emit, join_room, leave_room
from paddleocr import PaddleOCR
from PIL import Image
import io
import re
import sys
import time
import logging

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# 检查 Python 版本
python_version = sys.version_info
logger.info(f'Python version: {python_version.major}.{python_version.minor}.{python_version.micro}')

if python_version.major < 3 or (python_version.major == 3 and python_version.minor < 8):
    raise RuntimeError('Python 3.8 or higher is required')

# 1. 初始化 Flask
app = Flask(__name__)
app.config['SECRET_KEY'] = 'campus-resale-demo-secret'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 限制上传文件大小为 16MB

CORS(app, resources={r"/*": {"origins": "*"}})

# 使用 threading 模式（兼容 Python 3.8-3.13）
socketio = SocketIO(
    app, 
    cors_allowed_origins="*", 
    async_mode='threading',
    logger=False,
    engineio_logger=False
)

# 2. 初始化 PaddleOCR（OCR 识别）
# 使用新版本API参数，兼容 Python 3.8-3.13
try:
    logger.info('Initializing PaddleOCR...')
    ocr = PaddleOCR(
        use_angle_cls=True, 
        lang='ch', 
        show_log=False,
        use_gpu=False  # 使用 CPU 模式，兼容性更好
    )
    logger.info('PaddleOCR initialized successfully')
except Exception as e:
    logger.error(f'Failed to initialize PaddleOCR: {str(e)}')
    raise

# ==================== 错误处理 ====================
@app.errorhandler(413)
def request_entity_too_large(error):
    """文件过大错误处理"""
    return jsonify({
        'success': False,
        'message': '上传文件过大，请确保文件小于 16MB'
    }), 413

@app.errorhandler(500)
def internal_server_error(error):
    """服务器错误处理"""
    logger.error(f'Internal server error: {str(error)}')
    return jsonify({
        'success': False,
        'message': '服务器内部错误，请稍后重试'
    }), 500

@app.errorhandler(404)
def not_found(error):
    """404错误处理"""
    return jsonify({
        'success': False,
        'message': '请求的资源不存在'
    }), 404

# ==================== REST API ====================
@app.route('/api/ping', methods=['GET'])
def ping():
    """健康检查"""
    return jsonify({
        'ok': True, 
        'message': 'Server is running',
        'python_version': f'{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}',
        'ocr_ready': ocr is not None
    })

@app.route('/api/health', methods=['GET'])
def health_check():
    """详细健康检查"""
    try:
        health_status = {
            'status': 'healthy',
            'python_version': sys.version,
            'ocr_initialized': ocr is not None,
            'socketio_mode': 'threading',
            'timestamp': int(time.time() * 1000)
        }
        return jsonify(health_status)
    except Exception as e:
        logger.error(f'Health check failed: {str(e)}')
        return jsonify({
            'status': 'unhealthy',
            'error': str(e)
        }), 500

@app.route('/api/recognize', methods=['POST'])
def recognize_image():
    """OCR识别校园卡信息"""
    try:
        # 1. 验证请求
        if 'image' not in request.files:
            logger.warning('No image file in request')
            return jsonify({'success': False, 'message': '请上传图片'}), 400
        
        file = request.files['image']
        if not file or not file.filename:
            logger.warning('Empty file uploaded')
            return jsonify({'success': False, 'message': '图片文件为空'}), 400
        
        # 2. 验证文件类型
        allowed_extensions = {'png', 'jpg', 'jpeg', 'bmp', 'webp'}
        file_ext = file.filename.rsplit('.', 1)[-1].lower() if '.' in file.filename else ''
        if file_ext not in allowed_extensions:
            logger.warning(f'Invalid file type: {file_ext}')
            return jsonify({'success': False, 'message': '不支持的图片格式，请上传 PNG、JPG、JPEG、BMP 或 WEBP 格式'}), 400
        
        # 3. 读取和验证图片
        image_data = file.read()
        if len(image_data) == 0:
            logger.warning('Empty image data')
            return jsonify({'success': False, 'message': '图片数据为空'}), 400
        
        # 验证图片是否可以打开
        try:
            image = Image.open(io.BytesIO(image_data))
            image.verify()  # 验证图片完整性
            logger.info(f'Image verified: {image.format}, {image.size}')
        except Exception as img_error:
            logger.error(f'Invalid image: {str(img_error)}')
            return jsonify({'success': False, 'message': '无效的图片文件'}), 400
        
        # 4. 用 PaddleOCR 识别文字
        logger.info('Starting OCR recognition...')
        result = ocr.ocr(image_data)
        
        if not result or not result[0]:
            logger.warning('No text detected in image')
            return jsonify({
                'success': True,
                'message': '未识别到文字，请确保图片清晰且包含文字信息',
                'data': {'studentId': '', 'name': '', 'department': ''},
                'texts': []
            })
        
        # 5. 提取所有文字
        texts = []
        for line in result[0]:
            if line and len(line) >= 2 and len(line[1]) >= 2:
                text = line[1][0]
                confidence = line[1][1]
                texts.append({"text": text, "confidence": float(confidence)})
        
        logger.info(f'OCR detected {len(texts)} text blocks')
        
        # 6. 智能解析校园卡信息
        card_info = parse_student_card(texts)
        
        # 返回结果
        message = '识别成功' if card_info['studentId'] else '识别完成，请手动补充信息'
        logger.info(f'Recognition completed: {message}')
        
        return jsonify({
            'success': True,
            'message': message,
            'data': card_info,
            'texts': texts
        })
        
    except Exception as e:
        logger.error(f'OCR recognition error: {str(e)}', exc_info=True)
        return jsonify({
            'success': False, 
            'message': f'识别失败: {str(e)}'
        }), 500


def parse_student_card(texts):
    """
    解析校园卡信息
    
    Args:
        texts: OCR识别结果列表，每项包含 text 和 confidence
        
    Returns:
        dict: 包含 studentId, name, department 的字典
    """
    student_id = None
    name = None
    department = None
    
    # 学号正则：230340xxx（9位数字）
    student_id_pattern = re.compile(r'230340\d{3}')
    
    # 院系关键词（按常见程度排序）
    departments = [
        '计算机学院', '电子工程学院', '管理学院', 
        '外国语学院', '数学学院', '物理学院',
        '机械学院', '材料学院', '化学学院',
        '生命科学学院', '经济学院', '法学院'
    ]
    
    # 排除关键词（避免误识别）
    exclude_keywords = ['学院', '校园卡', '学生证', '大学', '姓名', '学号', '院系']
    
    try:
        for item in texts:
            if not isinstance(item, dict) or 'text' not in item:
                continue
                
            text = item['text'].strip()
            if not text:
                continue
            
            # 识别学号（优先级最高）
            if not student_id:
                match = student_id_pattern.search(text)
                if match:
                    student_id = match.group()
                    logger.debug(f'Found student ID: {student_id}')
            
            # 识别院系
            if not department:
                for dept in departments:
                    if dept in text:
                        department = dept
                        logger.debug(f'Found department: {department}')
                        break
            
            # 识别姓名（2-4个中文字符）
            if not name and 2 <= len(text) <= 4:
                # 检查是否全是中文
                if all('\u4e00' <= char <= '\u9fff' for char in text):
                    # 排除包含关键词的文本
                    if not any(keyword in text for keyword in exclude_keywords):
                        name = text
                        logger.debug(f'Found name: {name}')
    
    except Exception as e:
        logger.error(f'Error parsing student card: {str(e)}')
    
    result = {
        'studentId': student_id or '',
        'name': name or '',
        'department': department or ''
    }
    
    logger.info(f'Parsed student card: {result}')
    return result

@app.route('/api/recognize/product', methods=['POST'])
def recognize_product():
    """识别商品图片中的文字信息（如品牌、型号等）"""
    try:
        # 1. 验证请求
        if 'image' not in request.files:
            logger.warning('No image file in product recognition request')
            return jsonify({'success': False, 'message': '请上传图片'}), 400
        
        file = request.files['image']
        if not file or not file.filename:
            logger.warning('Empty file in product recognition')
            return jsonify({'success': False, 'message': '图片文件为空'}), 400
        
        # 2. 验证文件类型
        allowed_extensions = {'png', 'jpg', 'jpeg', 'bmp', 'webp'}
        file_ext = file.filename.rsplit('.', 1)[-1].lower() if '.' in file.filename else ''
        if file_ext not in allowed_extensions:
            logger.warning(f'Invalid product image type: {file_ext}')
            return jsonify({'success': False, 'message': '不支持的图片格式'}), 400
        
        # 3. 读取图片
        image_data = file.read()
        if len(image_data) == 0:
            return jsonify({'success': False, 'message': '图片数据为空'}), 400
        
        # 验证图片
        try:
            image = Image.open(io.BytesIO(image_data))
            image.verify()
            logger.info(f'Product image verified: {image.format}, {image.size}')
        except Exception as img_error:
            logger.error(f'Invalid product image: {str(img_error)}')
            return jsonify({'success': False, 'message': '无效的图片文件'}), 400
        
        # 4. OCR识别
        logger.info('Starting product OCR recognition...')
        result = ocr.ocr(image_data)
        
        if not result or not result[0]:
            logger.warning('No text detected in product image')
            return jsonify({
                'success': True,
                'message': '未识别到文字',
                'data': {'brand': '', 'model': '', 'allTexts': []},
                'texts': []
            })
        
        # 5. 提取所有文字
        texts = []
        for line in result[0]:
            if line and len(line) >= 2 and len(line[1]) >= 2:
                text = line[1][0]
                confidence = line[1][1]
                texts.append({"text": text, "confidence": float(confidence)})
        
        logger.info(f'Product OCR detected {len(texts)} text blocks')
        
        # 6. 智能解析商品信息
        product_info = parse_product_info(texts)
        
        logger.info(f'Product recognition completed: brand={product_info["brand"]}, model={product_info["model"]}')
        
        return jsonify({
            'success': True,
            'message': '识别成功',
            'data': product_info,
            'texts': texts
        })
        
    except Exception as e:
        logger.error(f'Product recognition error: {str(e)}', exc_info=True)
        return jsonify({
            'success': False, 
            'message': f'识别失败: {str(e)}'
        }), 500


def parse_product_info(texts):
    """
    解析商品信息
    
    Args:
        texts: OCR识别结果列表
        
    Returns:
        dict: 包含 brand, model, allTexts 的字典
    """
    # 常见品牌关键词（按类别组织）
    brands = {
        '电子产品': [
            'Apple', 'iPhone', 'iPad', 'MacBook', 'AirPods', '苹果',
            '华为', 'HUAWEI', 'Mate', 'P系列',
            '小米', 'Xiaomi', 'Redmi', 'Mi',
            'OPPO', 'vivo', 'iQOO', 'Realme',
            '三星', 'Samsung', 'Galaxy',
            '联想', 'Lenovo', 'ThinkPad', 'IdeaPad',
            'Dell', '戴尔', 'XPS', 'Inspiron',
            'HP', '惠普', 'Pavilion', 'EliteBook',
            'ASUS', '华硕', 'ROG', 'ZenBook',
            'Acer', '宏碁',
            'Surface', 'Microsoft', '微软',
            'Sony', '索尼', 'PlayStation',
            'Nintendo', '任天堂', 'Switch'
        ],
        '图书': [
            '人民邮电出版社', '机械工业出版社', '清华大学出版社',
            '电子工业出版社', '高等教育出版社', '北京大学出版社',
            'O\'Reilly', '图灵', '博文视点', '异步社区'
        ],
        '运动': [
            'Nike', '耐克', 'Air Jordan', 'Air Max',
            'Adidas', '阿迪达斯', 'Yeezy', 'Ultraboost',
            'Puma', '彪马',
            'New Balance', 'NB',
            'Under Armour', 'UA',
            'Reebok', '锐步',
            '李宁', 'LINING', 'Li-Ning',
            '安踏', 'ANTA',
            '特步', 'XTEP',
            '361度'
        ]
    }
    
    detected_brand = None
    detected_model = None
    all_texts = []
    
    try:
        # 提取所有文本
        for item in texts:
            if isinstance(item, dict) and 'text' in item:
                text = item['text'].strip()
                if text:
                    all_texts.append(text)
        
        # 合并所有文本用于品牌检测
        combined_text = ' '.join(all_texts)
        
        # 检测品牌（按优先级）
        for category, brand_list in brands.items():
            for brand in brand_list:
                # 不区分大小写匹配
                if brand.lower() in combined_text.lower():
                    detected_brand = brand
                    logger.debug(f'Found brand: {brand} in category: {category}')
                    break
            if detected_brand:
                break
        
        # 检测型号（多种模式）
        model_patterns = [
            re.compile(r'[A-Z]{1,3}[-\s]?\d{2,4}[A-Z]?'),  # 如: X-1000, T14
            re.compile(r'\d{1,2}[A-Z]{1,3}[-\s]?\d{0,3}'),  # 如: 14Pro, 13
            re.compile(r'[A-Z][a-z]+\s?\d+'),  # 如: iPhone14, Mate40
        ]
        
        for item in texts:
            if not isinstance(item, dict) or 'text' not in item:
                continue
                
            text = item['text'].strip()
            for pattern in model_patterns:
                match = pattern.search(text)
                if match and len(match.group()) >= 2:
                    detected_model = match.group().strip()
                    logger.debug(f'Found model: {detected_model}')
                    break
            if detected_model:
                break
    
    except Exception as e:
        logger.error(f'Error parsing product info: {str(e)}')
    
    result = {
        'brand': detected_brand or '',
        'model': detected_model or '',
        'allTexts': all_texts
    }
    
    logger.info(f'Parsed product info: brand={result["brand"]}, model={result["model"]}, texts_count={len(all_texts)}')
    return result


@app.route('/api/face/verify', methods=['POST'])
def face_verify():
    """人脸验证（演示）"""
    try:
        data = request.get_json()
        if not data:
            return jsonify({'ok': False, 'message': '请求数据为空'}), 400
            
        selfie_base64 = data.get('selfieBase64', '')
        
        if not selfie_base64:
            return jsonify({'ok': False, 'message': '请上传人脸照片'}), 400
            
        if not selfie_base64.startswith('data:image/'):
            return jsonify({'ok': False, 'message': '无效的图片格式'}), 400
        
        # 演示版：简单验证base64格式
        logger.info('Face verification passed (demo mode)')
        
        return jsonify({
            'ok': True, 
            'message': '人脸验证通过（演示）'
        })
        
    except Exception as e:
        logger.error(f'Face verification error: {str(e)}')
        return jsonify({
            'ok': False, 
            'message': f'验证失败: {str(e)}'
        }), 500

@app.route('/api/payment/create', methods=['POST'])
def create_payment():
    """创建支付订单（演示）"""
    try:
        data = request.get_json()
        if not data:
            return jsonify({'ok': False, 'message': '请求数据为空'}), 400
            
        order_id = data.get('orderId')
        amount = data.get('amount')
        item_title = data.get('itemTitle', '')
        
        if not order_id or not amount:
            return jsonify({'ok': False, 'message': '订单信息不完整'}), 400
        
        import time
        time.sleep(1)  # 模拟支付处理
        
        logger.info(f'Payment created: order={order_id}, amount={amount}')
        
        return jsonify({
            'ok': True,
            'message': '支付成功（演示版，无需实际支付）',
            'data': {
                'orderId': order_id,
                'transactionId': f'TXN_{int(time.time() * 1000)}',
                'amount': amount,
                'status': 'SUCCESS'
            }
        })
    except Exception as e:
        logger.error(f'Payment error: {str(e)}')
        return jsonify({'ok': False, 'message': f'支付失败: {str(e)}'}), 500

# ==================== WebSocket ====================
@socketio.on('connect')
def handle_connect():
    """客户端连接"""
    try:
        logger.info(f'Client connected: {request.sid}')
        emit('connected', {
            'message': '已连接到服务器',
            'sid': request.sid,
            'timestamp': int(time.time() * 1000)
        })
    except Exception as e:
        logger.error(f'Connection error: {str(e)}')

@socketio.on('disconnect')
def handle_disconnect():
    """客户端断开连接"""
    try:
        logger.info(f'Client disconnected: {request.sid}')
    except Exception as e:
        logger.error(f'Disconnection error: {str(e)}')

@socketio.on('join')
def handle_join(data):
    """加入聊天室"""
    try:
        if not data:
            logger.warning('Empty join data')
            return
            
        deal_id = data.get('dealId')
        user_id = data.get('userId')
        
        if not deal_id or not user_id:
            logger.warning(f'Invalid join data: {data}')
            return
        
        room = f'deal:{deal_id}'
        join_room(room)
        
        logger.info(f'User {user_id} joined room {room}')
        
        emit('user_joined', {
            'userId': user_id,
            'message': f'用户 {user_id} 加入了聊天',
            'timestamp': int(time.time() * 1000)
        }, room=room, skip_sid=request.sid)
        
    except Exception as e:
        logger.error(f'Join room error: {str(e)}')

@socketio.on('leave')
def handle_leave(data):
    """离开聊天室"""
    try:
        if not data:
            logger.warning('Empty leave data')
            return
            
        deal_id = data.get('dealId')
        user_id = data.get('userId')
        
        if not deal_id or not user_id:
            logger.warning(f'Invalid leave data: {data}')
            return
        
        room = f'deal:{deal_id}'
        leave_room(room)
        
        logger.info(f'User {user_id} left room {room}')
        
        emit('user_left', {
            'userId': user_id,
            'message': f'用户 {user_id} 离开了聊天',
            'timestamp': int(time.time() * 1000)
        }, room=room)
        
    except Exception as e:
        logger.error(f'Leave room error: {str(e)}')

@socketio.on('msg')
def handle_message(data):
    """处理聊天消息"""
    try:
        if not data:
            logger.warning('Empty message data')
            return
            
        deal_id = data.get('dealId')
        from_user_id = data.get('fromUserId')
        text = data.get('text')
        timestamp = data.get('timestamp')
        
        if not all([deal_id, from_user_id, text]):
            logger.warning(f'Invalid message data: {data}')
            return
        
        room = f'deal:{deal_id}'
        
        logger.info(f'Message in {room} from {from_user_id}: {text[:50]}...')
        
        emit('new_message', {
            'dealId': deal_id,
            'fromUserId': from_user_id,
            'text': text,
            'timestamp': timestamp or int(time.time() * 1000)
        }, room=room)
        
    except Exception as e:
        logger.error(f'Message handling error: {str(e)}')

@socketio.on_error_default
def default_error_handler(e):
    """WebSocket 默认错误处理"""
    logger.error(f'WebSocket error: {str(e)}', exc_info=True)

# 4. 启动 Flask + SocketIO
if __name__ == '__main__':
    try:
        logger.info('='*60)
        logger.info('Flask server starting...')
        logger.info(f'Python version: {sys.version}')
        logger.info(f'Server URL: http://localhost:5000')
        logger.info(f'WebSocket mode: threading')
        logger.info('='*60)
        
        # 启动服务器
        socketio.run(
            app, 
            host='0.0.0.0', 
            port=5000, 
            debug=True,
            use_reloader=True,
            log_output=True
        )
    except KeyboardInterrupt:
        logger.info('Server stopped by user')
    except Exception as e:
        logger.error(f'Server error: {str(e)}', exc_info=True)
        raise