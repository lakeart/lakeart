/**
 * 信用积分计算与头衔判定
 */

import { getUserById, updateUser, addCreditLog, getRatings, getDeals } from './storage.js'

/**
 * 根据评分更新信用分
 * @param {string} userId - 被评价的用户ID
 * @param {number} stars - 星级 (1-5)
 * @param {string} dealId - 交易ID
 * @param {boolean} isCompleted - 是否完成交易
 * @param {boolean} hasDispute - 是否有纠纷
 * @param {string} role - 角色：'buyer' 买家 或 'seller' 卖家
 */
export function updateCreditScore(userId, stars, dealId, isCompleted = true, hasDispute = false, role = 'seller') {
  const user = getUserById(userId)
  if (!user) return
  
  // 确定使用哪个信用分字段
  const creditField = role === 'buyer' ? 'buyerCredit' : 'sellerCredit'
  const oldCredit = user[creditField] || 60
  let delta = 0
  const reasons = []
  
  // 1. 星级得分：(星级 - 3) × 0.5
  const starsDelta = (stars - 3) * 0.5
  delta += starsDelta
  reasons.push(`评分${stars}星: ${starsDelta > 0 ? '+' : ''}${starsDelta.toFixed(1)}`)
  
  // 2. 完成度加分
  if (isCompleted) {
    delta += 0.2
    reasons.push('完成交易: +0.2')
  }
  
  // 3. 纠纷扣分
  if (hasDispute) {
    delta -= 0.5
    reasons.push('存在纠纷: -0.5')
  }
  
  // 更新对应的信用分
  const newCredit = Math.max(0, Math.min(100, oldCredit + delta)) // 限制在 0-100
  const updates = {
    [creditField]: newCredit,
    credit: role === 'seller' ? newCredit : user.sellerCredit || 60 // credit 字段保持为卖家信用分（兼容性）
  }
  updateUser(userId, updates)
  
  // 记录日志
  addCreditLog({
    userId,
    delta,
    oldCredit,
    newCredit,
    reason: `${role === 'buyer' ? '买家' : '卖家'}信用分: ${reasons.join('; ')}`,
    dealId,
    role
  })
  
  return {
    oldCredit,
    newCredit,
    delta,
    reasons,
    role
  }
}

/**
 * 计算用户的好评数和差评数
 */
export function getUserRatingStats(userId) {
  const allDeals = getDeals()
  const userDeals = allDeals.filter(d => 
    (d.buyerId === userId || d.sellerId === userId) && 
    d.status === 'DONE'
  )
  
  const allRatings = getRatings()
  
  let goodCount = 0  // 4-5星
  let badCount = 0   // 1-2星
  let totalCount = 0
  
  userDeals.forEach(deal => {
    // 找到对该用户的评分
    const rating = allRatings.find(r => 
      r.dealId === deal.id && 
      r.rateeId === userId  // 被评价者
    )
    
    if (rating) {
      totalCount++
      if (rating.stars >= 4) {
        goodCount++
      } else if (rating.stars <= 2) {
        badCount++
      }
    }
  })
  
  return {
    goodCount,
    badCount,
    totalCount,
    badRate: totalCount > 0 ? badCount / totalCount : 0
  }
}

/**
 * 计算用户近30天的成交数
 */
export function getRecentDealsCount(userId, days = 30) {
  const deals = getDeals()
  const cutoffTime = Date.now() - days * 24 * 60 * 60 * 1000
  
  return deals.filter(d => 
    d.sellerId === userId && 
    d.status === 'DONE' && 
    d.updatedAt && 
    d.updatedAt >= cutoffTime
  ).length
}

/**
 * 判定用户头衔
 * @returns {Array} 头衔列表
 */
export function getUserBadges(userId) {
  const user = getUserById(userId)
  if (!user) return []
  
  const badges = []
  const credit = user.credit || 60
  const stats = getUserRatingStats(userId)
  const recentDeals = getRecentDealsCount(userId, 30)
  
  // 1. 诚信之星：积分 ≥70 && 好评数 ≥3
  if (credit >= 70 && stats.goodCount >= 3) {
    badges.push({
      name: '诚信之星',
      icon: '⭐',
      color: '#FFD700',
      description: '信用积分≥70且好评≥3'
    })
  }
  
  // 2. 交易达人：积分 ≥75 && 好评数 ≥5
  if (credit >= 75 && stats.goodCount >= 5) {
    badges.push({
      name: '交易达人',
      icon: '🏆',
      color: '#FF6B6B',
      description: '信用积分≥75且好评≥5'
    })
  }
  
  // 3. 宝藏卖家：近30天3+成交 && 差评率<10%
  if (recentDeals >= 3 && stats.badRate < 0.1) {
    badges.push({
      name: '宝藏卖家',
      icon: '💎',
      color: '#4ECDC4',
      description: '近30天成交≥3且差评率<10%'
    })
  }
  
  return badges
}

/**
 * 获取信用等级描述
 */
export function getCreditLevel(credit) {
  if (credit >= 90) return { level: '极好', color: '#52C41A' }
  if (credit >= 75) return { level: '优秀', color: '#1890FF' }
  if (credit >= 60) return { level: '良好', color: '#13C2C2' }
  if (credit >= 40) return { level: '一般', color: '#FAAD14' }
  return { level: '较差', color: '#F5222D' }
}

