/**
 * 初始化样本数据
 */

import { 
  addUser, addItem, addFavorite, addView, 
  addDeal, addPost, addNotice, getUsers, getItems 
} from './storage.js'

/**
 * 生成样本数据（用于演示）
 */
export function generateSampleData() {
  // 检查是否已有数据
  if (getUsers().length > 0 || getItems().length > 0) {
    console.log('已存在数据，跳过样本生成')
    return false
  }
  
  console.log('开始生成样本数据...')
  
  // 1. 创建示例用户（已完善个性化信息）
  const users = [
    {
      studentId: '230340001',
      name: '张三',
      department: '计算机学院',
      password: '123456',
      gender: '男',
      college: '计算机学院',
      major: '计算机科学与技术',
      interests: ['电子产品', '教材', '运动器材'],
      buyerCredit: 76,
      sellerCredit: 80,
      credit: 78,
      faceVerified: true,
      profileCompleted: true
    },
    {
      studentId: '230340002',
      name: '李四',
      department: '计算机学院',
      password: '123456',
      gender: '女',
      college: '计算机学院',
      major: '软件工程',
      interests: ['教材', '美妆', '服装'],
      buyerCredit: 80,
      sellerCredit: 84,
      credit: 82,
      faceVerified: true,
      profileCompleted: true
    },
    {
      studentId: '230340003',
      name: '王五',
      department: '电子工程学院',
      password: '123456',
      gender: '男',
      college: '电子工程学院',
      major: '电子信息工程',
      interests: ['电子产品', '自行车', '摄影'],
      buyerCredit: 62,
      sellerCredit: 68,
      credit: 65,
      faceVerified: true,
      profileCompleted: true
    },
    {
      studentId: '230340004',
      name: '赵六',
      department: '管理学院',
      password: '123456',
      gender: '女',
      college: '管理学院',
      major: '工商管理',
      interests: ['教材', '生活用品', '服装'],
      buyerCredit: 70,
      sellerCredit: 74,
      credit: 72,
      faceVerified: true,
      profileCompleted: true
    },
    {
      studentId: '230340005',
      name: '小美',
      department: '外国语学院',
      password: '123456',
      gender: '女',
      college: '外国语学院',
      major: '英语',
      interests: ['教材', '文具', '美妆'],
      buyerCredit: 85,
      sellerCredit: 88,
      credit: 88,
      faceVerified: true,
      profileCompleted: true
    }
  ]
  
  const userIds = users.map(u => addUser(u).id)
  
  // 2. 创建示例商品（已添加原始价格字段）
  const items = [
    {
      sellerId: userIds[0],
      title: 'MacBook Pro 2020 13寸',
      description: '9成新，无划痕，性能完好，配充电器和包装盒',
      category: '电子产品',
      brand: '苹果',
      originalPrice: 9800,
      price: 6800,
      images: ['https://via.placeholder.com/400x300/4A90E2/FFFFFF?text=MacBook+Pro'],
      tags: ['笔记本', '苹果', '办公', '编程', '电子产品']
    },
    {
      sellerId: userIds[1],
      title: '高等数学（第七版）上下册',
      description: '同济大学版，笔记齐全，无破损',
      category: '教材',
      brand: '高等教育出版社',
      originalPrice: 89,
      price: 38,
      images: ['https://via.placeholder.com/400x300/E67E22/FFFFFF?text=Math+Book'],
      tags: ['教材', '数学', '考研']
    },
    {
      sellerId: userIds[0],
      title: 'iPad Air 4 64GB',
      description: '玫瑰金，带Apple Pencil一代，9.5成新',
      category: '电子产品',
      brand: '苹果',
      originalPrice: 4500,
      price: 3200,
      images: ['https://via.placeholder.com/400x300/E74C3C/FFFFFF?text=iPad+Air'],
      tags: ['平板', '苹果', '学习', '笔记', '电子产品']
    },
    {
      sellerId: userIds[2],
      title: '宜家书桌椅套装',
      description: '白色简约风，使用半年，无明显磨损',
      category: '生活用品',
      brand: '宜家',
      originalPrice: 450,
      price: 280,
      images: ['https://via.placeholder.com/400x300/27AE60/FFFFFF?text=Desk+Set'],
      tags: ['家具', '书桌', '学习', '生活用品']
    },
    {
      sellerId: userIds[3],
      title: 'Python编程：从入门到实践',
      description: '第二版，几乎全新，只看过前几章',
      category: '教材',
      brand: '人民邮电出版社',
      originalPrice: 99,
      price: 45,
      images: ['https://via.placeholder.com/400x300/16A085/FFFFFF?text=Python+Book'],
      tags: ['教材', '编程', 'Python']
    },
    {
      sellerId: userIds[2],
      title: '捷安特自行车',
      description: '通勤利器，7成新，骑行舒适',
      category: '自行车',
      brand: '捷安特',
      originalPrice: 1200,
      price: 650,
      images: ['https://via.placeholder.com/400x300/2980B9/FFFFFF?text=Bicycle'],
      tags: ['自行车', '代步', '运动']
    },
    {
      sellerId: userIds[0],
      title: '优衣库羽绒服',
      description: '黑色L码，去年冬天买的，穿过几次',
      category: '服装',
      brand: '优衣库',
      originalPrice: 499,
      price: 220,
      images: ['https://via.placeholder.com/400x300/34495E/FFFFFF?text=Jacket'],
      tags: ['服装', '冬装', '羽绒服']
    },
    {
      sellerId: userIds[1],
      title: '华为MatePad平板电脑',
      description: '11英寸，128GB，灰色，附赠键盘保护套',
      category: '电子产品',
      brand: '华为',
      originalPrice: 2599,
      price: 1800,
      images: ['https://via.placeholder.com/400x300/FF6B6B/FFFFFF?text=MatePad'],
      tags: ['平板', '华为', '办公', '电子产品']
    },
    {
      sellerId: userIds[4],
      title: '英语四级真题详解',
      description: '2023版，含听力音频，全新未用',
      category: '教材',
      brand: '高等教育出版社',
      originalPrice: 56,
      price: 28,
      images: ['https://via.placeholder.com/400x300/4ECDC4/FFFFFF?text=CET4+Book'],
      tags: ['教材', '英语', '四级']
    },
    {
      sellerId: userIds[3],
      title: '小米手环7 NFC版',
      description: '黑色，95成新，功能正常，含充电线',
      category: '运动器材',
      brand: '小米',
      originalPrice: 279,
      price: 180,
      images: ['https://via.placeholder.com/400x300/F39C12/FFFFFF?text=Mi+Band'],
      tags: ['智能手环', '运动', '健康', '运动器材']
    },
    {
      sellerId: userIds[2],
      title: 'ZARA女装风衣',
      description: '米色M码，去年秋季款，九成新',
      category: '服装',
      brand: 'ZARA',
      originalPrice: 599,
      price: 280,
      images: ['https://via.placeholder.com/400x300/E84393/FFFFFF?text=Trench+Coat'],
      tags: ['服装', '女装', '风衣']
    },
    {
      sellerId: userIds[0],
      title: '联想小新Pro14笔记本',
      description: 'i5-12500H，16G内存，512G固态，2.2K屏',
      category: '电子产品',
      brand: '联想',
      originalPrice: 5499,
      price: 3800,
      images: ['https://via.placeholder.com/400x300/6C5CE7/FFFFFF?text=Lenovo+Pro14'],
      tags: ['笔记本', '联想', '办公', '学习', '电子产品']
    },
    {
      sellerId: userIds[4],
      title: '无印良品收纳盒套装',
      description: '透明亚克力材质，全新，共6个不同大小',
      category: '生活用品',
      brand: '无印良品',
      originalPrice: 189,
      price: 120,
      images: ['https://via.placeholder.com/400x300/00B894/FFFFFF?text=Storage+Box'],
      tags: ['收纳', '整理', '生活用品']
    }
  ]
  
  const itemIds = items.map(item => addItem(item).id)
  
  // 3. 创建浏览和收藏记录
  addView(userIds[1], itemIds[0]) // 李四浏览MacBook
  addView(userIds[2], itemIds[0]) // 王五浏览MacBook
  addView(userIds[1], itemIds[2]) // 李四浏览iPad
  addFavorite(userIds[1], itemIds[0]) // 李四收藏MacBook
  addFavorite(userIds[2], itemIds[2]) // 王五收藏iPad
  
  // 4. 创建交易记录
  addDeal({
    itemId: itemIds[1],
    sellerId: userIds[1],
    buyerId: userIds[0],
    status: 'DONE'
  })
  
  // 5. 创建社区帖子
  addPost({
    userId: userIds[0],
    title: '校园二手交易小技巧分享',
    content: '大家好，我想分享一些二手交易的经验：1. 拍照要清晰 2. 描述要详细 3. 价格要合理...',
    likes: 5
  })
  
  addPost({
    userId: userIds[1],
    title: '求购二手kindle',
    content: '想买个kindle看书，有出的同学联系我～',
    likes: 2
  })
  
  // 6. 创建系统通知
  addNotice({
    userId: userIds[0],
    type: 'system',
    title: '欢迎使用校园闲置平台',
    content: '您已成功注册，快去发布您的闲置物品吧！'
  })
  
  console.log('✅ 样本数据生成完成')
  console.log(`- 用户: ${users.length} 个`)
  console.log(`- 商品: ${items.length} 件`)
  
  return true
}

/**
 * 清空并重新生成样本数据
 */
export function resetAndGenerateSampleData() {
  const { clearAllData } = require('./storage.js')
  clearAllData()
  return generateSampleData()
}

