﻿/**
 * localStorage 工具函数（优化版）
 * 所有数据以 CRD_ 前缀存储
 * 优化点：1. 数据压缩 2. 自动清理过期/冗余数据 3. 配额不足降级 4. 批量存储优化
 */
import LZString from 'lz-string'; // 需安装：npm install lz-string --save

// ==================== 配置项 ====================
const STORAGE_PREFIX = 'CRD_';
// 自动清理规则（根据业务调整）
const CLEANUP_RULES = {
  // 各存储项的最大保留数量/过期时间
  CRD_ITEMS: { maxCount: 50, expireDays: 90 }, // 商品最多存50条，保留90天
  CRD_VIEWS: { maxCount: 30, expireDays: 30 }, // 浏览记录最多30条，保留30天
  CRD_FAVS: { maxCount: 100, expireDays: 180 }, // 收藏最多100条，保留180天
  CRD_DEALS: { maxCount: 50, expireDays: 180 }, // 交易记录最多50条，保留180天
  CRD_NOTICES: { maxCount: 30, expireDays: 90 }, // 通知最多30条，保留90天
  CRD_MESSAGES: { maxCount: 100, expireDays: 90 }, // 消息最多100条，保留90天
  CRD_PRICE_LOGS: { maxCount: 50, expireDays: 60 }, // 定价日志最多50条，保留60天
  CRD_CREDIT_LOGS: { maxCount: 50, expireDays: 180 }, // 信用日志最多50条，保留180天
};

// ==================== 通用工具 ====================

/**
 * 数据清理：根据规则过滤过期/超量数据
 * @param {string} key 存储键名
 * @param {Array} data 待清理的数据（数组格式）
 * @returns {Array} 清理后的数据
 */
function cleanupData(key, data = []) {
  if (!Array.isArray(data) || data.length === 0) return data;

  const rule = CLEANUP_RULES[key];
  if (!rule) return data;

  const now = Date.now();
  let cleaned = data;

  // 1. 过滤过期数据（需数据包含 createdAt/ts/timestamp 字段）
  if (rule.expireDays > 0) {
    const expireMs = rule.expireDays * 24 * 60 * 60 * 1000;
    cleaned = cleaned.filter(item => {
      const createTime = item.createdAt || item.ts || item.timestamp;
      return createTime && (now - createTime) <= expireMs;
    });
  }

  // 2. 限制最大数量（超出部分保留最新的）
  if (rule.maxCount > 0 && cleaned.length > rule.maxCount) {
    // 按创建时间降序排序，取前N条
    cleaned.sort((a, b) => {
      const timeA = a.createdAt || a.ts || a.timestamp || 0;
      const timeB = b.createdAt || b.ts || b.timestamp || 0;
      return timeB - timeA;
    });
    cleaned = cleaned.slice(0, rule.maxCount);
  }

  return cleaned;
}

/**
 * 获取 localStorage 数据（自动解压）
 */
export function getStorage(key) {
  try {
    const fullKey = `${STORAGE_PREFIX}${key}`;
    const compressedData = localStorage.getItem(fullKey);
    if (!compressedData) return null;

    // 兼容旧数据（未压缩的直接解析）
    try {
      // 尝试直接JSON解析（旧数据）
      return JSON.parse(compressedData);
    } catch (e) {
      // 解压后解析（新数据）
      const jsonStr = LZString.decompress(compressedData);
      return jsonStr ? JSON.parse(jsonStr) : null;
    }
  } catch (error) {
    console.error(`读取 ${key} 失败:`, error);
    return null;
  }
}

/**
 * 存储 localStorage 数据（自动压缩+清理）
 */
export function setStorage(key, value) {
  try {
    const fullKey = `${STORAGE_PREFIX}${key}`;
    let data = value;

    // 1. 对数组型数据进行自动清理
    if (Array.isArray(data)) {
      data = cleanupData(fullKey, data);
    }

    // 2. 序列化并压缩
    const jsonStr = JSON.stringify(data);
    const compressedData = LZString.compress(jsonStr);

    // 3. 存储（如果压缩后更大，存储原始数据）
    const storageValue = compressedData.length < jsonStr.length ? compressedData : jsonStr;
    localStorage.setItem(fullKey, storageValue);

    return true;
  } catch (error) {
    console.error(`存储 ${key} 失败:`, error);

    // 4. 配额不足时的降级处理
    if (error.name === 'QuotaExceededError' || error.code === 22) {
      // 尝试清理最大体积的存储项
      cleanupLargestStorage();
      // 再次尝试存储（清理后可能有空间）
      try {
        const fullKey = `${STORAGE_PREFIX}${key}`;
        const jsonStr = JSON.stringify(value);
        const compressedData = LZString.compress(jsonStr);
        localStorage.setItem(fullKey, compressedData);
        alert('存储空间不足，已自动清理部分旧数据，存储成功！');
        return true;
      } catch (secondError) {
        alert('存储空间不足！建议:\n1. 清理部分不常用数据\n2. 减少上传图片的数量/大小\n3. 刷新页面重试');
        return false;
      }
    }

    return false;
  }
}

/**
 * 删除 localStorage 数据
 */
export function removeStorage(key) {
  try {
    const fullKey = `${STORAGE_PREFIX}${key}`;
    localStorage.removeItem(fullKey);
    return true;
  } catch (error) {
    console.error(`删除 ${key} 失败:`, error);
    return false;
  }
}

/**
 * 清空所有 CRD_ 开头的数据
 */
export function clearAllData() {
  const keys = Object.keys(localStorage).filter(key => key.startsWith(STORAGE_PREFIX));
  keys.forEach(key => localStorage.removeItem(key));
  console.log('已清空所有CRD相关数据');
  return true;
}

/**
 * 清理体积最大的存储项（配额不足时降级用）
 */
function cleanupLargestStorage() {
  const crdKeys = Object.keys(localStorage).filter(key => key.startsWith(STORAGE_PREFIX));
  if (crdKeys.length === 0) return;

  // 找到体积最大的存储项
  let largestKey = crdKeys[0];
  let largestSize = localStorage.getItem(largestKey).length;

  crdKeys.forEach(key => {
    const size = localStorage.getItem(key).length;
    if (size > largestSize) {
      largestSize = size;
      largestKey = key;
    }
  });

  // 清理该存储项（保留最新的10条数据，避免完全清空）
  const data = getStorage(largestKey.replace(STORAGE_PREFIX, '')) || [];
  if (Array.isArray(data) && data.length > 10) {
    // 保留最新的10条
    const sorted = data.sort((a, b) => {
      const timeA = a.createdAt || a.ts || a.timestamp || 0;
      const timeB = b.createdAt || b.ts || b.timestamp || 0;
      return timeB - timeA;
    });
    const trimmed = sorted.slice(0, 10);
    setStorage(largestKey.replace(STORAGE_PREFIX, ''), trimmed);
    console.log(`已清理存储项 ${largestKey}，保留最新10条数据`);
  } else {
    // 非数组或数量过少，直接删除
    localStorage.removeItem(largestKey);
    console.log(`已删除存储项 ${largestKey}`);
  }
}

/**
 * 生成唯一 ID
 */
export function generateId() {
  return `${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}

// ==================== 用户相关（无修改，兼容原有逻辑）====================
export function getUsers() {
  return getStorage('USERS') || [];
}

export function setUsers(users) {
  return setStorage('USERS', users);
}

export function addUser(user) {
  const users = getUsers();
  const newUser = {
    id: generateId(),
    buyerCredit: 100,
    sellerCredit: 100,
    credit: 100,
    faceVerified: false,
    createdAt: Date.now(),
    ...user
  };
  users.push(newUser);
  setUsers(users);
  return newUser;
}

export function updateUser(userId, updates) {
  const users = getUsers();
  const index = users.findIndex(u => u.id === userId);
  if (index !== -1) {
    users[index] = { ...users[index], ...updates };
    setUsers(users);
    return users[index];
  }
  return null;
}

export function getUserById(userId) {
  const users = getUsers();
  return users.find(u => u.id === userId);
}

export function getUserByStudentId(studentId) {
  const users = getUsers();
  return users.find(u => u.studentId === studentId);
}

// ==================== 会话相关（无修改）====================
export function getSession() {
  return getStorage('SESSION');
}

export function setSession(session) {
  return setStorage('SESSION', session);
}

export function clearSession() {
  return removeStorage('SESSION');
}

export function getCurrentUser() {
  const session = getSession();
  if (!session) return null;
  return getUserById(session.userId);
}

// ==================== 商品相关（优化批量操作）====================
export function getItems() {
  return getStorage('ITEMS') || [];
}

export function setItems(items) {
  return setStorage('ITEMS', items);
}

export function addItem(item) {
  const items = getItems();
  const newItem = {
    ...item,
    id: generateId(),
    status: 'ACTIVE', // ACTIVE, SOLD, REMOVED
    createdAt: Date.now()
  };
  items.push(newItem);
  return setItems(items) ? newItem : null;
}

export function updateItem(itemId, updates) {
  const items = getItems();
  const index = items.findIndex(i => i.id === itemId);
  if (index !== -1) {
    items[index] = { ...items[index], ...updates, updatedAt: Date.now() }; // 增加更新时间
    return setItems(items) ? items[index] : null;
  }
  return null;
}

export function getItemById(itemId) {
  const items = getItems();
  return items.find(i => i.id === itemId);
}

// ==================== 收藏相关（优化去重逻辑）====================
export function getFavorites() {
  return getStorage('FAVS') || [];
}

export function setFavorites(favs) {
  return setStorage('FAVS', favs);
}

export function addFavorite(userId, itemId) {
  const favs = getFavorites();
  // 去重（避免重复存储）
  if (!favs.some(f => f.userId === userId && f.itemId === itemId)) {
    favs.push({ userId, itemId, createdAt: Date.now() });
    setFavorites(favs);
  }
}

export function removeFavorite(userId, itemId) {
  const favs = getFavorites();
  const filtered = favs.filter(f => !(f.userId === userId && f.itemId === itemId));
  setFavorites(filtered);
}

export function isFavorited(userId, itemId) {
  const favs = getFavorites();
  return favs.some(f => f.userId === userId && f.itemId === itemId);
}

export function getUserFavorites(userId) {
  const favs = getFavorites();
  return favs.filter(f => f.userId === userId);
}

// ==================== 浏览记录（优化去重，避免重复记录）====================
export function getViews() {
  return getStorage('VIEWS') || [];
}

export function setViews(views) {
  return setStorage('VIEWS', views);
}

export function addView(userId, itemId) {
  const views = getViews();
  // 去重：同一用户10分钟内对同一商品的浏览记录只保留一条
  const tenMinutesMs = 10 * 60 * 1000;
  const recentView = views.find(
    v => v.userId === userId && v.itemId === itemId && (Date.now() - v.ts) < tenMinutesMs
  );
  if (!recentView) {
    views.push({ userId, itemId, ts: Date.now() });
    setViews(views);
  }
}

export function getUserViews(userId) {
  const views = getViews();
  return views.filter(v => v.userId === userId).sort((a, b) => b.ts - a.ts);
}

// ==================== 交易相关（无修改）====================
export function getDeals() {
  return getStorage('DEALS') || [];
}

export function setDeals(deals) {
  return setStorage('DEALS', deals);
}

export function addDeal(deal) {
  const deals = getDeals();
  const newDeal = {
    ...deal,
    id: generateId(),
    status: 'INTENT', // INTENT, DONE, CANCELLED
    createdAt: Date.now()
  };
  deals.push(newDeal);
  return setDeals(deals) ? newDeal : null;
}

export function updateDeal(dealId, updates) {
  const deals = getDeals();
  const index = deals.findIndex(d => d.id === dealId);
  if (index !== -1) {
    deals[index] = { ...deals[index], ...updates, updatedAt: Date.now() };
    return setDeals(deals) ? deals[index] : null;
  }
  return null;
}

export function getDealById(dealId) {
  const deals = getDeals();
  return deals.find(d => d.id === dealId);
}

// ==================== 评分相关（无修改）====================
export function getRatings() {
  return getStorage('RATINGS') || [];
}

export function setRatings(ratings) {
  return setStorage('RATINGS', ratings);
}

export function addOrUpdateRating(rating) {
  const ratings = getRatings();
  const index = ratings.findIndex(r => r.dealId === rating.dealId && r.raterId === rating.raterId);
  
  if (index !== -1) {
    ratings[index] = { ...ratings[index], ...rating, updatedAt: Date.now() };
  } else {
    ratings.push({ ...rating, createdAt: Date.now() });
  }
  
  return setRatings(ratings) ? (ratings[index] || ratings[ratings.length - 1]) : null;
}

export function getRatingsByDeal(dealId) {
  const ratings = getRatings();
  return ratings.filter(r => r.dealId === dealId);
}

// ==================== 信用日志（无修改）====================
export function getCreditLogs() {
  return getStorage('CREDIT_LOGS') || [];
}

export function setCreditLogs(logs) {
  return setStorage('CREDIT_LOGS', logs);
}

export function addCreditLog(log) {
  const logs = getCreditLogs();
  logs.push({
    ...log,
    id: generateId(),
    createdAt: Date.now()
  });
  return setCreditLogs(logs);
}

export function getUserCreditLogs(userId) {
  const logs = getCreditLogs();
  return logs.filter(l => l.userId === userId).sort((a, b) => b.createdAt - a.createdAt);
}

// ==================== 定价日志（无修改）====================
export function getPriceLogs() {
  return getStorage('PRICE_LOGS') || [];
}

export function setPriceLogs(logs) {
  return setStorage('PRICE_LOGS', logs);
}

export function addPriceLog(log) {
  const logs = getPriceLogs();
  logs.push({
    ...log,
    id: generateId(),
    createdAt: Date.now()
  });
  return setPriceLogs(logs);
}

// ==================== 社区相关（优化点赞去重）====================
export function getPosts() {
  return getStorage('POSTS') || [];
}

export function setPosts(posts) {
  return setStorage('POSTS', posts);
}

export function addPost(post) {
  const posts = getPosts();
  const newPost = {
    ...post,
    id: generateId(),
    createdAt: Date.now()
  };
  posts.push(newPost);
  return setPosts(posts) ? newPost : null;
}

export function getComments() {
  return getStorage('COMMENTS') || [];
}

export function setComments(comments) {
  return setStorage('COMMENTS', comments);
}

export function addComment(comment) {
  const comments = getComments();
  comments.push({
    ...comment,
    id: generateId(),
    createdAt: Date.now()
  });
  return setComments(comments);
}

export function getLikes() {
  return getStorage('LIKES') || [];
}

export function setLikes(likes) {
  return setStorage('LIKES', likes);
}

export function toggleLike(userId, postId) {
  const likes = getLikes();
  const index = likes.findIndex(l => l.userId === userId && l.postId === postId);
  
  if (index !== -1) {
    likes.splice(index, 1);
  } else {
    likes.push({ userId, postId, createdAt: Date.now() });
  }
  
  return setLikes(likes) ? (index === -1) : false;
}

// ==================== 通知相关（优化排序）====================
export function getNotices() {
  return getStorage('NOTICES') || [];
}

export function setNotices(notices) {
  return setStorage('NOTICES', notices);
}

export function addNotice(notice) {
  const notices = getNotices();
  notices.unshift({
    ...notice,
    id: generateId(),
    read: false,
    createdAt: Date.now()
  });
  return setNotices(notices);
}

export function markNoticeAsRead(noticeId) {
  const notices = getNotices();
  const index = notices.findIndex(n => n.id === noticeId);
  if (index !== -1) {
    notices[index].read = true;
    notices[index].readAt = Date.now();
    return setNotices(notices);
  }
  return false;
}

export function getUserNotices(userId) {
  const notices = getNotices();
  return notices.filter(n => n.userId === userId).sort((a, b) => b.createdAt - a.createdAt);
}

// ==================== 消息模板（无修改）====================
export function getTemplates() {
  return getStorage('TEMPLATES') || [];
}

export function setTemplates(templates) {
  return setStorage('TEMPLATES', templates);
}

export function addTemplate(template) {
  const templates = getTemplates();
  templates.push({
    ...template,
    id: generateId(),
    createdAt: Date.now()
  });
  return setTemplates(templates) ? template : null;
}

// ==================== 消息留痕（优化排序）====================
export function getMessages() {
  return getStorage('MESSAGES') || [];
}

export function setMessages(messages) {
  return setStorage('MESSAGES', messages);
}

export function addMessage(message) {
  const messages = getMessages();
  messages.push({
    ...message,
    id: generateId(),
    timestamp: Date.now()
  });
  return setMessages(messages);
}

export function getDealMessages(dealId) {
  const messages = getMessages();
  return messages.filter(m => m.dealId === dealId).sort((a, b) => a.timestamp - b.timestamp);
}

// ==================== 新增：手动清理指定类型数据 ====================
export function cleanupSpecificData(type) {
  const validTypes = Object.keys(CLEANUP_RULES).map(key => key.replace(STORAGE_PREFIX, ''));
  if (!validTypes.includes(type)) {
    console.error(`不支持清理类型：${type}，支持类型：${validTypes.join(',')}`);
    return false;
  }
  return setStorage(type, []); // 清空该类型数据
}

// ==================== 新增：查看存储占用情况 ====================
export function getStorageUsage() {
  const usage = {
    totalSize: 0,
    items: []
  };

  Object.keys(localStorage).forEach(key => {
    if (key.startsWith(STORAGE_PREFIX)) {
      const value = localStorage.getItem(key);
      const size = value.length;
      usage.totalSize += size;
      usage.items.push({
        key,
        size: (size / 1024).toFixed(2) + 'KB',
        rawSize: size
      });
    }
  });

  usage.totalSize = (usage.totalSize / 1024).toFixed(2) + 'KB';
  console.log('当前存储占用情况：', usage);
  return usage;
}