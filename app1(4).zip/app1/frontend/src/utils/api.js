/**
 * API 工具函数
 */

import axios from 'axios'

const API_BASE_URL = 'http://localhost:5000'

/**
 * 人脸验证
 */
export async function verifyFace(selfieBase64) {
  try {
    const response = await axios.post(`${API_BASE_URL}/api/face/verify`, {
      selfieBase64
    })
    return response.data
  } catch (error) {
    console.error('人脸验证失败:', error)
    throw error
  }
}

/**
 * 健康检查
 */
export async function pingServer() {
  try {
    const response = await axios.get(`${API_BASE_URL}/api/ping`)
    return response.data
  } catch (error) {
    console.error('服务器连接失败:', error)
    throw error
  }
}

