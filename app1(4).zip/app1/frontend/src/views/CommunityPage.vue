<template>
  <div class="community-page">
    <div class="page-header">
      <h1>🏛️ 社区广场</h1>
      <button class="btn-create" @click="showCreateModal = true">
        ✍️ 发帖
      </button>
    </div>
    
    <div class="posts-list">
      <div v-for="post in sortedPosts" :key="post.id" class="post-card">
        <div class="post-header">
          <div class="author-info" @click="goToUserProfile(post.userId)">
            <div class="author-avatar">{{ getAuthorName(post.userId)[0] }}</div>
            <div class="author-detail">
              <div class="author-name">{{ getAuthorName(post.userId) }}</div>
              <div class="post-time">{{ formatTime(post.createdAt) }}</div>
            </div>
          </div>
        </div>
        
        <div class="post-content">
          <h3 class="post-title">{{ post.title }}</h3>
          <p class="post-text">{{ post.content }}</p>
        </div>
        
        <div class="post-actions">
          <button 
            class="action-btn"
            :class="{ liked: isLiked(post.id) }"
            @click="toggleLike(post.id)"
          >
            {{ isLiked(post.id) ? '❤️' : '🤍' }} 
            {{ getLikeCount(post.id) }}
          </button>
          <button class="action-btn" @click="toggleComments(post.id)">
            💬 {{ getCommentCount(post.id) }}
          </button>
        </div>
        
        <!-- 评论区 -->
        <div v-if="expandedPostId === post.id" class="comments-section">
          <div class="comment-input">
            <input 
              v-model="commentInput"
              type="text" 
              placeholder="写下你的评论..."
              @keydown.enter="addComment(post.id)"
            />
            <button @click="addComment(post.id)">发送</button>
          </div>
          
          <div class="comments-list">
            <div 
              v-for="comment in getPostComments(post.id)" 
              :key="comment.id"
              class="comment-item"
            >
              <div class="comment-author">{{ getAuthorName(comment.userId) }}</div>
              <div class="comment-text">{{ comment.text }}</div>
              <div class="comment-time">{{ formatTime(comment.createdAt) }}</div>
            </div>
          </div>
        </div>
      </div>
      
      <div v-if="sortedPosts.length === 0" class="empty-state">
        <p>📝 还没有帖子</p>
        <p class="hint">成为第一个发帖的人吧！</p>
      </div>
    </div>
    
    <!-- 发帖弹窗 -->
    <div v-if="showCreateModal" class="modal-overlay" @click="closeCreateModal">
      <div class="modal-content" @click.stop>
        <h3>发布新帖</h3>
        
        <div class="form-group">
          <label>标题 *</label>
          <input v-model="postForm.title" type="text" placeholder="输入标题" maxlength="50" />
        </div>
        
        <div class="form-group">
          <label>内容 *</label>
          <textarea 
            v-model="postForm.content" 
            placeholder="分享你的想法..."
            rows="6"
          ></textarea>
        </div>
        
        <div class="modal-actions">
          <button class="btn-cancel" @click="closeCreateModal">取消</button>
          <button class="btn-submit" @click="createPost">发布</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { 
  getCurrentUser, getPosts, addPost, getComments, addComment as saveComment,
  getLikes, toggleLike as togglePostLike, getUserById
} from '../utils/storage.js'

const router = useRouter()
const currentUser = ref(null)

const showCreateModal = ref(false)
const postForm = ref({
  title: '',
  content: ''
})

const posts = ref([])
const comments = ref([])
const likes = ref([])
const expandedPostId = ref(null)
const commentInput = ref('')

const sortedPosts = computed(() => {
  return [...posts.value].sort((a, b) => b.createdAt - a.createdAt)
})

onMounted(() => {
  currentUser.value = getCurrentUser()
  loadData()
})

function loadData() {
  posts.value = getPosts()
  comments.value = getComments()
  likes.value = getLikes()
}

function getAuthorName(userId) {
  const user = getUserById(userId)
  return user?.name || '未知用户'
}

function getLikeCount(postId) {
  return likes.value.filter(l => l.postId === postId).length
}

function isLiked(postId) {
  if (!currentUser.value) return false
  return likes.value.some(l => l.postId === postId && l.userId === currentUser.value.id)
}

function toggleLike(postId) {
  if (!currentUser.value) {
    alert('请先登录')
    return
  }
  
  togglePostLike(currentUser.value.id, postId)
  loadData()
}

function getCommentCount(postId) {
  return comments.value.filter(c => c.postId === postId).length
}

function toggleComments(postId) {
  expandedPostId.value = expandedPostId.value === postId ? null : postId
}

function getPostComments(postId) {
  return comments.value
    .filter(c => c.postId === postId)
    .sort((a, b) => b.createdAt - a.createdAt)
}

function addComment(postId) {
  if (!commentInput.value.trim()) return
  
  saveComment({
    postId,
    userId: currentUser.value.id,
    text: commentInput.value.trim()
  })
  
  commentInput.value = ''
  loadData()
}

function closeCreateModal() {
  showCreateModal.value = false
  postForm.value = { title: '', content: '' }
}

function createPost() {
  if (!postForm.value.title || !postForm.value.content) {
    alert('请填写完整信息')
    return
  }
  
  addPost({
    userId: currentUser.value.id,
    title: postForm.value.title,
    content: postForm.value.content,
    likes: 0
  })
  
  alert('发布成功！')
  closeCreateModal()
  loadData()
}

function formatTime(timestamp) {
  const date = new Date(timestamp)
  return date.toLocaleString('zh-CN')
}

function goToUserProfile(userId) {
  // 跳转到用户主页（这里简化为跳转到"我的"页面）
  router.push('/me')
}
</script>

<style scoped>
.community-page {
  padding: 20px 0;
}

.page-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 24px;
}

.page-header h1 {
  margin: 0;
  font-size: 28px;
  color: #333;
}

.btn-create {
  padding: 10px 24px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  font-size: 16px;
  transition: all 0.3s;
}

.btn-create:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
}

.posts-list {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.post-card {
  background: white;
  border-radius: 12px;
  padding: 24px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}

.post-header {
  margin-bottom: 16px;
}

.author-info {
  display: flex;
  gap: 12px;
  cursor: pointer;
  width: fit-content;
}

.author-avatar {
  width: 48px;
  height: 48px;
  border-radius: 50%;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  font-weight: bold;
  font-size: 18px;
}

.author-detail {
  display: flex;
  flex-direction: column;
  justify-content: center;
}

.author-name {
  font-weight: 500;
  color: #333;
  margin-bottom: 4px;
}

.post-time {
  font-size: 12px;
  color: #999;
}

.post-content {
  margin-bottom: 16px;
}

.post-title {
  margin: 0 0 12px 0;
  font-size: 20px;
  color: #333;
}

.post-text {
  margin: 0;
  color: #666;
  line-height: 1.6;
  white-space: pre-wrap;
}

.post-actions {
  display: flex;
  gap: 16px;
  padding-top: 16px;
  border-top: 1px solid #f0f0f0;
}

.action-btn {
  padding: 8px 16px;
  background: #f5f5f5;
  border: none;
  border-radius: 20px;
  cursor: pointer;
  font-size: 14px;
  transition: all 0.3s;
  display: flex;
  align-items: center;
  gap: 4px;
}

.action-btn:hover {
  background: #e0e0e0;
}

.action-btn.liked {
  background: #ffe6e6;
  color: #ff4757;
}

.comments-section {
  margin-top: 16px;
  padding-top: 16px;
  border-top: 1px solid #f0f0f0;
}

.comment-input {
  display: flex;
  gap: 12px;
  margin-bottom: 16px;
}

.comment-input input {
  flex: 1;
  padding: 10px;
  border: 1px solid #ddd;
  border-radius: 6px;
  font-size: 14px;
}

.comment-input button {
  padding: 10px 20px;
  background: #1890ff;
  color: white;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  font-size: 14px;
}

.comments-list {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.comment-item {
  padding: 12px;
  background: #f9f9f9;
  border-radius: 8px;
}

.comment-author {
  font-size: 14px;
  font-weight: 500;
  color: #333;
  margin-bottom: 6px;
}

.comment-text {
  font-size: 14px;
  color: #666;
  margin-bottom: 6px;
  line-height: 1.5;
}

.comment-time {
  font-size: 12px;
  color: #999;
}

.empty-state {
  text-align: center;
  padding: 60px 20px;
  color: #999;
}

.hint {
  font-size: 14px;
  color: #bbb;
  margin-top: 8px;
}

/* 弹窗样式 */
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0,0,0,0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
}

.modal-content {
  background: white;
  border-radius: 12px;
  padding: 32px;
  max-width: 600px;
  width: 90%;
}

.modal-content h3 {
  margin: 0 0 24px 0;
  font-size: 20px;
  color: #333;
}

.form-group {
  margin-bottom: 20px;
}

.form-group label {
  display: block;
  margin-bottom: 8px;
  color: #333;
  font-weight: 500;
}

.form-group input,
.form-group textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ddd;
  border-radius: 8px;
  font-size: 14px;
  font-family: inherit;
}

.modal-actions {
  display: flex;
  gap: 12px;
  margin-top: 24px;
}

.btn-cancel,
.btn-submit {
  flex: 1;
  padding: 12px;
  border: none;
  border-radius: 8px;
  font-size: 16px;
  cursor: pointer;
  transition: all 0.3s;
}

.btn-cancel {
  background: #f5f5f5;
  color: #666;
}

.btn-submit {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
}
</style>

