<template>
  <div class="center-page">
    <h1>📬 通知中心</h1>
    
    <div class="tabs">
      <button 
        v-for="tab in tabs" 
        :key="tab.value"
        :class="['tab', { active: activeTab === tab.value }]"
        @click="activeTab = tab.value"
      >
        {{ tab.label }}
        <span class="count" v-if="getUnreadCount(tab.value) > 0">
          {{ getUnreadCount(tab.value) }}
        </span>
      </button>
    </div>
    
    <!-- 通知列表 -->
    <div v-if="activeTab === 'notices'" class="tab-content">
      <div class="notices-list">
        <div 
          v-for="notice in filteredNotices" 
          :key="notice.id"
          :class="['notice-item', { unread: !notice.read }]"
          @click="markAsRead(notice)"
        >
          <div class="notice-icon" :class="notice.type">
            {{ noticeIcons[notice.type] }}
          </div>
          <div class="notice-content">
            <div class="notice-title">{{ notice.title }}</div>
            <div class="notice-text">{{ notice.content }}</div>
            <div class="notice-time">{{ formatTime(notice.createdAt) }}</div>
          </div>
        </div>
        
        <div v-if="filteredNotices.length === 0" class="empty-state">
          <p>📭 暂无通知</p>
        </div>
      </div>
      
      <div class="actions" v-if="filteredNotices.length > 0">
        <button class="btn-action" @click="markAllAsRead">
          全部标记为已读
        </button>
      </div>
    </div>
    
    <!-- 消息模板管理 -->
    <div v-if="activeTab === 'templates'" class="tab-content">
      <h3>消息模板管理（演示）</h3>
      
      <div class="template-form">
        <div class="form-group">
          <label>模板标题</label>
          <input v-model="templateForm.title" type="text" placeholder="输入模板标题" />
        </div>
        
        <div class="form-group">
          <label>模板内容</label>
          <textarea v-model="templateForm.content" placeholder="输入模板内容" rows="4"></textarea>
        </div>
        
        <div class="form-group">
          <label>模板类型</label>
          <select v-model="templateForm.type">
            <option value="system">系统通知</option>
            <option value="deal">交易提醒</option>
            <option value="marketing">营销消息</option>
          </select>
        </div>
        
        <div class="form-actions">
          <button class="btn-primary" @click="addTemplate">保存模板</button>
          <button class="btn-secondary" @click="sendTestNotice">发送测试</button>
        </div>
      </div>
      
      <div class="templates-list">
        <h4>已有模板</h4>
        <div 
          v-for="template in templates" 
          :key="template.id"
          class="template-item"
        >
          <div class="template-info">
            <div class="template-title">{{ template.title }}</div>
            <div class="template-type">{{ typeLabels[template.type] }}</div>
          </div>
          <div class="template-content">{{ template.content }}</div>
        </div>
        
        <div v-if="templates.length === 0" class="empty-state">
          暂无模板
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { 
  getCurrentUser, getUserNotices, markNoticeAsRead,
  getNotices, setNotices, getTemplates, addTemplate as saveTemplate,
  addNotice
} from '../utils/storage.js'

const currentUser = ref(null)
const activeTab = ref('notices')

const tabs = [
  { value: 'notices', label: '我的通知' },
  { value: 'templates', label: '模板管理' }
]

const noticeIcons = {
  system: '📢',
  deal: '💼',
  rating: '⭐',
  marketing: '🎁'
}

const typeLabels = {
  system: '系统通知',
  deal: '交易提醒',
  marketing: '营销消息'
}

const notices = ref([])
const templates = ref([])
const templateForm = ref({
  title: '',
  content: '',
  type: 'system'
})

const filteredNotices = computed(() => {
  return notices.value.sort((a, b) => b.createdAt - a.createdAt)
})

onMounted(() => {
  currentUser.value = getCurrentUser()
  loadNotices()
  loadTemplates()
  initializeDefaultTemplates()
})

function loadNotices() {
  if (currentUser.value) {
    notices.value = getUserNotices(currentUser.value.id)
  }
}

function loadTemplates() {
  templates.value = getTemplates()
}

function initializeDefaultTemplates() {
  if (templates.value.length === 0) {
    // 创建默认模板
    const defaultTemplates = [
      {
        title: '欢迎新用户',
        content: '欢迎加入校园闲置平台！快去发布或浏览商品吧~',
        type: 'system'
      },
      {
        title: '交易完成提醒',
        content: '您的交易已完成，别忘了给对方评价哦！',
        type: 'deal'
      },
      {
        title: '开学季活动',
        content: '开学季以旧换新，快来参与吧！',
        type: 'marketing'
      }
    ]
    
    defaultTemplates.forEach(t => {
      saveTemplate(t)
    })
    
    loadTemplates()
  }
}

function getUnreadCount(tab) {
  if (tab === 'notices') {
    return notices.value.filter(n => !n.read).length
  }
  return 0
}

function markAsRead(notice) {
  if (!notice.read) {
    markNoticeAsRead(notice.id)
    loadNotices()
  }
}

function markAllAsRead() {
  const allNotices = getNotices()
  allNotices.forEach(n => {
    if (n.userId === currentUser.value.id) {
      n.read = true
    }
  })
  setNotices(allNotices)
  loadNotices()
  
  // 触发页面刷新以更新 Header 中的通知数量
  // 通过修改查询参数来触发路由更新
  window.dispatchEvent(new Event('storage'))
  
  alert('已全部标记为已读')
}

function addTemplate() {
  if (!templateForm.value.title || !templateForm.value.content) {
    alert('请填写完整信息')
    return
  }
  
  saveTemplate({
    title: templateForm.value.title,
    content: templateForm.value.content,
    type: templateForm.value.type
  })
  
  templateForm.value = {
    title: '',
    content: '',
    type: 'system'
  }
  
  loadTemplates()
  alert('模板保存成功')
}

function sendTestNotice() {
  if (!templateForm.value.title || !templateForm.value.content) {
    alert('请填写完整信息')
    return
  }
  
  addNotice({
    userId: currentUser.value.id,
    type: templateForm.value.type,
    title: templateForm.value.title,
    content: templateForm.value.content + '（测试）'
  })
  
  loadNotices()
  alert('测试通知已发送')
}

function formatTime(timestamp) {
  const date = new Date(timestamp)
  const now = new Date()
  const diff = now - date
  
  if (diff < 60000) {
    return '刚刚'
  } else if (diff < 3600000) {
    return `${Math.floor(diff / 60000)}分钟前`
  } else if (diff < 86400000) {
    return `${Math.floor(diff / 3600000)}小时前`
  } else if (diff < 604800000) {
    return `${Math.floor(diff / 86400000)}天前`
  } else {
    return date.toLocaleDateString('zh-CN')
  }
}
</script>

<style scoped>
.center-page {
  padding: 20px 0;
}

.center-page h1 {
  margin: 0 0 24px 0;
  font-size: 28px;
  color: #333;
}

.tabs {
  display: flex;
  gap: 12px;
  margin-bottom: 24px;
}

.tab {
  padding: 10px 20px;
  border: 1px solid #ddd;
  background: white;
  border-radius: 20px;
  cursor: pointer;
  transition: all 0.3s;
  font-size: 14px;
  display: flex;
  align-items: center;
  gap: 6px;
}

.tab:hover {
  border-color: #667eea;
  color: #667eea;
}

.tab.active {
  background: #667eea;
  color: white;
  border-color: #667eea;
}

.count {
  background: #ff4757;
  color: white;
  padding: 2px 8px;
  border-radius: 10px;
  font-size: 12px;
  font-weight: bold;
}

.tab-content {
  background: white;
  border-radius: 12px;
  padding: 24px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}

.notices-list {
  display: flex;
  flex-direction: column;
  gap: 12px;
  margin-bottom: 20px;
}

.notice-item {
  display: flex;
  gap: 16px;
  padding: 16px;
  background: #f9f9f9;
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.3s;
}

.notice-item:hover {
  background: #f0f0f0;
}

.notice-item.unread {
  background: #e6f7ff;
  border-left: 4px solid #1890ff;
}

.notice-icon {
  width: 48px;
  height: 48px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 24px;
  flex-shrink: 0;
}

.notice-icon.system {
  background: #e6f7ff;
}

.notice-icon.deal {
  background: #fff7e6;
}

.notice-icon.rating {
  background: #fff1f0;
}

.notice-icon.marketing {
  background: #f6ffed;
}

.notice-content {
  flex: 1;
}

.notice-title {
  font-size: 16px;
  font-weight: 500;
  color: #333;
  margin-bottom: 6px;
}

.notice-text {
  font-size: 14px;
  color: #666;
  margin-bottom: 8px;
  line-height: 1.6;
}

.notice-time {
  font-size: 12px;
  color: #999;
}

.actions {
  display: flex;
  justify-content: flex-end;
}

.btn-action {
  padding: 10px 20px;
  background: #1890ff;
  color: white;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  font-size: 14px;
  transition: all 0.3s;
}

.btn-action:hover {
  background: #40a9ff;
}

.tab-content h3,
.tab-content h4 {
  margin: 0 0 20px 0;
  font-size: 18px;
  color: #333;
}

.template-form {
  padding: 20px;
  background: #f9f9f9;
  border-radius: 8px;
  margin-bottom: 24px;
}

.form-group {
  margin-bottom: 16px;
}

.form-group label {
  display: block;
  margin-bottom: 8px;
  color: #333;
  font-weight: 500;
}

.form-group input,
.form-group select,
.form-group textarea {
  width: 100%;
  padding: 10px;
  border: 1px solid #ddd;
  border-radius: 6px;
  font-size: 14px;
  font-family: inherit;
}

.form-actions {
  display: flex;
  gap: 12px;
}

.btn-primary,
.btn-secondary {
  padding: 10px 24px;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  font-size: 14px;
  transition: all 0.3s;
}

.btn-primary {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
}

.btn-secondary {
  background: #52c41a;
  color: white;
}

.templates-list {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.template-item {
  padding: 16px;
  background: #f9f9f9;
  border-radius: 8px;
}

.template-info {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 8px;
}

.template-title {
  font-weight: 500;
  color: #333;
}

.template-type {
  font-size: 12px;
  padding: 2px 8px;
  background: #e6f7ff;
  color: #1890ff;
  border-radius: 4px;
}

.template-content {
  font-size: 14px;
  color: #666;
}

.empty-state {
  text-align: center;
  padding: 40px;
  color: #999;
}
</style>

