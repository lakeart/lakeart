<template>
  <div class="profile-setup-page">
    <div class="setup-container">
      <div class="setup-header">
        <h1>🎯 完善个人信息</h1>
        <p>帮助我们为您提供更精准的推荐</p>
      </div>
      
      <div class="setup-form">
        <!-- 性别 -->
        <div class="form-section">
          <h3>基本信息</h3>
          
          <div class="form-group">
            <label>性别 *</label>
            <div class="radio-group">
              <label class="radio-item">
                <input type="radio" v-model="form.gender" value="男" />
                <span>👨 男</span>
              </label>
              <label class="radio-item">
                <input type="radio" v-model="form.gender" value="女" />
                <span>👩 女</span>
              </label>
              <label class="radio-item">
                <input type="radio" v-model="form.gender" value="其他" />
                <span>🧑 其他</span>
              </label>
            </div>
          </div>
        </div>
        
        <!-- 学院和专业 -->
        <div class="form-section">
          <h3>学业信息</h3>
          
          <div class="form-group">
            <label>学院 *</label>
            <select v-model="form.college" @change="onCollegeChange">
              <option value="">请选择学院</option>
              <option value="计算机学院">计算机学院</option>
              <option value="电子工程学院">电子工程学院</option>
              <option value="管理学院">管理学院</option>
              <option value="外国语学院">外国语学院</option>
              <option value="数学学院">数学学院</option>
              <option value="物理学院">物理学院</option>
              <option value="化学学院">化学学院</option>
              <option value="机械学院">机械学院</option>
            </select>
          </div>
          
          <div class="form-group">
            <label>专业 *</label>
            <select v-model="form.major" :disabled="!form.college">
              <option value="">请选择专业</option>
              <option v-for="major in availableMajors" :key="major" :value="major">
                {{ major }}
              </option>
            </select>
          </div>
        </div>
        
        <!-- 兴趣爱好标签 -->
        <div class="form-section">
          <h3>兴趣爱好标签</h3>
          <p class="section-hint">选择您感兴趣的类别，帮助我们推荐更合适的商品</p>
          
          <div class="tags-container">
            <label 
              v-for="tag in interestTags" 
              :key="tag.value"
              class="tag-item"
              :class="{ active: form.interests.includes(tag.value) }"
            >
              <input 
                type="checkbox" 
                :value="tag.value" 
                v-model="form.interests"
              />
              <span class="tag-icon">{{ tag.icon }}</span>
              <span class="tag-label">{{ tag.label }}</span>
            </label>
          </div>
        </div>
        
        <!-- 提交按钮 -->
        <div class="form-actions">
          <button class="btn-skip" @click="handleSkip">跳过</button>
          <button class="btn-submit" @click="handleSubmit">完成设置</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { getCurrentUser, updateUser } from '../utils/storage.js'

const router = useRouter()
const route = useRoute()
const currentUser = ref(getCurrentUser())

// 表单数据
const form = ref({
  gender: '',
  college: currentUser.value?.department || '', // 使用注册时的院系
  major: '',
  interests: []
})

// 兴趣标签选项
const interestTags = [
  { value: '电子产品', label: '电子产品', icon: '💻' },
  { value: '教材', label: '教材书籍', icon: '📚' },
  { value: '生活用品', label: '生活用品', icon: '🏠' },
  { value: '服装', label: '服装配饰', icon: '👕' },
  { value: '运动器材', label: '运动健身', icon: '⚽' },
  { value: '自行车', label: '自行车', icon: '🚲' },
  { value: '乐器', label: '乐器', icon: '🎸' },
  { value: '美妆', label: '美妆护肤', icon: '💄' },
  { value: '游戏', label: '游戏娱乐', icon: '🎮' },
  { value: '摄影', label: '摄影器材', icon: '📷' },
  { value: '文具', label: '文具办公', icon: '✏️' },
  { value: '其他', label: '其他', icon: '📦' }
]

// 学院-专业映射
const collegeMajorMap = {
  '计算机学院': [
    '计算机科学与技术',
    '软件工程',
    '网络工程',
    '信息安全',
    '人工智能',
    '数据科学与大数据技术'
  ],
  '电子工程学院': [
    '电子信息工程',
    '通信工程',
    '微电子科学与工程',
    '集成电路设计与集成系统',
    '电子科学与技术'
  ],
  '管理学院': [
    '工商管理',
    '市场营销',
    '会计学',
    '财务管理',
    '人力资源管理',
    '电子商务'
  ],
  '外国语学院': [
    '英语',
    '日语',
    '德语',
    '法语',
    '翻译'
  ],
  '数学学院': [
    '数学与应用数学',
    '信息与计算科学',
    '统计学',
    '应用统计学'
  ],
  '物理学院': [
    '物理学',
    '应用物理学',
    '光电信息科学与工程',
    '材料物理'
  ],
  '化学学院': [
    '化学',
    '应用化学',
    '化学工程与工艺',
    '材料化学'
  ],
  '机械学院': [
    '机械设计制造及其自动化',
    '机械电子工程',
    '车辆工程',
    '工业设计'
  ]
}

// 可用专业列表
const availableMajors = computed(() => {
  return collegeMajorMap[form.value.college] || []
})

// 学院变化时清空专业
function onCollegeChange() {
  form.value.major = ''
}

// 跳过设置
function handleSkip() {
  if (confirm('确定要跳过吗？您可以稍后在个人中心完善信息')) {
    router.push('/market')
  }
}

// 提交设置
function handleSubmit() {
  // 验证必填项
  if (!form.value.gender) {
    alert('请选择性别')
    return
  }
  
  if (!form.value.college) {
    alert('请选择学院')
    return
  }
  
  if (!form.value.major) {
    alert('请选择专业')
    return
  }
  
  if (form.value.interests.length === 0) {
    alert('请至少选择一个兴趣标签')
    return
  }
  
  // 更新用户信息
  if (currentUser.value) {
    updateUser(currentUser.value.id, {
      gender: form.value.gender,
      college: form.value.college,
      major: form.value.major,
      interests: form.value.interests,
      profileCompleted: true
    })
    
    alert('个人信息设置成功！')
    router.push('/market')
  } else {
    alert('用户信息错误，请重新登录')
    router.push('/auth')
  }
}
</script>

<style scoped>
.profile-setup-page {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 40px 20px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
}

.setup-container {
  background: white;
  border-radius: 20px;
  padding: 48px;
  max-width: 700px;
  width: 100%;
  box-shadow: 0 20px 60px rgba(0,0,0,0.3);
  animation: fadeIn 0.5s ease;
}

.setup-header {
  text-align: center;
  margin-bottom: 40px;
}

.setup-header h1 {
  margin: 0 0 12px 0;
  font-size: 32px;
  color: #333;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

.setup-header p {
  margin: 0;
  color: #666;
  font-size: 16px;
}

.setup-form {
  display: flex;
  flex-direction: column;
  gap: 32px;
}

.form-section {
  padding: 24px;
  background: linear-gradient(135deg, #f8f9ff 0%, #ffffff 100%);
  border-radius: 16px;
  border: 2px solid rgba(102, 126, 234, 0.1);
}

.form-section h3 {
  margin: 0 0 20px 0;
  font-size: 20px;
  color: #333;
  display: flex;
  align-items: center;
  gap: 8px;
}

.section-hint {
  margin: -12px 0 16px 0;
  color: #999;
  font-size: 14px;
}

.form-group {
  margin-bottom: 20px;
}

.form-group:last-child {
  margin-bottom: 0;
}

.form-group label {
  display: block;
  margin-bottom: 12px;
  color: #333;
  font-weight: 600;
  font-size: 15px;
}

.form-group select {
  width: 100%;
  padding: 14px 16px;
  border: 2px solid #e0e0e0;
  border-radius: 12px;
  font-size: 15px;
  font-family: inherit;
  background: white;
  transition: all 0.3s;
}

.form-group select:focus {
  outline: none;
  border-color: #667eea;
  box-shadow: 0 0 0 4px rgba(102, 126, 234, 0.1);
}

.form-group select:disabled {
  background: #f5f5f5;
  cursor: not-allowed;
}

/* 单选按钮组 */
.radio-group {
  display: flex;
  gap: 16px;
  flex-wrap: wrap;
}

.radio-item {
  flex: 1;
  min-width: 120px;
  position: relative;
  cursor: pointer;
}

.radio-item input[type="radio"] {
  position: absolute;
  opacity: 0;
  width: 0;
  height: 0;
}

.radio-item span {
  display: block;
  padding: 16px 24px;
  border: 2px solid #e0e0e0;
  border-radius: 12px;
  text-align: center;
  font-size: 16px;
  font-weight: 500;
  transition: all 0.3s;
  background: white;
}

.radio-item input:checked + span {
  border-color: #667eea;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
  transform: translateY(-2px);
}

.radio-item:hover span {
  border-color: #667eea;
}

/* 标签选择 */
.tags-container {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(140px, 1fr));
  gap: 12px;
}

.tag-item {
  position: relative;
  cursor: pointer;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
  padding: 20px 12px;
  border: 2px solid #e0e0e0;
  border-radius: 12px;
  background: white;
  transition: all 0.3s;
}

.tag-item input[type="checkbox"] {
  position: absolute;
  opacity: 0;
  width: 0;
  height: 0;
}

.tag-icon {
  font-size: 32px;
  transition: transform 0.3s;
}

.tag-label {
  font-size: 14px;
  color: #666;
  font-weight: 500;
  transition: color 0.3s;
}

.tag-item.active {
  border-color: #667eea;
  background: linear-gradient(135deg, rgba(102, 126, 234, 0.1) 0%, rgba(118, 75, 162, 0.1) 100%);
}

.tag-item.active .tag-icon {
  transform: scale(1.2);
}

.tag-item.active .tag-label {
  color: #667eea;
  font-weight: 600;
}

.tag-item:hover {
  border-color: #667eea;
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(102, 126, 234, 0.2);
}

/* 按钮 */
.form-actions {
  display: flex;
  gap: 16px;
  margin-top: 16px;
}

.btn-skip,
.btn-submit {
  flex: 1;
  padding: 16px 32px;
  border: none;
  border-radius: 12px;
  font-size: 16px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s;
}

.btn-skip {
  background: #f5f5f5;
  color: #666;
}

.btn-skip:hover {
  background: #e0e0e0;
}

.btn-submit {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
}

.btn-submit:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 20px rgba(102, 126, 234, 0.5);
}

@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(30px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

@media (max-width: 768px) {
  .setup-container {
    padding: 32px 24px;
  }
  
  .tags-container {
    grid-template-columns: repeat(auto-fill, minmax(100px, 1fr));
  }
  
  .form-actions {
    flex-direction: column;
  }
}
</style>

