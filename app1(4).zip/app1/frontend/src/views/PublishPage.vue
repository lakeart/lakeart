<template>
  <div class="publish-page">
    <div class="publish-container">
      <h1>📝 发布商品</h1>
      
      <div class="publish-form">
        <!-- 基本信息 -->
        <div class="form-section">
          <h3>基本信息</h3>
          
          <div class="form-group">
            <label>商品标题 *</label>
            <input 
              v-model="form.title" 
              type="text" 
              placeholder="简短描述你的商品" 
              maxlength="50"
            />
          </div>
          
          <div class="form-group">
            <label>详细描述</label>
            <textarea 
              v-model="form.description" 
              placeholder="详细描述商品的状况、购买时间、使用情况等"
              rows="4"
            ></textarea>
          </div>
          
          <div class="form-group">
            <label>商品图片</label>
            <input type="file" accept="image/*" multiple @change="handleImageUpload" ref="imageInput" />
            <div v-if="imagePreviews.length > 0" class="image-previews">
              <div v-for="(img, index) in imagePreviews" :key="index" class="preview-item">
                <img :src="img" alt="商品图片">
                <button class="btn-remove" @click="removeImage(index)">×</button>
              </div>
            </div>
            
            <!-- 智能识别按钮 -->
            <div v-if="imagePreviews.length > 0 && imageFiles.length > 0" class="ocr-actions">
              <button 
                class="btn-ocr" 
                @click="recognizeProduct"
                :disabled="recognizing"
              >
                {{ recognizing ? '识别中...' : '🔍 智能识别商品信息' }}
              </button>
              
              <div v-if="recognizedInfo" class="recognized-result">
                <div class="result-title">✅ 识别结果：</div>
                <div v-if="recognizedInfo.brand" class="result-item">
                  <span>品牌：</span>
                  <strong>{{ recognizedInfo.brand }}</strong>
                </div>
                <div v-if="recognizedInfo.model" class="result-item">
                  <span>型号：</span>
                  <strong>{{ recognizedInfo.model }}</strong>
                </div>
                <div v-if="recognizedInfo.allTexts && recognizedInfo.allTexts.length > 0" class="result-item">
                  <span>识别到的文字：</span>
                  <div class="text-list">{{ recognizedInfo.allTexts.join(', ') }}</div>
                </div>
                <button class="btn-apply" @click="applyRecognizedInfo">应用识别结果</button>
              </div>
            </div>
          </div>
        </div>
        
        <!-- 分类信息 -->
        <div class="form-section">
          <h3>分类信息</h3>
          
          <div class="form-row">
            <div class="form-group">
              <label>类别 *</label>
              <select v-model="form.category" @change="onCategoryChange">
                <option value="">请选择</option>
                <option v-for="cat in categories" :key="cat" :value="cat">{{ cat }}</option>
              </select>
            </div>
            
            <div class="form-group">
              <label>品牌 *</label>
              <select v-model="form.brand" :disabled="!form.category">
                <option value="">请选择</option>
                <option v-for="brand in brands" :key="brand" :value="brand">{{ brand }}</option>
              </select>
            </div>
          </div>
          
          <div class="form-group">
            <label>型号</label>
            <input v-model="form.model" type="text" placeholder="选填" />
          </div>
          
          <div class="form-group">
            <label>标签（用空格分隔）</label>
            <input 
              v-model="tagsInput" 
              type="text" 
              placeholder="如：笔记本 苹果 办公 编程"
            />
          </div>
        </div>
        
        <!-- 智能定价 -->
        <div class="form-section pricing-section">
          <h3>💰 智能定价</h3>
          
          <div class="pricing-hint">
            请输入物品的原始价格（新品价格），系统会基于历史成交数据为您生成建议售价
          </div>
          
          <div class="form-group">
            <label>物品原始价格 * (元)</label>
            <input 
              v-model.number="form.originalPrice" 
              type="number" 
              placeholder="请输入该物品的新品价格"
              min="0"
              @input="clearSuggestion"
            />
          </div>
          
          <button 
            class="btn-generate-price" 
            @click="generatePrice"
            :disabled="!canGeneratePrice || generating"
          >
            {{ generating ? '生成中...' : '🎯 生成建议价' }}
          </button>
          
          <div v-if="suggestedPrice" class="price-suggestion">
            <div class="suggestion-header">
              <span class="label">建议售价区间：</span>
              <span class="range">¥{{ suggestedPrice.minPrice }} - ¥{{ suggestedPrice.maxPrice }}</span>
            </div>
            
            <div class="suggestion-detail">
              <div class="detail-item">
                <span>推荐价格：</span>
                <strong>¥{{ suggestedPrice.suggestedPrice }}</strong>
              </div>
              <div class="detail-item">
                <span>折旧率：</span>
                <span>{{ suggestedPrice.depreciationRate }}%</span>
              </div>
              <div class="detail-item">
                <span>数据来源：</span>
                <span>{{ sourceText }}</span>
              </div>
              <div class="detail-item">
                <span>样本数量：</span>
                <span>{{ suggestedPrice.sampleCount }} 条</span>
              </div>
            </div>
            
            <button class="btn-use-suggestion" @click="useSuggestion">
              使用推荐价格
            </button>
          </div>
          
          <div class="form-group">
            <label>最终售价 * (元)</label>
            <input 
              v-model.number="form.price" 
              type="number" 
              placeholder="请输入售价"
              min="0"
            />
          </div>
        </div>
        
        <!-- 提交按钮 -->
        <div class="form-actions">
          <button class="btn-cancel" @click="handleCancel">取消</button>
          <button class="btn-submit" @click="handleSubmit">发布商品</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { useRouter } from 'vue-router'
import axios from 'axios'
import { getCurrentUser, addItem, addPriceLog } from '../utils/storage.js'
import { 
  generateSuggestedPrice, 
  getCategories, 
  getBrandsByCategory
} from '../utils/pricing.js'

const router = useRouter()
const currentUser = ref(getCurrentUser())

// 表单数据
const form = ref({
  title: '',
  description: '',
  category: '',
  brand: '',
  model: '',
  originalPrice: null,
  price: null
})

const tagsInput = ref('')
const imagePreviews = ref([])
const imageFiles = ref([])
const imageInput = ref(null)
const generating = ref(false)
const suggestedPrice = ref(null)
const recognizing = ref(false)
const recognizedInfo = ref(null)

// 选项
const categories = getCategories()
const brands = ref([])

// 是否可以生成价格
const canGeneratePrice = computed(() => {
  return form.value.category && form.value.brand && form.value.originalPrice && form.value.originalPrice > 0
})

// 数据来源文本
const sourceText = computed(() => {
  if (!suggestedPrice.value) return ''
  return suggestedPrice.value.source === 'history' 
    ? '历史成交数据' 
    : '默认折旧率'
})

// 清除建议价格
function clearSuggestion() {
  if (suggestedPrice.value) {
    suggestedPrice.value = null
  }
}

// 分类变化时更新品牌列表
function onCategoryChange() {
  form.value.brand = ''
  brands.value = getBrandsByCategory(form.value.category)
}

// 处理图片上传
function handleImageUpload(event) {
  const files = Array.from(event.target.files)
  
  files.forEach(file => {
    // 保存原始文件（用于OCR）
    imageFiles.value.push(file)
    
    // 生成预览
    const reader = new FileReader()
    reader.onload = (e) => {
      imagePreviews.value.push(e.target.result)
    }
    reader.readAsDataURL(file)
  })
  
  // 清空识别结果
  recognizedInfo.value = null
}

// 移除图片
function removeImage(index) {
  imagePreviews.value.splice(index, 1)
  imageFiles.value.splice(index, 1)
  recognizedInfo.value = null
}

// 识别商品信息
async function recognizeProduct() {
  if (imageFiles.value.length === 0) {
    alert('请先上传商品图片')
    return
  }
  
  recognizing.value = true
  recognizedInfo.value = null
  
  try {
    // 使用第一张图片进行识别
    const formData = new FormData()
    formData.append('image', imageFiles.value[0])
    
    const response = await axios.post('http://localhost:5000/api/recognize/product', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    })
    
    if (response.data.success && response.data.data) {
      recognizedInfo.value = response.data.data
      alert('商品信息识别成功！')
    } else {
      alert(response.data.message || '识别失败')
    }
  } catch (error) {
    console.error('商品识别失败:', error)
    alert('识别失败，请确保后端服务已启动')
  } finally {
    recognizing.value = false
  }
}

// 应用识别结果
function applyRecognizedInfo() {
  if (!recognizedInfo.value) return
  
  // 自动填充品牌
  if (recognizedInfo.value.brand && !form.value.brand) {
    // 尝试匹配品牌列表
    const matchedBrand = brands.value.find(b => 
      b.toLowerCase().includes(recognizedInfo.value.brand.toLowerCase()) ||
      recognizedInfo.value.brand.toLowerCase().includes(b.toLowerCase())
    )
    if (matchedBrand) {
      form.value.brand = matchedBrand
    }
  }
  
  // 自动填充型号
  if (recognizedInfo.value.model && !form.value.model) {
    form.value.model = recognizedInfo.value.model
  }
  
  alert('已应用识别结果到表单')
}

// 生成建议价格
function generatePrice() {
  if (!canGeneratePrice.value) {
    alert('请先选择类别、品牌并填写原始价格')
    return
  }
  
  generating.value = true
  
  // 模拟延迟（实际是同步计算）
  setTimeout(() => {
    suggestedPrice.value = generateSuggestedPrice(
      form.value.category,
      form.value.brand,
      form.value.originalPrice
    )
    
    generating.value = false
    
    if (suggestedPrice.value.sampleCount === 0) {
      alert('暂无历史数据参考，已使用默认折旧率计算')
    }
  }, 800)
}

// 使用推荐价格
function useSuggestion() {
  if (suggestedPrice.value) {
    form.value.price = suggestedPrice.value.suggestedPrice
  }
}

// 取消发布
function handleCancel() {
  if (confirm('确定要取消发布吗？')) {
    router.back()
  }
}

// 提交发布
function handleSubmit() {
  // 验证必填项
  if (!form.value.title || !form.value.category || !form.value.brand || 
      !form.value.originalPrice || !form.value.price) {
    alert('请填写所有必填项')
    return
  }
  
  if (form.value.originalPrice <= 0) {
    alert('原始价格必须大于0')
    return
  }
  
  if (form.value.price <= 0) {
    alert('售价必须大于0')
    return
  }
  
  if (form.value.price >= form.value.originalPrice) {
    alert('售价不能大于或等于原始价格')
    return
  }
  
  // 解析标签
  const tags = tagsInput.value
    .split(/\s+/)
    .filter(tag => tag.trim())
  
  // 创建商品
  const newItem = addItem({
    sellerId: currentUser.value.id,
    title: form.value.title,
    description: form.value.description,
    category: form.value.category,
    brand: form.value.brand,
    model: form.value.model,
    originalPrice: form.value.originalPrice,
    price: form.value.price,
    images: imagePreviews.value,
    tags
  })
  
  // 记录定价偏差（如果使用了建议价）
  if (suggestedPrice.value) {
    const delta = form.value.price - suggestedPrice.value.suggestedPrice
    addPriceLog({
      itemId: newItem.id,
      originalPrice: form.value.originalPrice,
      suggested: suggestedPrice.value.suggestedPrice,
      finalPrice: form.value.price,
      delta,
      category: form.value.category,
      brand: form.value.brand
    })
  }
  
  alert('发布成功！')
  router.push('/market')
}
</script>

<style scoped>
.publish-page {
  padding: 20px 0;
}

.publish-container {
  background: white;
  border-radius: 12px;
  padding: 32px;
  max-width: 800px;
  margin: 0 auto;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}

.publish-container h1 {
  margin: 0 0 32px 0;
  font-size: 28px;
  color: #333;
}

.form-section {
  margin-bottom: 32px;
  padding-bottom: 32px;
  border-bottom: 1px solid #f0f0f0;
}

.form-section:last-of-type {
  border-bottom: none;
}

.form-section h3 {
  margin: 0 0 20px 0;
  font-size: 18px;
  color: #333;
}

.form-group {
  margin-bottom: 20px;
}

.form-group label {
  display: block;
  margin-bottom: 8px;
  color: #333;
  font-weight: 500;
}

.form-group input,
.form-group select,
.form-group textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ddd;
  border-radius: 8px;
  font-size: 14px;
  font-family: inherit;
}

.form-group input:focus,
.form-group select:focus,
.form-group textarea:focus {
  outline: none;
  border-color: #667eea;
}

.form-group input:disabled,
.form-group select:disabled {
  background: #f5f5f5;
  cursor: not-allowed;
}

.form-row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 16px;
}

.image-previews {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
  gap: 12px;
  margin-top: 12px;
}

.preview-item {
  position: relative;
  aspect-ratio: 1;
  border-radius: 8px;
  overflow: hidden;
  border: 2px solid #ddd;
}

.preview-item img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.btn-remove {
  position: absolute;
  top: 4px;
  right: 4px;
  width: 24px;
  height: 24px;
  border-radius: 50%;
  background: rgba(0,0,0,0.6);
  color: white;
  border: none;
  cursor: pointer;
  font-size: 18px;
  line-height: 1;
}

.pricing-section {
  background: linear-gradient(135deg, #ffeaa7 0%, #fdcb6e 100%);
  padding: 24px;
  border-radius: 12px;
  border: none;
}

.pricing-hint {
  margin-bottom: 16px;
  color: #666;
  font-size: 14px;
}

.btn-generate-price {
  width: 100%;
  padding: 14px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  border: none;
  border-radius: 8px;
  font-size: 16px;
  font-weight: bold;
  cursor: pointer;
  transition: all 0.3s;
}

.btn-generate-price:hover:not(:disabled) {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
}

.btn-generate-price:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.price-suggestion {
  margin: 20px 0;
  padding: 20px;
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}

.suggestion-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
  padding-bottom: 16px;
  border-bottom: 1px solid #f0f0f0;
}

.suggestion-header .label {
  font-size: 14px;
  color: #666;
}

.suggestion-header .range {
  font-size: 20px;
  font-weight: bold;
  color: #ff4757;
}

.suggestion-detail {
  display: flex;
  flex-direction: column;
  gap: 12px;
  margin-bottom: 16px;
}

.detail-item {
  display: flex;
  justify-content: space-between;
  font-size: 14px;
}

.detail-item span:first-child {
  color: #666;
}

.detail-item strong {
  color: #ff4757;
  font-size: 18px;
}

.btn-use-suggestion {
  width: 100%;
  padding: 10px;
  background: #52c41a;
  color: white;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  font-size: 14px;
  transition: all 0.3s;
}

.btn-use-suggestion:hover {
  background: #45a617;
}

.ocr-actions {
  margin-top: 16px;
}

.btn-ocr {
  width: 100%;
  padding: 12px;
  background: linear-gradient(135deg, #00b894 0%, #00cec9 100%);
  color: white;
  border: none;
  border-radius: 8px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s;
}

.btn-ocr:hover:not(:disabled) {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(0, 184, 148, 0.4);
}

.btn-ocr:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.recognized-result {
  margin-top: 16px;
  padding: 16px;
  background: #f6ffed;
  border: 1px solid #b7eb8f;
  border-radius: 8px;
}

.result-title {
  font-weight: bold;
  color: #52c41a;
  margin-bottom: 12px;
}

.result-item {
  margin-bottom: 8px;
  font-size: 14px;
}

.result-item span {
  color: #666;
}

.result-item strong {
  color: #333;
  margin-left: 8px;
}

.text-list {
  margin-top: 4px;
  padding: 8px;
  background: white;
  border-radius: 4px;
  font-size: 12px;
  color: #666;
  max-height: 60px;
  overflow-y: auto;
}

.btn-apply {
  width: 100%;
  margin-top: 12px;
  padding: 10px;
  background: #52c41a;
  color: white;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  font-size: 14px;
  transition: all 0.3s;
}

.btn-apply:hover {
  background: #45a617;
}

.form-actions {
  display: flex;
  gap: 16px;
  margin-top: 32px;
}

.btn-cancel,
.btn-submit {
  flex: 1;
  padding: 14px;
  border: none;
  border-radius: 8px;
  font-size: 16px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s;
}

.btn-cancel {
  background: #f5f5f5;
  color: #666;
}

.btn-cancel:hover {
  background: #e0e0e0;
}

.btn-submit {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
}

.btn-submit:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
}
</style>

