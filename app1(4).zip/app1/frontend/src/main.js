import { createApp } from 'vue'
import App from './App.vue'
import router from './router'
import './styles/main.css'
import { getUsers, getItems } from './utils/storage.js'
import { generateSampleData } from './utils/init.js'

// 首次启动时自动生成测试数据
const users = getUsers()
const items = getItems()
if (users.length === 0 && items.length === 0) {
  console.log('🎲 首次启动，自动生成测试数据...')
  generateSampleData()
  console.log('✅ 测试数据生成完成！')
}

const app = createApp(App)
app.use(router)
app.mount('#app')

