<template>
  <div class="item-card" @click="goToDetail">
    <div class="item-image">
      <img :src="item.images?.[0] || 'https://via.placeholder.com/300x200/CCCCCC/FFFFFF?text=No+Image'" :alt="item.title">
      <div class="item-status" v-if="item.status === 'SOLD'">已售出</div>
    </div>
    
    <div class="item-content">
      <h3 class="item-title">{{ item.title }}</h3>
      
      <div class="item-tags">
        <span class="tag" v-for="tag in item.tags?.slice(0, 3)" :key="tag">
          {{ tag }}
        </span>
      </div>
      
      <div class="item-info">
        <span class="brand">{{ item.brand }}</span>
        <span class="category">{{ item.category }}</span>
      </div>
      
      <div class="item-footer">
        <div class="price">¥{{ item.price }}</div>
        <div class="seller-info" v-if="seller">
          <span class="seller-name">{{ seller.name }}</span>
          <span class="seller-dept">{{ seller.department }}</span>
          <div class="badges" v-if="badges.length > 0">
            <span 
              class="badge-icon" 
              v-for="badge in badges.slice(0, 2)" 
              :key="badge.name"
              :title="badge.description"
            >
              {{ badge.icon }}
            </span>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import { useRouter } from 'vue-router'
import { getUserById } from '../utils/storage.js'
import { getUserBadges } from '../utils/credit.js'

const props = defineProps({
  item: {
    type: Object,
    required: true
  }
})

const router = useRouter()

const seller = computed(() => {
  return getUserById(props.item.sellerId)
})

const badges = computed(() => {
  if (!seller.value) return []
  return getUserBadges(seller.value.id)
})

function goToDetail() {
  router.push(`/item/${props.item.id}`)
}
</script>

<style scoped>
.item-card {
  background: white;
  border-radius: 12px;
  overflow: hidden;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
  transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
  cursor: pointer;
  position: relative;
  animation: fadeIn 0.5s ease;
}

.item-card::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: linear-gradient(135deg, rgba(102, 126, 234, 0.1) 0%, rgba(118, 75, 162, 0.1) 100%);
  opacity: 0;
  transition: opacity 0.4s;
  pointer-events: none;
}

.item-card:hover {
  transform: translateY(-8px) scale(1.02);
  box-shadow: 0 12px 32px rgba(102, 126, 234, 0.3);
}

.item-card:hover::before {
  opacity: 1;
}

.item-image {
  position: relative;
  width: 100%;
  height: 200px;
  overflow: hidden;
  background: linear-gradient(135deg, #f5f5f5 0%, #e8e8e8 100%);
}

.item-image img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  transition: transform 0.4s cubic-bezier(0.4, 0, 0.2, 1);
}

.item-card:hover .item-image img {
  transform: scale(1.1);
}

.item-status {
  position: absolute;
  top: 10px;
  right: 10px;
  background: rgba(0,0,0,0.7);
  color: white;
  padding: 4px 12px;
  border-radius: 4px;
  font-size: 12px;
}

.item-content {
  padding: 16px;
}

.item-title {
  font-size: 16px;
  font-weight: 600;
  margin: 0 0 12px 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.item-tags {
  display: flex;
  gap: 6px;
  margin-bottom: 12px;
  flex-wrap: wrap;
}

.tag {
  background: #f0f0f0;
  padding: 2px 8px;
  border-radius: 4px;
  font-size: 12px;
  color: #666;
}

.item-info {
  display: flex;
  gap: 8px;
  margin-bottom: 12px;
  font-size: 12px;
}

.brand {
  background: #e6f7ff;
  color: #1890ff;
  padding: 2px 8px;
  border-radius: 4px;
}

.category {
  background: #f6ffed;
  color: #52c41a;
  padding: 2px 8px;
  border-radius: 4px;
}

.item-footer {
  display: flex;
  justify-content: space-between;
  align-items: flex-end;
}

.price {
  font-size: 24px;
  font-weight: bold;
  background: linear-gradient(135deg, #ff4757 0%, #ff6b81 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

.seller-info {
  text-align: right;
  font-size: 12px;
  color: #999;
  display: flex;
  flex-direction: column;
  gap: 2px;
  align-items: flex-end;
}

.seller-name {
  font-weight: 500;
  color: #333;
}

.badges {
  display: flex;
  gap: 4px;
  margin-top: 4px;
}

.badge-icon {
  font-size: 14px;
}
</style>

